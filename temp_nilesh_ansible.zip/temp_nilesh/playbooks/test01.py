import os
print (''' first \n second ''')

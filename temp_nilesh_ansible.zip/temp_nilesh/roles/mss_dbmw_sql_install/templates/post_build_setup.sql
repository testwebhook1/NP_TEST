/**********************************************************
------------------ DB Maint script …. ---------------------
***********************************************************/
/**********************************************************

Completed Items : 

Enables/Creates/Updates DBMail profiles 
Creates Reorg/Updstats SP’s 
Creates Agent Job for Weekly Maintenance 
Creates RecycleErrorLog Job - This step can be included in a single cleanup job that runs daily - WIP
Changes ErrorLog Retention to 12days 
Disables XPs 
Revokes Guest user permission 
DisableLookbackCheck for A-Records 
Full backup Daily job
log backup job 
Default compress backup 
TempDB data file creation 
Model database recovery model
Autogrowth settings for model 
MIN/MAX Setup for Instance
Maintenance cleanup job 
Disable CEIP services 
Added log shring job where recovery Simple 1/26/2021

Pending Items:

ME login creation 
Creates CAS/IPSoft ID’s – Need to change logic to create local id


***********************************************************/
/**********************************************************
---------------- Enable Database Mail XPs  ----------------
***********************************************************/

EXEC master.dbo.sp_configure 'show advanced options', 1
RECONFIGURE WITH OVERRIDE
GO
exec sp_configure 'Database Mail XPs',1
RECONFIGURE WITH OVERRIDE
GO

select 'DBMailAccount_Before' [Type],p.name [ProfileName],p.description [ProfileDesc],a.name [AccountName],a.description [AccountDesc],a.email_address,a.display_name,a.replyto_address,pp.is_default
from [msdb].[dbo].[sysmail_profile] p join [msdb].[dbo].[sysmail_profileaccount] pa on p.profile_id=pa.profile_id
join [msdb].[dbo].[sysmail_account] a on pa.account_id=a.account_id join [msdb].[dbo].[sysmail_principalprofile] pp on p.profile_id=pp.profile_id
where p.name in ('SQLServerMail','SQLDBAMail') and p.description like 'Mail for SQL%'

IF NOT EXISTS(select 'DBMailAccount_Before' [Type],p.name [ProfileName],p.description [ProfileDesc],a.name [AccountName],a.description [AccountDesc],a.email_address,a.display_name,a.replyto_address,pp.is_default
from [msdb].[dbo].[sysmail_profile] p join [msdb].[dbo].[sysmail_profileaccount] pa on p.profile_id=pa.profile_id
join [msdb].[dbo].[sysmail_account] a on pa.account_id=a.account_id join [msdb].[dbo].[sysmail_principalprofile] pp on p.profile_id=pp.profile_id
where p.name in ('SQLServerMail','SQLDBAMail') and p.description like 'Mail for SQL%')
BEGIN
	-- Create a Database Mail account  
	EXECUTE msdb.dbo.sysmail_add_account_sp  
		@account_name = 'SQLDBAMail',  
		@description = 'SQLServer DBA Mail',  
		@email_address = 'SQLServerJobAlert@moodys.com',  
		@replyto_address = 'No-Reply@Moodys.com',  
		@display_name = 'SQLServer Job Alert',  
		@mailserver_name = 'exmx.moodys.com' ;  

	-- Create a Database Mail profile  
	EXECUTE msdb.dbo.sysmail_add_profile_sp  
		@profile_name = 'SQLDBAMail',  
		@description = 'Mail for SQLServer' ;  

	-- Add the account to the profile  
	EXECUTE msdb.dbo.sysmail_add_profileaccount_sp  
		@profile_name = 'SQLDBAMail',  
		@account_name = 'SQLDBAMail',  
		@sequence_number =1 ;  

	-- Grant access to the profile to all users in the msdb database  
	EXECUTE msdb.dbo.sysmail_add_principalprofile_sp  
		@profile_name = 'SQLDBAMail',  
		@principal_name = 'public',  
		@is_default = 1 ;  

	
END
ELSE -- If exists
BEGIN

declare @act_id int,@prof_id int
select @prof_id=pa.profile_id,@act_id=pa.account_id from [msdb].[dbo].[sysmail_profile] p join [msdb].[dbo].[sysmail_profileaccount] pa on p.profile_id=pa.profile_id
join [msdb].[dbo].[sysmail_account] a on pa.account_id=a.account_id join [msdb].[dbo].[sysmail_principalprofile] pp on p.profile_id=pp.profile_id
where p.name in ('SQLServerMail','SQLDBAMail') and p.description like 'Mail for SQL%'

exec msdb..sysmail_update_account_sp @account_id=@act_id,
	@account_name = 'SQLDBAMail',  
	@description = 'SQLServer DBA Mail',  
	@email_address = 'SQLServerJobAlert@moodys.com',  
	@replyto_address = 'No-Reply@Moodys.com',  
	@display_name = 'SQLServer Job Alert',  
	@mailserver_name = 'exmx.moodys.com' ; 

exec msdb..sysmail_update_profile_sp @profile_id=@prof_id,
	@profile_name = 'SQLDBAMail',  
    @description = 'Mail for SQLServer' 

END

GO

USE [msdb]
IF (OBJECT_ID('sp_send_dbmail_moodys') IS NOT NULL)
DROP PROCEDURE [dbo].[sp_send_dbmail_moodys] 
GO
CREATE PROCEDURE [dbo].[sp_send_dbmail_moodys] 
				@MailSubject varchar(1000) = '' ,@ErrorMessage varchar(2048) = '== SQLServer Database Mail =='
AS
BEGIN
	SET NOCOUNT ON;

	declare @strMailSubject varchar(1024)
	set @strMailSubject = '< ' + @@Servername + ' > ' + @MailSubject

	EXEC msdb.dbo.sp_send_dbmail 
		@profile_name = 'SQLDBAMail', 
		@recipients = 'SQLServerSupport@moodys.com;', 
		@body = @ErrorMessage, 
		@subject = @strMailSubject
END
GO
	--exec msdb.dbo.sp_send_dbmail_moodys 'Please Ignore! Testing. '

select 'DBMailAccount_After' [Type],p.name [ProfileName],p.description [ProfileDesc],a.name [AccountName],a.description [AccountDesc],a.email_address,a.display_name,a.replyto_address,pp.is_default
from [msdb].[dbo].[sysmail_profile] p join [msdb].[dbo].[sysmail_profileaccount] pa on p.profile_id=pa.profile_id
join [msdb].[dbo].[sysmail_account] a on pa.account_id=a.account_id join [msdb].[dbo].[sysmail_principalprofile] pp on p.profile_id=pp.profile_id
where p.name in ('SQLServerMail','SQLDBAMail') and p.description like 'Mail for SQL%'
GO



/**********************************************************
------------------- Create IPSoft ID  --------------------
***********************************************************/

declare @window_login_name SYSNAME
set @window_login_name='domainname\username'
declare @servername varchar(30),@hostname varchar(50), @instancename varchar(50), @domain varchar(50)

select @servername=@@servername
select @hostname = RTRIM(LTRIM(cast(SERVERPROPERTY('ComputerNamePhysicalNetBIOS') as varchar(200))))
	If @hostname is null 
	set @hostname = @instancename

declare @env CHAR(15)
set @env= case when @servername like '%1__' or @servername like '%7__' 
--or @servername like '%4__' or @servername like '%4___' 
or @servername like '%prd%'  or @servername like '%prod%' then 'prod' 
 when @hostname like '%1__' or @hostname like '%7__' then 'prod' 
when (@servername like '%2__' or @servername like '%DEV%'  or @servername like '%DV%' )
		and (@servername not like '%2e_' and @servername not like '%2QA' and @servername not like '%3201')  then 'dev' 
 else 'Controlled'
end --as 'env'

select @domain=DEFAULT_DOMAIN()
If @domain='ANALYTICS'
		select @domain = 'MDYNYCMAS'

		select DEFAULT_DOMAIN()
if @env = 'dev'
	set @window_login_name = @domain+'\sql_dv_ipc'
if @env = 'Controlled'
	set @window_login_name = @domain+'\sql_qa_ipc'
if @env = 'prod'
	set @window_login_name = @domain+'\sql_pr_ipc'

if SUSER_ID( @window_login_name) IS NULL
begin
	declare @version int
	declare @login_cmd varchar(100)
	set @version= @@microsoftversion / 0x01000000
	if (@version>8)

	begin
		set @login_cmd='create login ['+@window_login_name +'] from windows'
		exec(@login_cmd)
	end
	else
	begin
		exec sp_grantlogin @window_login_name
	end
end

use msdb
if not exists (select * from msdb.dbo.sysusers where [name]=@window_login_name)
begin
	EXEC msdb.dbo.sp_grantdbaccess @window_login_name, @window_login_name
	EXEC msdb.dbo.sp_addrolemember 'db_datareader', @window_login_name
	end
	else
	begin
	EXEC msdb.dbo.sp_addrolemember 'db_datareader', @window_login_name
	end

use master
declare @dyn_master_query_1 varchar(100)
if not exists (select * from master.dbo.sysusers where [name]=@window_login_name)
begin
	EXEC sp_grantdbaccess @window_login_name, @window_login_name
	EXEC sp_addrolemember 'db_datareader', @window_login_name
	
	set @dyn_master_query_1='Grant exec on xp_readerrorlog to ['+@window_login_name+']'
	exec(@dyn_master_query_1)

end
else
	begin
		EXEC sp_addrolemember 'db_datareader', @window_login_name
		
		set @dyn_master_query_1='Grant exec on xp_readerrorlog to ['+@window_login_name+']'
		exec(@dyn_master_query_1)
end

declare @grant_cmd varchar (200)
set @version= @@microsoftversion / 0x01000000
if (@version>8)
begin
	set @grant_cmd ='grant view server state to ['+@window_login_name+']'+
			' grant view any definition to ['+@window_login_name+']'
	use master
	exec (@grant_cmd)
	exec msdb.dbo.sp_addrolemember 'SQLAgentOperatorRole',@window_login_name

end
else
begin
	exec msdb.dbo.sp_addrolemember 'TargetServersRole',@window_login_name
end

GO

/**********************************************************
-------------------  Create CAS ID  ---------------------
***********************************************************/

declare @window_login_name SYSNAME
set @window_login_name='domainname\username'
declare @servername varchar(30),@hostname varchar(50), @instancename varchar(50), @domain varchar(50)

select @servername=@@servername
select @hostname = RTRIM(LTRIM(cast(SERVERPROPERTY('ComputerNamePhysicalNetBIOS') as varchar(200))))
	If @hostname is null 
	set @hostname = @instancename

declare @env CHAR(15)
set @env= case when @servername like '%1__' or @servername like '%7__' 
or @servername like '%prd%'  or @servername like '%prod%' then 'prod' 
 when @hostname like '%1__' or @hostname like '%7__' then 'prod' 
 else 'dev'
end --as 'env'

select @domain=DEFAULT_DOMAIN()
If @domain='ANALYTICS'
		select @domain = 'MDYNYCMAS'

if @env = 'dev'
	set @window_login_name = @domain+'\sql_ex_cas01'
if @env = 'prod'
	set @window_login_name = @domain+'\sql_pr_cas01'

if SUSER_ID( @window_login_name) IS NULL
begin
	declare @version int
	declare @login_cmd varchar(100)
	set @version= @@microsoftversion / 0x01000000
	if (@version>8)

	begin
		set @login_cmd='create login ['+@window_login_name +'] from windows'
		exec(@login_cmd)
	end
	else
	begin
		exec sp_grantlogin @window_login_name
	end
end

if not exists (select * from master.dbo.sysusers where [name]=@window_login_name)
begin
	EXEC sp_grantdbaccess @window_login_name, @window_login_name
	EXEC sp_addsrvrolemember  @window_login_name , 'sysadmin'
end

GO

/**********************************************************
------------------- Create reindex SP ---------------------
***********************************************************/

USE [master]
GO

/****** Object:  StoredProcedure [dbo].[rebuild_reorg_index]    ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[rebuild_reorg_index]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[rebuild_reorg_index]
GO

USE [master]
GO

/****** Object:  StoredProcedure [dbo].[rebuild_reorg_index]    ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [dbo].[rebuild_reorg_index]

@databaseToCheck VARCHAR(250) = NULL,
@fragmentationThreshold VARCHAR(10) = 10,
@indexFillFactor VARCHAR(5) = 90,
@reportOnly BIT = 0,
@doonline VARCHAR(5) = 'OFF',
@sortInTempdb VARCHAR(5) = 'ON'
-- created by Animesh 5/23/2017
-- monified by Nilesh 5/23/2017 filter added using table for flexibility
-- modified by Nilesh 5/24/2017 Try catch added.
-- modified by nilesh 5/25/2017 error count and information & softinTempDB parameter
-- modified by nilesh 5/25/2017 copy from other version for exsits condition and print date+table name
-- modified by Animesh 5/26/2017 added on line and off line both reindex with error msg executing second one too
-- Ver_201705_05

AS

BEGIN

  SET NOCOUNT ON

  SET ARITHABORT ON

  SET NUMERIC_ROUNDABORT OFF


--Initial check - You must be SysAdmin
DECLARE @isSysAdmin INT
SET @isSysAdmin=(SELECT IS_SRVROLEMEMBER ('sysadmin'));

--Initial check - You must be using SQL Server 2005 or later
DECLARE @SQLServerVersion INT
SET @SQLServerVersion=(SELECT CAST(LEFT(CAST(SERVERPROPERTY('ProductVersion') AS VARCHAR(50)),CHARINDEX('.',CAST

(SERVERPROPERTY('ProductVersion') AS VARCHAR(50)))-1) AS INT));

declare    @msg varchar(800), @errcount int
set @msg='* successfully over *'
set @errcount = 0

IF @isSysAdmin=1 AND @SQLServerVersion >= 9
BEGIN 

-- Variable/parameters Declaration
DECLARE @dbname NVARCHAR(128);
DECLARE @ReorganizeOrRebuildCommand NVARCHAR(MAX);
DECLARE @ReorganizeOrRebuildCommandExp NVARCHAR(MAX);
DECLARE @dbid INT;
--DECLARE @indexFillFactor VARCHAR(5); 
--DECLARE @fragmentationThreshold VARCHAR(10);
DECLARE @indexStatisticsScanningMode VARCHAR(20);
DECLARE @verboseMode BIT;
--DECLARE @reportOnly BIT;
-- DECLARE @sortInTempdb VARCHAR(3);
DECLARE @isHadrEnabled BIT;
--DECLARE @databaseToCheck VARCHAR(250)
DECLARE @dynamic_command NVARCHAR(1024);
DECLARE @dynamic_command_get_tables NVARCHAR(MAX);
DECLARE @schemaname NVARCHAR(255);
DECLARE @tablename NVARCHAR(255);

--Initializations - Do not change
--SET @databaseToCheck=NULL;
SET @dynamic_command = NULL;
SET @dynamic_command_get_tables = NULL;
SET @isHadrEnabled=0;

--SET NOCOUNT ON;

---------------------------------------------------------
--Set Parameter Values: You can change these (optional) -
--Note: The script has default parameters set   -
---------------------------------------------------------
--if set to 1: it will just generate a report with the index reorganization/rebuild statements
--if set to 0: it will reorganize or rebuild the fragmented indexes
--SET @reportOnly = 0;

--optional: if not set (NULL), it will scann all databases
--If name is set (i.e. 'testDB') it will just scan the given database
--SET @databaseToCheck = NULL;

--maintains only the indexes that have average fragmentation percentage equal or higher from the given value
--SET @fragmentationThreshold = 15;

--fill factor - the percentage of the data page to be filled up with index data
--SET @indexFillFactor = 90;

--sets the scanning mode for index statistics 
--available values: 'DEFAULT', NULL, 'LIMITED', 'SAMPLED', or 'DETAILED'
SET @indexStatisticsScanningMode='SAMPLED';

--if set to ON: sorts intermediate index results in TempDB 
--if set to OFF: sorts intermediate index results in user database's log file
--SET @sortInTempdb='ON'; 

--if set to 0: Does not output additional information about the index reorganization/rebuild process
--if set to 1: Outputs additional information about the index reorganization/rebuild process
SET @verboseMode = 1; 
------------------------------
--End Parameter Values Setup -
------------------------------

-- check if given database exists and if compatibility level >= SQL 2005 (90)
IF @verboseMode=1
 PRINT 'Checking if database '+@databaseToCheck+' exists and if compatibility level equals or greater 2005 (90)';

 -- if given database does not exist, raise error with severity 20
 -- in order to terminate script's execution
IF @databaseToCheck IS NOT NULL
BEGIN
 DECLARE @checkResult INT
 SET @checkResult=(SELECT COUNT(*) FROM master.sys.databases WHERE [name]=RTRIM(@databaseToCheck));
 IF @checkResult<1
  RAISERROR('Error executing index reorganization/rebuild script: Database does not exist' , 20, 1) WITH LOG;

 DECLARE @checkResult2 INT
 SET @checkResult=(SELECT [compatibility_level] FROM master.sys.databases WHERE [name]=RTRIM(@databaseToCheck));
 IF @checkResult<90
  RAISERROR('Error executing index reorganization/rebuild script: Only databases with SQL Server 2005 or later 

compatibility level are supported' , 20, 1) WITH LOG;  
END

IF @verboseMode=1
 PRINT 'Initial checks completed with no errors.';

-- Temporary table for storing index fragmentation details
IF OBJECT_ID('tempdb..#tmpFragmentedIndexes') IS NULL
BEGIN
CREATE TABLE #tmpFragmentedIndexes
    (
      [dbName] sysname,
      [tableName] sysname,
   [schemaName] sysname,
      [indexName] sysname,
      [databaseID] SMALLINT ,
      [objectID] INT ,
      [indexID] INT ,
      [AvgFragmentationPercentage] FLOAT,
   [reorganizationOrRebuildCommand] NVARCHAR(MAX),
   [reorganizationOrRebuildCommandExp] NVARCHAR(MAX)
    );
END 

-- Initialize temporary table
DELETE FROM #tmpFragmentedIndexes;

-- Validate parameters/set defaults
IF @sortInTempdb NOT IN ('ON','OFF')
SET @sortInTempdb='ON';

-- Check if instance has AlwaysOn AGs enabled
SET @isHadrEnabled=CAST((SELECT ISNULL(SERVERPROPERTY('IsHadrEnabled'),0)) AS BIT);

-- if database not specified scan all databases
IF @databaseToCheck IS NULL
BEGIN
DECLARE dbNames_cursor CURSOR
FOR
    SELECT  s.[name] AS dbName ,
            s.database_id
    FROM    master.sys.databases s            
    WHERE   s.state_desc = 'ONLINE'
            AND s.is_read_only != 1            
            AND s.[name] NOT IN ( 'master', 'model', 'tempdb' )
   AND s.[compatibility_level]>=90
    ORDER BY s.database_id;    
END 
ELSE
-- if database specified, scan only that database
BEGIN
DECLARE dbNames_cursor CURSOR 
FOR
    SELECT  s.[name] AS dbName ,
            s.database_id
    FROM    master.sys.databases s            
    WHERE   s.state_desc = 'ONLINE'
            AND s.is_read_only != 1                        
   AND s.[name]=RTRIM(@databaseToCheck)    
END 

-- if Always On Availability Groups are enabled, check for primary databases
-- (thus exclude secondary databases)
IF @isHadrEnabled=1
BEGIN

DEALLOCATE dbNames_cursor;

-- if database not specified scan all databases
IF @databaseToCheck IS NULL
BEGIN
 DECLARE dbNames_cursor CURSOR
 FOR
  SELECT  s.[name] AS dbName ,
    s.database_id
  FROM    master.sys.databases s
    LEFT JOIN master.sys.dm_hadr_availability_replica_states r ON s.replica_id = r.replica_id
  WHERE   s.state_desc = 'ONLINE'
    AND s.is_read_only != 1
    AND UPPER(ISNULL(r.role_desc, 'NonHadrEnabled')) NOT LIKE 'SECONDARY'
    AND s.[name] NOT IN ( 'master', 'model', 'tempdb' )
    AND s.[compatibility_level]>=90 
  ORDER BY s.database_id;    
END
ELSE
-- if database specified, scan only that database
BEGIN
 DECLARE dbNames_cursor CURSOR
 FOR
  SELECT  s.[name] AS dbName ,
    s.database_id
  FROM    master.sys.databases s
    LEFT JOIN master.sys.dm_hadr_availability_replica_states r ON s.replica_id = r.replica_id
  WHERE   s.state_desc = 'ONLINE'
    AND s.is_read_only != 1
    AND UPPER(ISNULL(r.role_desc, 'NonHadrEnabled')) NOT LIKE 'SECONDARY'    
    AND s.[name]=RTRIM(@databaseToCheck);  
END 
END 


--
-- For each database included in the cursor, 
-- gather all tables that have indexes with 
-- average fragmentation percentage equal or above @fragmentationThreshold
--
OPEN dbNames_cursor;
FETCH NEXT FROM dbNames_cursor INTO @dbname, @dbid;
WHILE @@fetch_status = 0
    BEGIN   
 
 --If verbose mode is enabled, print logs
        IF @verboseMode = 1
            BEGIN
    PRINT ''
                PRINT 'Gathering index fragmentation statistics for database: ['+ @dbname + '] with id: ' + CAST

(@dbid AS VARCHAR(10));    
            END;
                   
        SET @dynamic_command_get_tables = N'
 USE [' + @dbname+ N'];
 INSERT INTO #tmpFragmentedIndexes (
  [dbName],
  [tableName],
  [schemaName],
  [indexName],
  [databaseID],
  [objectID],
  [indexID],
  [AvgFragmentationPercentage],
  [reorganizationOrRebuildCommand],
  [reorganizationOrRebuildCommandExp] 
  )
  SELECT
     DB_NAME() as [dbName], 
     tbl.name as [tableName],
     SCHEMA_NAME (tbl.schema_id) as schemaName, 
     idx.Name as [indexName], 
     pst.database_id as [databaseID], 
     pst.object_id as [objectID], 
     pst.index_id as [indexID], 
     pst.avg_fragmentation_in_percent as [AvgFragmentationPercentage],
     CASE WHEN pst.avg_fragmentation_in_percent > 30 THEN 
     ''ALTER INDEX [''+idx.Name+''] ON [''+DB_NAME()+''].[''+SCHEMA_NAME (tbl.schema_id)+''].[''+tbl.name+''] 

REBUILD WITH (FILLFACTOR = '+@indexFillFactor+', SORT_IN_TEMPDB = '+@sortInTempdb+',ONLINE = '+ @doonline++',  STATISTICS_NORECOMPUTE = 

OFF);''
     WHEN pst.avg_fragmentation_in_percent > 5 AND pst.avg_fragmentation_in_percent <= 30 THEN 
     ''ALTER INDEX [''+idx.Name+''] ON [''+DB_NAME()+''].[''+SCHEMA_NAME (tbl.schema_id)+''].[''+tbl.name+''] 

REORGANIZE;''     
     ELSE
     NULL
     END,
	 CASE WHEN pst.avg_fragmentation_in_percent > 30 THEN 
     ''ALTER INDEX [''+idx.Name+''] ON [''+DB_NAME()+''].[''+SCHEMA_NAME (tbl.schema_id)+''].[''+tbl.name+''] 

REBUILD WITH (FILLFACTOR = '+@indexFillFactor+', SORT_IN_TEMPDB = '+@sortInTempdb+',ONLINE = OFF,  STATISTICS_NORECOMPUTE = 

OFF);''     
     ELSE
     NULL
     END
  FROM sys.dm_db_index_physical_stats(DB_ID(), NULL, NULL, NULL , '''+@indexStatisticsScanningMode+''') as pst
   INNER JOIN sys.tables as tbl ON pst.object_id = tbl.object_id
   INNER JOIN sys.indexes idx ON pst.object_id = idx.object_id AND pst.index_id = idx.index_id
  WHERE pst.index_id != 0  
   AND pst.alloc_unit_type_desc IN ( N''IN_ROW_DATA'', N''ROW_OVERFLOW_DATA'')
   AND pst.avg_fragmentation_in_percent >= '+ @fragmentationThreshold + '';
   
        
  -- if verbose  mode is enabled, print logs    
  IF @verboseMode=1
   BEGIN
    PRINT 'Index fragmentation statistics script: ';    
    PRINT @dynamic_command_get_tables;
  END

  -- gather index fragmentation statistics
        EXEC (@dynamic_command_get_tables);
       
     -- bring next record from the cursor
        FETCH NEXT FROM dbNames_cursor INTO @dbname, @dbid;
    END;

CLOSE dbNames_cursor;
DEALLOCATE dbNames_cursor;
-----------------------------------
--**Nilesh

If OBJECT_ID('dbo.MITDBA_Maintenance') is null
BEGIN 
	set @dynamic_command_get_tables = '

CREATE TABLE [dbo].[MITDBA_Maintenance](
	[MITId] [int] NOT NULL,
	[EntryDate] [datetime] NOT NULL,
	[UpdateDate] [datetime] NOT NULL,
	[DBName] [sysname] NOT NULL,
	[SchemaName] [sysname] NOT NULL,
	[TableName] [sysname] NOT NULL,
	[indexName] [sysname] NOT NULL,
	[IgnoreYN] [char](1) NOT NULL,
	[rebuildCMD] [varchar](200) NULL,
	[reOrgCMD] [varchar](200) NULL,
	[RecActiveYN] [char](1) NULL,
PRIMARY KEY CLUSTERED 
(
	[DBName] ASC,
	[SchemaName] ASC,
	[TableName] ASC,
	[indexName] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

ALTER TABLE [dbo].[MITDBA_Maintenance] ADD  CONSTRAINT [DF__MITDBA_Maint_Ignore]  DEFAULT (''Y'') FOR [IgnoreYN]
ALTER TABLE [dbo].[MITDBA_Maintenance] ADD  CONSTRAINT [DF__MITDBA_Maint_active]  DEFAULT (''Y'') FOR [RecActiveYN]
'
  EXEC (@dynamic_command_get_tables);
END
-- skip whoe database
delete #tmpFragmentedIndexes from #tmpFragmentedIndexes T  join
       master.[dbo].[MITDBA_Maintenance] ING on T.dbName = ING.[DBName] and ING.[SchemaName] = '*'
              where ING.RecActiveYN = 'Y' and ING.IgnoreYN = 'Y'
-- skip entire schema
delete #tmpFragmentedIndexes from #tmpFragmentedIndexes T  join
       master.[dbo].[MITDBA_Maintenance] ING on T.dbName = ING.[DBName] and t.schemaName = ING.[SchemaName] 
                     and ING.[TableName] = '*'
              where ING.RecActiveYN = 'Y' and ING.IgnoreYN = 'Y'
-- skip whole table
delete #tmpFragmentedIndexes from #tmpFragmentedIndexes  T  join
       master.[dbo].[MITDBA_Maintenance] ING on T.dbName = ING.[DBName] and t.schemaName = ING.[SchemaName]
              and T.tableName = ING.[TableName] and ING.indexName='*'
				and ING.RecActiveYN = 'Y' and ING.IgnoreYN = 'Y'
-- skip table+index
delete #tmpFragmentedIndexes from #tmpFragmentedIndexes  T  join
       master.[dbo].[MITDBA_Maintenance] ING on T.dbName = ING.[DBName] and t.schemaName = ING.[SchemaName]
              and T.tableName = ING.[TableName] and T.indexName = ING.indexName
				and ING.RecActiveYN = 'Y' and ING.IgnoreYN = 'Y'
--update customized command 
UPDATE #tmpFragmentedIndexes SET reorganizationOrRebuildCommand = [reOrgCMD]
       from #tmpFragmentedIndexes  T  join
       master.[dbo].[MITDBA_Maintenance] ING on T.dbName = ING.[DBName] and t.schemaName = ING.[SchemaName]
              and T.tableName = ING.[TableName] and T.indexName = ING.indexName and ING.RecActiveYN = 'Y'
       where reorganizationOrRebuildCommand like '%REORGANIZE%'
UPDATE #tmpFragmentedIndexes SET reorganizationOrRebuildCommand = [rebuildCMD]
       from #tmpFragmentedIndexes  T  join
       master.[dbo].[MITDBA_Maintenance] ING on T.dbName = ING.[DBName] and t.schemaName = ING.[SchemaName]
              and T.tableName = ING.[TableName] and T.indexName = ING.indexName and ING.RecActiveYN = 'Y'
	   where T.reorganizationOrRebuildCommand like '%REBUILD%'

------------------------------------------------------------

-- if 'report only' mode is enabled
IF @reportOnly=1
BEGIN 
 SELECT  dbName ,
            tableName ,
            schemaName ,
            indexName ,            
            AvgFragmentationPercentage ,
            reorganizationOrRebuildCommand,
			reorganizationOrRebuildCommandExp
 FROM    #tmpFragmentedIndexes
 ORDER BY AvgFragmentationPercentage DESC;
END
ELSE 
-- if 'report only' mode is disabled, then execute 
-- index reorganize/rebuild statements
BEGIN 
 DECLARE reorganizeOrRebuildCommands_cursor CURSOR
 FOR
    SELECT  dbName,schemaName,tableName,reorganizationOrRebuildCommand, reorganizationOrRebuildCommandExp
  FROM #tmpFragmentedIndexes
  WHERE reorganizationOrRebuildCommand IS NOT NULL
  ORDER BY AvgFragmentationPercentage DESC;

  
--Start executing the rebuild or reorg command

 OPEN reorganizeOrRebuildCommands_cursor;
 FETCH NEXT FROM reorganizeOrRebuildCommands_cursor INTO @dbname,@schemaname,@tablename,@ReorganizeOrRebuildCommand,@ReorganizeOrRebuildCommandExp ;
 WHILE @@fetch_status = 0
  BEGIN   
         
   IF @verboseMode = 1
   BEGIN
     PRINT ''
     PRINT 'Executing script:'     
     PRINT @ReorganizeOrRebuildCommand
   END
	print convert(char(22),getdate()) +'table '+@dbname +N'.' + @schemaname +N'.' + @tablename
   -------------- 
--declare    @msg varchar(800)
	IF OBJECT_ID(@dbname +N'.' + @schemaname +N'.' + @tablename, 'U') IS NOT NULL
	BEGIN
		BEGIN TRY  
			--select (1/0)
			EXEC  (@ReorganizeOrRebuildCommand);  
		END TRY  
		BEGIN CATCH
			select   @msg='ErrorMsg# '+convert(CHAR(10),ERROR_NUMBER())+' '+ERROR_MESSAGE() 
			print @msg
			set @errcount  = @errcount + 1
			IF @msg LIKE '%Online index operations can only be performed in Enterprise edition of SQL Server%' OR
				@msg LIKE '%online operation cannot be performed%'
			BEGIN
				PRINT 'Executing Rebuild Index OFFLINE:'
				EXEC  (@ReorganizeOrRebuildCommandExp);
				set @errcount  = @errcount - 1 --decreasing the actual error count by 1
			END
		END CATCH;
		--
		
	END
   FETCH NEXT FROM reorganizeOrRebuildCommands_cursor INTO @dbname,@schemaname,@tablename,@ReorganizeOrRebuildCommand,@ReorganizeOrRebuildCommandExp;
  END;

 CLOSE reorganizeOrRebuildCommands_cursor;
 DEALLOCATE reorganizeOrRebuildCommands_cursor;

 PRINT ''
 PRINT 'All fragmented indexes have been reorganized/rebuilt.'
 PRINT ''
	print @msg
	print 'Total error(s): '+STR(@errcount ) +'** i.e. search for ErrorMsg# in output log'
END
END 
ELSE
BEGIN
 PRINT '';
 PRINT 'Error: You need to be SysAdmin and use SQL Server 2005 or later in order to use this script.';
 PRINT '';
END
--End of Script

END

GO

/**********************************************************
------------------ Create UPD Stats SP ------------------
***********************************************************/
USE [master]
GO

/****** Object:  StoredProcedure [dbo].[update_stats]    ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[update_stats]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[update_stats]
GO

USE [master]
GO

/****** Object:  StoredProcedure [dbo].[update_stats]    ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[update_stats]

@databaseToCheck VARCHAR(255) = NULL,
@rowmodctr INT = 20, 
@samplepercent INT = 40,
@reportOnly BIT = 0
-- created by Animesh 8/01/2017
-- modified by Nilesh 8/02/2017 added reportonly and filter for system tables and null index name
-- Ver_201708_02

AS

BEGIN

  SET NOCOUNT ON

  SET ARITHABORT ON

  SET NUMERIC_ROUNDABORT OFF

DECLARE @DBS TABLE (I INT NOT NULL IDENTITY(1,1) PRIMARY KEY CLUSTERED,
                    DBNAME SYSNAME NOT NULL )--declare databases to check table

DECLARE @I INT --declare outer while loop start counter
        ,@Z INT --declare outer while loop end counter
        ,@SQL VARCHAR(1024) --declare variable for update stat command
        ,@j INT --declare inner while loop start counter
        ,@Y INT --declare inner while loop end counter
        ,@MYDB SYSNAME --declare dynamic variable for database to use
        ,@msg NVARCHAR(1024) --declare error message variable
		
--if database not specified scan all databases
IF @databaseToCheck IS NULL
BEGIN

--get the databases to check except master,tempdb and model
INSERT INTO @DBS
SELECT s.name 
FROM sys.databases s
INNER JOIN SYS.master_files F ON S.DATABASE_ID = F.database_id  AND F.data_space_id = 1
WHERE S.STATE = 0 -- online
  AND S.database_id > 3 -- exclude master, tempdb and model -- I left msdb 
  AND S.is_read_only = 0 -- read/write
  AND S.user_access = 0 -- multi_user
  --AND S.NAME NOT IN ('test')
ORDER BY F.SIZE DESC

END

--if database is specified scan the database only
ELSE
BEGIN

--get the specified database
INSERT INTO @DBS
SELECT s.name 
FROM sys.databases s
INNER JOIN SYS.master_files F ON S.DATABASE_ID = F.database_id  AND F.data_space_id = 1
WHERE S.STATE = 0 -- online
  AND S.NAME = @databaseToCheck -- for the specified database only 
  AND S.is_read_only = 0 -- read/write
  AND S.user_access = 0 -- multi_user
  --AND S.NAME NOT IN ('test')
ORDER BY F.SIZE DESC

END

SELECT @Z = @@ROWCOUNT --initalize end value for outer while loop
SELECT @I = 1 --initalize start value for inner while loop



WHILE @I <= @z 

BEGIN

	--drop and create temp table
    BEGIN TRY DROP TABLE #T END TRY BEGIN CATCH END CATCH
    CREATE TABLE #T( I INT NOT NULL IDENTITY(1,1) PRIMARY KEY CLUSTERED, tablename VARCHAR(1024) NOT NULL, 
	type_desc VARCHAR(1024) NOT NULL, index_name VARCHAR(1024) NULL, statistics_update_date [datetime] NULL, 
	rowmodctr INT NULL, MYSQL VARCHAR(1024) NOT NULL )
	--get the insert statement for temp table
    SELECT @MYDB = QUOTENAME (S.DBNAME )
           ,@SQL = 'USE ' + QUOTENAME (S.DBNAME ) + ';' + CHAR(13) + ' 
                    ' + CHAR(13) +
                   'INSERT INTO #T(tablename,type_desc,index_name,statistics_update_date,rowmodctr,MYSQL) 
SELECT 

DISTINCT
      tablename= OBJECT_NAME(i.object_id)
       , o.type_desc
       ,''all''--,index_name=i.[name]
    , ''01/01/01''--statistics_update_date = STATS_DATE(i.object_id, i.index_id)
       , si.rowmodctr, ''UPDATE STATISTICS '' + QUOTENAME(OBJECT_NAME(i.object_id)) + 
       '' WITH SAMPLE '+ cast(@samplepercent AS NVARCHAR) + ' PERCENT''
FROM sys.indexes i (nolock)
JOIN sys.objects o (nolock) on
       i.object_id=o.object_id 
	   and o.type_desc <> ''SYSTEM_TABLE''
	   and i.name is not null
JOIN sys.sysindexes si (nolock) on
       i.object_id=si.id
       and i.index_id=si.indid
       and si.rowmodctr >= '+ CAST (@rowmodctr AS NVARCHAR) + '
order by si.rowmodctr desc  ' + CHAR(13)  

      FROM @DBS s
        WHERE s.I = @I 


    PRINT CAST (@SQL AS NTEXT)
       BEGIN TRY

            EXEC (@SQL) -- execute the insert statement for temp table
            SELECT @Y = @@ROWCOUNT --initalize inner while loop end value

       END TRY
       BEGIN CATCH
           SELECT @Y = 0
       END CATCH



    SELECT @J = 1 --initalize inner while loop start value
if @reportOnly = 1 --to get the report only
	select @MYDB+' - '+MYSQL from    #T 
else

	BEGIN  --@reportOnly = 0
		WHILE @J <= @y BEGIN
			
			--get the command from the temp table along with the database name
		   SELECT @SQL = 'USE ' + @MYDB + ';' + CHAR(13) + MYSQL 
		   FROM #T 
		   WHERE I= @J

		   BEGIN TRY
				PRINT CAST (@SQL AS NTEXT)
				EXEC (@SQL) -- execute the update stats command
		   END TRY
		   BEGIN CATCH
				select   @msg='ErrorMsg# '+convert(CHAR(10),ERROR_NUMBER())+' '+ERROR_MESSAGE() --get the error while executing update stats
				print @msg
		   END CATCH

		   SELECT @J = @J + 1

		END /*INNER WHILE*/
	END --@reportOnly=0
    SELECT @I = @I +1

  END /*OUTER WHILE*/

END

GO


/****************************************************************************
------------- Create DB Backup/Cleaunup SP Modified by Arun on 10/9/2019---------------
****************************************************************************/
USE [master]
GO

/****** Object:  StoredProcedure [dbo].[usp_BackupDatabases]    Script Date: 10/9/2019 10:14:54 AM ******/
DROP PROCEDURE [dbo].[usp_BackupDatabases]
GO

/****** Object:  StoredProcedure [dbo].[usp_BackupDatabases]    Script Date: 10/9/2019 10:14:54 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



CREATE PROCEDURE [dbo].[usp_BackupDatabases]
@backupType CHAR(5)= null, 
@defaultType CHAR(10) = null,
@filePath VARCHAR(255) = null,
@LogPath VARCHAR(255) = null,
@logdir VARCHAR(255) = null,
@tmpName NVARCHAR(50) = null,
@fileName NVARCHAR(255) = null,
@fileDate NVARCHAR(20) = null,
@expDBs NVARCHAR(255) = null

--@dynSQL NVARCHAR(255) = null

AS
SET NOCOUNT ON; 

SELECT @fileDate = CONVERT(VARCHAR, GETDATE(),112) + '_' +  REPLACE(CONVERT(VARCHAR, GETDATE(),108),':','')   
EXEC master..xp_instance_regread @rootkey = 'HKEY_LOCAL_MACHINE', @key = 'Software\Microsoft\MSSQLServer\MSSQLServer',  
    @value_name = 'BackupDirectory', @BackupDirectory = @filePath OUTPUT ;
EXEC xp_create_subdir @filepath
IF @defaultType = 'F' -- Begin loop for Full backup
BEGIN
IF @backupType = 'A' -- Begin loop for All database
BEGIN
DECLARE db_cursor CURSOR READ_ONLY FOR  

SELECT name 
FROM sys.databases 
WHERE 
state ='0' and 
user_access_desc <> 'SINGLE_USER' and 
is_read_only = 0 and
name not in ('tempdb','distribution')

OPEN db_cursor   
FETCH NEXT FROM db_cursor INTO @tmpName   

WHILE @@FETCH_STATUS = 0   
BEGIN
   SET @fileName = @filePath +'\' + @tmpName + '_' + @fileDate + '.BAK'
   --SET @dynSQL = 'BACKUP '+ @defaultType +' [' + @tmpName + '] TO DISK='+ @fileName
   --EXECUTE sp_executesql @dynSQL
   BACKUP DATABASE @tmpName TO DISK = @fileName  
   FETCH NEXT FROM db_cursor INTO @tmpName   
END   
CLOSE db_cursor   
DEALLOCATE db_cursor
END

ELSE IF @backupType = 'S' --Beign Loop for Specific db's mentioned in @expDBs
BEGIN
DECLARE db_cursor CURSOR READ_ONLY FOR  
SELECT name 
FROM sys.databases 
WHERE 
name IN (@expDBs) and 
state ='0' and 
is_read_only = '0' and
user_access_desc <> 'SINGLE_USER'
 
OPEN db_cursor   
FETCH NEXT FROM db_cursor INTO @tmpName   
 
WHILE @@FETCH_STATUS = 0   
BEGIN
   SET @fileName = @filePath +'\' + @tmpName + '_' + @fileDate + '.BAK'
   --SET @dynSQL = 'BACKUP '+ @defaultType +' [' + @tmpName + '] TO DISK='+ @fileName
   --EXECUTE sp_executesql @dynSQL
   BACKUP DATABASE @tmpName TO DISK = @fileName  
   FETCH NEXT FROM db_cursor INTO @tmpName   
END   
CLOSE db_cursor   
DEALLOCATE db_cursor
END

ELSE IF @backupType = 'E' --Begin loop to exclude DB's in @expDBs
BEGIN
DECLARE db_cursor CURSOR READ_ONLY FOR  
SELECT name 
FROM sys.databases
WHERE 
name NOT IN (@expDBs) and 
state ='0' and 
is_read_only = '0' and
user_access_desc <> 'SINGLE_USER' and
name not in ('tempdb','distribution')
 
OPEN db_cursor   
FETCH NEXT FROM db_cursor INTO @tmpName   
 
WHILE @@FETCH_STATUS = 0   
BEGIN
   SET @fileName = @filePath +'\' + @tmpName + '_' + @fileDate + '.BAK'
   --SET @dynSQL = 'BACKUP '+ @defaultType +' [' + @tmpName + '] TO DISK='+ @fileName
   --EXECUTE sp_executesql @dynSQL
   BACKUP DATABASE @tmpName TO DISK = @fileName  
   FETCH NEXT FROM db_cursor INTO @tmpName   
END   
CLOSE db_cursor   
DEALLOCATE db_cursor
END

ELSE
PRINT 'Please specify backupType = A/S/E'
END

ELSE IF @defaultType = 'L' --Begin loop for Log backup
BEGIN
IF @backupType = 'A' --Being loop for log backup of all databases which are online and recovery is full
BEGIN
DECLARE db_cursor CURSOR READ_ONLY FOR  
SELECT name 
FROM sys.databases 
WHERE 
state ='0' and 
user_access_desc <> 'SINGLE_USER' and 
is_read_only = '0' and 
recovery_model_desc ='FULL' 
and name not in (SELECT primary_database FROM msdb..log_shipping_primary_databases)
and name not in ('tempdb','distribution')

OPEN db_cursor   
FETCH NEXT FROM db_cursor INTO @tmpName   

WHILE @@FETCH_STATUS = 0   
BEGIN
/*
EXEC master..xp_instance_regread @rootkey = 'HKEY_LOCAL_MACHINE', @key = 'Software\Microsoft\MSSQLServer\MSSQLServer',  
    @value_name = 'BackupDirectory', @BackupDirectory = @filePath OUTPUT ;
EXEC xp_create_subdir @filepath
*/
   set @logdir='Tlog_Backup'
   SET @LogPath= @filePath +'\' + @logdir
   EXEC xp_create_subdir @logpath
   SET @fileName = @LogPath +'\' + @tmpName + '_' + @fileDate + '.TRN'
   --SET @dynSQL = 'BACKUP '+ @defaultType +' [' + @tmpName + '] TO DISK='+ @fileName
   --EXECUTE sp_executesql @dynSQL
   BACKUP LOG @tmpName TO DISK = @fileName  
   FETCH NEXT FROM db_cursor INTO @tmpName   
END   
CLOSE db_cursor   
DEALLOCATE db_cursor
END

ELSE IF @backupType = 'S' -- Loop for specific db's
BEGIN
DECLARE db_cursor CURSOR READ_ONLY FOR  
SELECT name 
FROM sys.databases 
WHERE 
name IN (@expDBs) and 
state ='0' and 
is_read_only = '0' and 
recovery_model_desc ='FULL' and
user_access_desc <> 'SINGLE_USER'
 
OPEN db_cursor   
FETCH NEXT FROM db_cursor INTO @tmpName   
 
WHILE @@FETCH_STATUS = 0   
BEGIN
   SET @fileName = @filePath +'\' + @tmpName + '_' + @fileDate + '.TRN'
   --SET @dynSQL = 'BACKUP '+ @defaultType +' [' + @tmpName + '] TO DISK='+ @fileName
   --EXECUTE sp_executesql @dynSQL
   BACKUP LOG @tmpName TO DISK = @fileName  
   FETCH NEXT FROM db_cursor INTO @tmpName   
END   
CLOSE db_cursor   
DEALLOCATE db_cursor
END

ELSE IF @backupType = 'E' --Loop to exclude DBs 
BEGIN
DECLARE db_cursor CURSOR READ_ONLY FOR  
SELECT name 
FROM sys.databases
WHERE 
name NOT IN (@expDBs) and 
state ='0' and 
is_read_only = '0' and
user_access_desc <> 'SINGLE_USER' and 
recovery_model_desc = 'FULL' 
 
OPEN db_cursor   
FETCH NEXT FROM db_cursor INTO @tmpName   
 
WHILE @@FETCH_STATUS = 0
BEGIN
   SET @fileName = @filePath +'\' + @tmpName + '_' + @fileDate + '.TRN'
   --SET @dynSQL = 'BACKUP '+ @defaultType +' [' + @tmpName + '] TO DISK='+ @fileName
   --EXECUTE sp_executesql @dynSQL
   BACKUP LOG @tmpName TO DISK = @fileName  
   FETCH NEXT FROM db_cursor INTO @tmpName   
END   
CLOSE db_cursor   
DEALLOCATE db_cursor
END

ELSE
PRINT 'Please specify backupType = A/S/E'
END

ELSE
PRINT 'Please specify defaultType = F/L'


GO



-- Delete backups SP
USE [master]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_DeleteOldBackup]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_DeleteOldBackup]
GO

USE [master]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[usp_DeleteOldBackup] 
	@bkpDIR NVARCHAR(255) = null,
	@extension NVARCHAR(10),
	@age_hrs INT
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @DeleteDate NVARCHAR(50)
	DECLARE @DeleteDateTime DATETIME
	SET @DeleteDateTime = DateAdd(hh, - @age_hrs, GetDate())
    SET @DeleteDate = (Select Replace(Convert(nvarchar, @DeleteDateTime, 111), '/', '-') + 'T' + Convert(nvarchar, @DeleteDateTime, 108))
	EXEC master..xp_instance_regread @rootkey = 'HKEY_LOCAL_MACHINE',  
    @key = 'Software\Microsoft\MSSQLServer\MSSQLServer',  
    @value_name = 'BackupDirectory', @BackupDirectory = @bkpDIR OUTPUT ;
	EXEC xp_create_subdir @bkpDIR
	EXECUTE master.dbo.xp_delete_file 0, -- 0 for bkp files,1 for report files
		@bkpDIR,
		@extension,
		@DeleteDate,
		1 -- 0 for current folder,1 for subdirectories
END
GO


-----Delete Tlog SP Added by Arun on 10/9/2019------

USE [master]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_DeleteOldTrnlogBackup]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_DeleteOldTrnlogBackup]
GO

USE [master]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

USE [master]
GO

/****** Object:  StoredProcedure [dbo].[usp_DeleteOldTrnlogBackup]    Script Date: 10/9/2019 11:59:56 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [dbo].[usp_DeleteOldTrnlogBackup] 
	@bkpDIR NVARCHAR(255) = null,
	@extension NVARCHAR(10),
	@LogPath VARCHAR(255) = null,
	@logdir VARCHAR(255) = null,
	@age_hrs INT
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @DeleteDate NVARCHAR(50)
	DECLARE @DeleteDateTime DATETIME
	SET @DeleteDateTime = DateAdd(hh, - @age_hrs, GetDate())
    SET @DeleteDate = (Select Replace(Convert(nvarchar, @DeleteDateTime, 111), '/', '-') + 'T' + Convert(nvarchar, @DeleteDateTime, 108))
	EXEC master..xp_instance_regread @rootkey = 'HKEY_LOCAL_MACHINE',  
    @key = 'Software\Microsoft\MSSQLServer\MSSQLServer',  
    @value_name = 'BackupDirectory', @BackupDirectory = @bkpDIR OUTPUT ;

	set @logdir='Tlog_Backup'
    SET @LogPath= @bkpDIR +'\' + @logdir
	EXEC xp_create_subdir @LogPath
	EXECUTE master.dbo.xp_delete_file 0, -- 0 for bkp files,1 for report files
		@bkpDIR,
		@extension,
		@DeleteDate,
		1 -- 0 for current folder,1 for subdirectories
END

GO

/**********************************************************
---------------- Create DB Maint JOB  --------------------
***********************************************************/
USE [msdb]
GO

/****** Object:  Job [DB Maintenance Plan - Weekly]    Script Date: 06/10/2018 20:10:15 ******/
IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs WHERE name = N'DB Maintenance Plan - Weekly')
EXEC msdb.dbo.sp_delete_job @job_name=N'DB Maintenance Plan - Weekly', @delete_unused_schedule=1
GO

USE [msdb]
GO

/****** Object:  Job [DB Maintenance Plan - Weekly]    Script Date: 06/10/2018 20:10:15 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [Database Maintenance]    Script Date: 7/20/2018 1:03:45 AM ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'Database Maintenance' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'Database Maintenance'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'DB Maintenance Plan - Weekly', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'Weekly Maintenance Job', 
		@category_name=N'Database Maintenance', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [CheckDB]    Script Date: 7/20/2018 1:03:45 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'CheckDB', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=4, 
		@on_fail_step_id=4, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'BEGIN
IF OBJECT_ID(''tempdb..#CheckOnlineDB'') IS NOT NULL DROP TABLE #CheckOnlineDB
Create table #CheckOnlineDB
(
ID INT IDENTITY (1,1) NOT NULL ,
Database_name sysname NOT NULL,
State_desc nvarchar(60)
)

Insert into #CheckOnlineDB

Select name,state_desc 
from sys.databases 
where state_desc=''Online''

Declare @ExecuteCmd nvarchar(max), @ID Int, @DBName sysname, @State_Desc1 nvarchar(60)

SET @ID=1

While (1=1)
BEGIN
Select @ID=ID, @DBName=Database_name, @State_Desc1=State_desc
from #CheckOnlineDB
where ID=@ID
IF @@ROWCOUNT=0
BREAK

SET @ExecuteCmd = N''DBCC CHECKDB(['' + @DBName + N''])WITH NO_INFOMSGS, ALL_ERRORMSGS, DATA_PURITY ''
--Print @command1
exec sp_executesql @ExecuteCmd
Set @ID=@ID+1

END
END', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Reindexing]    Script Date: 7/20/2018 1:03:45 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Reindexing', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=4, 
		@on_fail_step_id=4, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXECUTE master.[dbo].[rebuild_reorg_index] 
@databaseToCheck = NULL,
@fragmentationThreshold=10, 
@indexFillFactor=90,
@doonline = ''ON'',
@sortInTempdb = ''ON'',
@reportOnly=0', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [UpdateStats]    Script Date: 7/20/2018 1:03:45 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'UpdateStats', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=4, 
		@on_fail_step_id=4, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC master.dbo.update_stats
@databaseToCheck = NULL,--NULL for all databases
@rowmodctr = 500,
@samplepercent=20,
@reportonly=0', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [SendNotification]    Script Date: 7/20/2018 1:03:45 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'SendNotification', 
		@step_id=4, 
		@cmdexec_success_code=0, 
		@on_success_action=2, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @strMailSubject varchar(1024)
set @strMailSubject = ''< '' + @@Servername + '' > '' + ''Job Failure : DB Maintenance - Weekly'' 

EXEC msdb.dbo.sp_send_dbmail 
     @profile_name = ''SQLDBAMail'', 
     @recipients = ''SQLServerSupport@moodys.com;'', 
     @body = ''Job Failure : DB Maintenance - Weekly'',
     @subject = @strMailSubject', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'WeelySchedule', 
		@enabled=1, 
		@freq_type=8, 
		@freq_interval=64, --Not to be changed unless day needs to be changed
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_time=230000 -- Not to be changed unless time needs to be changed
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO


/**********************************************************
---------------- Create DB Backup JOB  --------------------
***********************************************************/

USE [msdb]
GO

/****** Object:  Job [DB Backup Plan - Daily]    Script Date: 06/10/2018 20:06:48 ******/
IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'DB Backup Plan - Daily')
EXEC msdb.dbo.sp_delete_job @job_name=N'DB Backup Plan - Daily', @delete_unused_schedule=1
GO

USE [msdb]
GO
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [Database Maintenance]    Script Date: 7/20/2018 12:55:53 AM ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'Database Maintenance' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'Database Maintenance'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'DB Backup Plan - Daily', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'Takes Daily Backup', 
		@category_name=N'Database Maintenance', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [TakeBackup]    Script Date: 7/20/2018 12:55:53 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'TakeBackup', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=4, 
		@on_fail_step_id=3, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC usp_BackupDatabases
@backupType=''A'', --Specify A for all, S for specific databases and E to Exclude dbs in expDB
@expDBs='''', -- List the execption dbs
@defaultType=''F''', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [BackupCleanUp]    Script Date: 7/20/2018 12:55:53 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'BackupCleanUp', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=4, 
		@on_fail_step_id=3, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC usp_DeleteOldBackup
@extension=''bak'',
@age_hrs=''72''', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [SendNotification]    Script Date: 7/20/2018 12:55:53 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'SendNotification', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=2, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @strMailSubject varchar(1024)
set @strMailSubject = ''< '' + @@Servername + '' > '' + ''Job Failure : DB Backup - Daily'' 

EXEC msdb.dbo.sp_send_dbmail 
     @profile_name = ''SQLDBAMail'', 
     @recipients = ''SQLServerSupport@moodys.com;'', 
     @body = ''Job Failure : DB Backup - Daily'',
     @subject = @strMailSubject', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Schedule', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, --Not to be changed unless day needs to be changed
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0,
		@active_start_time=190000 --Not to be changed unless time needs to be changed
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO


/******************************************************************************************
---------------- Transaction_Log_Backup Job Added by Arun on 10/9/2019 --------------------
******************************************************************************************/

USE [msdb]
GO

/****** Object:  Job [Transaction_Log_Backup]    Script Date: 10/9/2019 12:08:44 PM ******/
IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs WHERE name = N'Transaction_Log_Backup')
EXEC msdb.dbo.sp_delete_job @job_name=N'Transaction_Log_Backup', @delete_unused_schedule=1
GO

/****** Object:  Job [Transaction_Log_Backup]    Script Date: 10/9/2019 12:08:44 PM ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [Database Maintenance]    Script Date: 10/9/2019 12:08:44 PM ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'Database Maintenance' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'Database Maintenance'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Transaction_Log_Backup', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'Takes Tlog Backup', 
		@category_name=N'Database Maintenance', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [TakeTlogBackup]    Script Date: 10/9/2019 12:08:44 PM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'TakeTlogBackup', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=4, 
		@on_fail_step_id=3, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC usp_BackupDatabases
@backupType=''A'', --Specify A for all, S for specific databases and E to Exclude dbs in expDB
@expDBs='''', -- List the execption dbs
@defaultType=''L''', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [TlogBackupCleanUp]    Script Date: 10/9/2019 12:08:44 PM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'TlogBackupCleanUp', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=4, 
		@on_fail_step_id=3, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC usp_DeleteOldTrnlogBackup
@extension=''trn'',
@age_hrs=''48''', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [SendNotification]    Script Date: 10/9/2019 12:08:44 PM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'SendNotification', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=2, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @strMailSubject varchar(1024)
set @strMailSubject = ''< '' + @@Servername + '' > '' + ''Job Failure : Transaction Log Backup - Failed'' 

EXEC msdb.dbo.sp_send_dbmail 
     @profile_name = ''SQLDBAMail'', 
     @recipients = ''SQLServerSupport@moodys.com;'', 
     @body = ''Job Failure : DB Backup - Daily'',
     @subject = @strMailSubject', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Schedule', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=4, 
		@freq_subday_interval=15, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20191009, 
		@active_end_date=99991231, 
		@active_start_time=0, 
		@active_end_time=235959
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/**********************************************************
---------------- Job to Purge JOB History -----------------
***********************************************************/

USE [msdb]
GO

/****** Object:  Job [DBA Log Purging]    Script Date: 7/19/2018 11:40:00 PM ******/
IF EXISTS(select name from msdb..sysjobs where name = 'DBA Log Purging')
EXEC msdb.dbo.sp_delete_job @job_name=N'DBA Log Purging', @delete_unused_schedule=1
GO


/****** Object:  Job [DBA Log Purging]    Script Date: 7/19/2018 11:40:00 PM ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 7/19/2018 11:40:00 PM ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'DBA Log Purging', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'--Deletes 2 weeks old error log files
--Deletes 8 weeks old MSDB backup/restore history
--Deletes 2 weeks old Job history log for every job
--Deletes 8 weeks old Maintenance plan history logs', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [LogPurge]    Script Date: 7/19/2018 11:40:00 PM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'LogPurge', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=4, 
		@on_fail_step_id=2, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'USE master
DECLARE @spath varchar(1000), @dt datetime, @st varchar(1000), @cutoff_date datetime

CREATE table #tmp (Logdate datetime, processinfo varchar(200), logtext varchar(1000))
INSERT into #tmp 
EXEC sp_readerrorlog 1,1,''Logging SQL''

--SELECT @spath =  [path] FROM Sys.dm_os_server_diagnostics_log_configurations

select @spath=logtext from #tmp
select @spath=rtrim(ltrim(right(@spath, len(@spath)-charindex(''file'',@spath)-4)))
select @spath=rtrim(replace(@spath,'''''''',''''))
select @spath=left(@spath, len(@spath)-1)
select @spath=right(reverse(@spath), len(@spath)-charindex(''\'',reverse(@spath))+1)
select @spath=reverse(@spath)
drop table #tmp

--- Cleanup Maintenance Plan report files -- 2 weeks before 
SET @cutoff_date = DATEADD(day, -15, GETDATE());
EXECUTE master.dbo.xp_delete_file 1,@spath,N''txt'',@dt
EXEC msdb.dbo.sp_purge_jobhistory  @oldest_date=@cutoff_date

--- History cleanup Task -- 8 weeks before 
SET @cutoff_date = DATEADD(day, -56, GETDATE());
EXEC msdb.dbo.sp_delete_backuphistory @cutoff_date

EXECUTE msdb..sp_maintplan_delete_log null,null,@cutoff_date
GO 
', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [SendNotiF]    Script Date: 7/19/2018 11:40:00 PM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'SendNotiF', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=2, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @strMailSubject varchar(1024)
set @strMailSubject = ''< '' + @@Servername + '' > '' + ''Job Failure : DB Maintenance - Weekly'' 

EXEC msdb.dbo.sp_send_dbmail 
     @profile_name = ''SQLDBAMail'', 
     @recipients = ''SQLServerSupport@moodys.com;'', 
     @body = ''Job Failure : DBA Log history Purging'',
     @subject = @strMailSubject', 
		@database_name=N'msdb', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'WeeklySchedule', 
		@enabled=1, 
		@freq_type=8, 
		@freq_interval=64, --Not to be changed unless day needs to be changed
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1,
 		@active_start_time=220000 --Not to be changed unless time needs to be changed
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO

/**********************************************************
-------------- Disable CEIP services ---------------
***********************************************************/


EXEC master.dbo.sp_configure 'show advanced options', 1
RECONFIGURE WITH OVERRIDE
GO
exec sp_configure 'xp_cmdshell',1
RECONFIGURE WITH OVERRIDE
GO

--Get All CEIP Service status
xp_cmdshell 'PowerShell.exe -command "Get-Service |? name -Like "*TELEMETRY*" | select -property name,starttype,status"'
go
--Stop and Disabled all CEIP services
--xp_cmdshell 'PowerShell.exe -command "Get-Service -name "*TELEMETRY*" | Stop-Service -passthru | Set-Service -startmode disabled"'
--go
xp_cmdshell 'PowerShell.exe -command "Get-Service -name "*TELEMETRY*" | Stop-Service "'
go
xp_cmdshell 'PowerShell.exe -command "Get-Service -name "*TELEMETRY*" | Set-Service -startmode disabled"'
go
--Get All Final CEIP Service status
xp_cmdshell 'PowerShell.exe -command "Get-Service |? name -Like "*TELEMETRY*" | select -property name,starttype,status"'
go

/**********************************************************
-------------- Config Change to disable XPs ---------------
***********************************************************/

Use Master
GO

EXEC master.dbo.sp_configure 'show advanced options', 1
RECONFIGURE WITH OVERRIDE
GO

EXEC master.dbo.sp_configure 'xp_available media', 0
go
EXEC master.dbo.sp_configure 'xp_cmdshell', 0
go
EXEC master.dbo.sp_configure 'xp_dirtree', 0
go
EXEC master.dbo.sp_configure 'xp_dsninfo', 0
go
EXEC master.dbo.sp_configure 'xp_enumdsn', 0
go
EXEC master.dbo.sp_configure 'xp_enumerrorlogs', 0
go
EXEC master.dbo.sp_configure 'xp_enumgroups', 0
go
EXEC master.dbo.sp_configure 'xp_eventlog', 0
go
EXEC master.dbo.sp_configure 'xp_getfiledetails', 0
go
EXEC master.dbo.sp_configure 'xp_getnetname',0
go
EXEC master.dbo.sp_configure 'xp_logevent', 0
go
EXEC master.dbo.sp_configure 'xp_loginconfig', 0
go
EXEC master.dbo.sp_configure 'xp_servicecontrol', 0
go
EXEC master.dbo.sp_configure 'Default trace enabled', 1;  
go 
EXEC master.dbo.sp_configure 'xp_sprintf', 0
go
EXEC master.dbo.sp_configure 'Ad Hoc Distributed Queries', 0;  
go
EXEC master.dbo.sp_configure 'Database Mail XPs', 1;   
go
EXEC master.dbo.sp_configure 'clr enabled', 0;
go
EXEC master.dbo.sp_configure 'Cross db ownership chaining', 0;   
go
EXEC master.dbo.sp_configure 'xp_sscanf', 0
go
EXEC master.dbo.sp_configure 'xp_subdirs', 0
go
EXEC master.dbo.sp_configure 'xp_deletemail',0 
go
EXEC master.dbo.sp_configure 'xp_findnextmsg',0
go
EXEC master.dbo.sp_configure 'xp_deletemail',0 
go
EXEC master.dbo.sp_configure 'xp_findnextmsg',0
go
EXEC master.dbo.sp_configure 'xp_get_mapi_default_profile',0
go
EXEC master.dbo.sp_configure 'xp_get_mapi_profiles',0
go
EXEC master.dbo.sp_configure 'xp_readmail',0
go
EXEC master.dbo.sp_configure 'xp_startmail',0
go
EXEC master.dbo.sp_configure 'xp_stopmail',0
go
EXEC master.dbo.sp_configure 'xp_cleanupwebtask',0 
go 
EXEC master.dbo.sp_configure 'xp_convertwebtask',0 
go 
EXEC master.dbo.sp_configure 'xp_dropwebtask',0 
go 
EXEC master.dbo.sp_configure 'xp_enumcodepages',0 
go 
EXEC master.dbo.sp_configure 'xp_makewebtask',0 
go 
EXEC master.dbo.sp_configure 'xp_readwebtask',0 
go 
EXEC master.dbo.sp_configure 'xp_runwebtask',0 
go
EXEC master.dbo.sp_configure 'sp_OADestroy',0 
go 
EXEC master.dbo.sp_configure 'sp_OAGetErrorInfo',0 
go 
EXEC master.dbo.sp_configure 'sp_OAStop',0 
go
EXECUTE sp_configure 'Database Mail XPs', 1;
go
EXECUTE sp_configure 'Remote admin connections', 0;
go
EXECUTE sp_configure 'Scan for startup procs', 0;
go
REVOKE EXECUTE ON xp_regaddmultistring TO PUBLIC;
go
REVOKE EXECUTE ON xp_regdeletekey TO PUBLIC;
go
REVOKE EXECUTE ON xp_regdeletevalue TO PUBLIC;
go
REVOKE EXECUTE ON xp_regenumvalues TO PUBLIC;
go
REVOKE EXECUTE ON xp_regremovemultistring TO PUBLIC;
go
REVOKE EXECUTE ON xp_regwrite TO PUBLIC;
go
REVOKE EXECUTE ON xp_regread TO PUBLIC;
go
REVOKE EXECUTE ON xp_regaddmultistring TO PUBLIC;
go
REVOKE EXECUTE ON xp_regdeletekey TO PUBLIC;
go
REVOKE EXECUTE ON xp_regdeletevalue TO PUBLIC;
go
REVOKE EXECUTE ON xp_regenumvalues TO PUBLIC;
go
REVOKE EXECUTE ON xp_regremovemultistring TO PUBLIC;
go
REVOKE EXECUTE ON xp_regwrite TO PUBLIC;
go
REVOKE EXECUTE ON xp_regread TO PUBLIC;
go

sp_configure 'allow updates',0
go

RECONFIGURE WITH OVERRIDE
GO

EXEC master.dbo.sp_configure 'show advanced options', 0
RECONFIGURE WITH OVERRIDE
GO

/**********************************************************
--------------- Create RecycleErrorlog Job ----------------
***********************************************************/

USE [msdb]
GO

BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]]    Script Date: 04/22/2015 14:10:32 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Recycle Errorlog', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [ReCycle]    Script Date: 04/22/2015 14:10:32 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'ReCycle', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N' exec sp_cycle_errorlog', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Recycle errorlog', 
		@enabled=1, 
		@freq_type=8, 
		@freq_interval=64, --Not to be changed unless day needs to be changed
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO


/**********************************************************
---------- Enable Default Backup Compression ----------
***********************************************************/

IF NOT EXISTS(SELECT * FROM sys.configurations WHERE name = 'backup compression default' AND value_in_use = 1)
EXEC sp_configure 'backup compression default', 1 ;  
RECONFIGURE WITH OVERRIDE ;  
GO

/**********************************************************
---------------- Change Recovery for Model ----------------
***********************************************************/

IF EXISTS(SELECT * FROM sys.databases WHERE name = 'model' and recovery_model_desc <> 'SIMPLE')
ALTER DATABASE model SET RECOVERY SIMPLE
GO
USE [master]
GO
ALTER DATABASE [model] MODIFY FILE ( NAME = N'modeldev', FILEGROWTH = 131072KB )
GO
ALTER DATABASE [model] MODIFY FILE ( NAME = N'modellog', FILEGROWTH = 131072KB )
GO

/**********************************************************
--------------- Change TEMPDB File num/size ---------------
***********************************************************/

USE [master]
GO
DECLARE @cpu_count      int,
         @file_count     int,
         @logical_name   sysname,
         @file_name      nvarchar(520),
         @physical_name  nvarchar(520),
         @size           int,
         @max_size       int,
         @growth         int,
         @alter_command  nvarchar(max)

SELECT  @physical_name = physical_name,
         @size = size / 128, 
         @max_size = max_size / 128,
         @growth = growth / 128
FROM    tempdb.sys.database_files
WHERE   name = 'tempdev'

SELECT  @file_count = COUNT(*)
FROM    tempdb.sys.database_files
WHERE   type_desc = 'ROWS'

SELECT  @cpu_count = cpu_count
FROM    sys.dm_os_sys_info

if @cpu_count > 8
select @cpu_count=8

WHILE @file_count < @cpu_count 
  BEGIN
     SELECT  @logical_name = 'tempdev' + CAST(@file_count AS nvarchar)
     SELECT  @file_name = REPLACE(@physical_name, 'tempdb.mdf', @logical_name + '.ndf')
     SELECT  @alter_command = 'ALTER DATABASE [tempdb] ADD FILE ( NAME =N''' + @logical_name + ''', FILENAME =N''' +  @file_name + ''', SIZE = 128 MB, MAXSIZE = 10 GB, FILEGROWTH = 128 MB )'
     EXEC sp_executesql @alter_command
     SELECT  @file_count = @file_count + 1
  END
GO

/**********************************************************
---------- SETUP MIN/MAX Memory for SQL Instance ----------
***********************************************************/

DECLARE @total_mem decimal(20,2),
		@min INT = 2048,
		@max INT,
		@SQLver INT,
		@dynSQL1 NVARCHAR (100),
		@dynSQL2 NVARCHAR (100),
		@dynDef NVARCHAR (100) 

SET NOCOUNT ON
SELECT @SQLver = @@MICROSOFTVERSION/0x01000000

SELECT @dynSQL1 = (SELECT CASE
WHEN @SQLver >= 11
THEN 'physical_memory_kb'
ELSE 'physical_memory_in_bytes'
END AS PhysMemMB FROM sys.dm_os_sys_info)

SET @dynSQL2 = 'SELECT @total_memOUT = ' +@dynSQL1+ ' FROM sys.dm_os_sys_info';
SET @dynDef = N'@total_memOUT decimal(20,2) OUTPUT';
EXEC SP_EXECUTESQL @dynSQL2, @dynDef, @total_memOUT=@total_mem OUTPUT

IF @SQLver >=11
SELECT @max = (@total_mem *(8.5 / 10.0))/(1024) 
ELSE
SELECT @max = (@total_mem *(8.5 / 10.0))/(1024*1024) 

EXEC sp_configure 'show advanced options',1
RECONFIGURE
EXEC sp_configure 'min server memory (MB)',@min
EXEC sp_configure 'max server memory (MB)',@max
EXEC sp_configure 'show advanced options',0
RECONFIGURE
GO

/**********************************************************
---------- Revoke CONNECT Permissions On 'Guest' ----------
***********************************************************/

EXECUTE master.sys.sp_MSforeachdb 'USE [?]; REVOKE CONNECT FROM guest'
go
USE msdb;
go
GRANT connect TO guest;
go

/**********************************************************
--------------- Change ErrorLog retention -----------------
***********************************************************/

USE [master]
GO
EXEC xp_instance_regwrite N'HKEY_LOCAL_MACHINE', N'Software\Microsoft\MSSQLServer\MSSQLServer', N'NumErrorLogs', REG_DWORD, 12
GO

/**********************************************************
---------- DisableLookbackCheck for A-RECORD --------------
***********************************************************/

EXEC xp_instance_regwrite
      @rootkey = N'HKEY_LOCAL_MACHINE',
      @key =N'SYSTEM\CurrentControlSet\Control\Lsa',
      @value_name = N'DisableLoopbackCheck',
      @type = N'REG_DWORD',
      @value = 1
GO	  
USE [msdb]
GO

/****** Object:  Job [DB Shrink_Log_File]    Script Date: 01/11/2021 5:42:12 AM ******/
IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs WHERE name = N'DB Shrink_Log_File')
EXEC msdb.dbo.sp_delete_job @job_name=N'DB Shrink_Log_File', @delete_unused_schedule=1
GO

/****** Object:  Job [DB Shrink_Log_File]    Script Date: 01/11/2021 5:42:12 AM ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 01/11/2021 5:42:12 AM ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'DB Shrink_Log_File', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Shrink_File]    Script Date: 11/18/2020 5:42:12 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Shrink_File', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'DECLARE @dbname VARCHAR(256)
DECLARE @logname VARCHAR(256)
DECLARE @dbcursor CURSOR
SET @dbcursor = CURSOR
FOR
SELECT  d.name, mf.name as logfile--, physical_name AS current_file_location, size
	FROM sys.master_files mf
	inner join sys.databases d
		on mf.database_id = d.database_id
	where d.recovery_model_desc = ''SIMPLE''
	and d.name not in (''master'',''model'',''msdb'')
	and mf.type in  (1)
	OPEN @dbcursor
FETCH NEXT
FROM @dbcursor
INTO @dbname, @logname
WHILE @@FETCH_STATUS = 0
BEGIN
    --PRINT (''USE ['' + @dbname + ''] DBCC SHRINKFILE ('''''' + @logname + '''''' , 1024, TRUNCATEONLY)'')        --Uncomment this to print the shrink commands
    --EXEC (''USE ['' + @dbname + ''] DBCC SHRINKFILE ('''''' + @logname + '''''' , 1024, TRUNCATEONLY)'')
      EXEC (''USE ['' + @dbname + ''] DBCC SHRINKFILE ('''''' + @logname + '''''' , 1024)'')
    FETCH NEXT
    FROM @dbcursor
    INTO @dbname, @logname
END
CLOSE @dbcursor
DEALLOCATE @dbcursor', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'schedule', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=8, 
		@freq_subday_interval=4, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20201118, 
		@active_end_date=99991231, 
		@active_start_time=180000, 
		@active_end_time=60259
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

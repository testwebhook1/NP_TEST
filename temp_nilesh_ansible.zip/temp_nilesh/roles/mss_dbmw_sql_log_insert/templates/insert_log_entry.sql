USE [MDYMIT_DBs]
GO

INSERT INTO [dbo].[asb_mssql_playbook_log]
           ([playbook_name]
           ,[Ranby]
           ,[ok_flag]
           ,[SQLname]
           ,[SQLDBname]
           ,[SQLLoginname]
           ,[Parm1]
           ,[Parm2]
           ,[Parm3]
           ,[Parm4]
           ,[Parm5]
           ,[Parm6]
           ,[Parm7]
           ,[Parm8], [outputfile], [asb_tower] )
     VALUES
           ( '{{ playbook_name }}' 
           , '{{ Ranby }} '
           , '{{ok_flag }}'
           , '{{ SQLname }}'
           , '{{ SQLDBname }}'
           , '{{ SQLLoginname }}'
           , '{{ Parm1 }}'
           , '{{ Parm2 }}'
           , '{{ Parm3 }}'
           , '{{ Parm4 }}'
           , '{{ Parm5 }}'
           , '{{ Parm6 }}'
           , '{{ Parm7 }}'
           , '{{ Parm8 }}'
           , '{{ outputfile }}' , '{{ asb_tower }}')
GO



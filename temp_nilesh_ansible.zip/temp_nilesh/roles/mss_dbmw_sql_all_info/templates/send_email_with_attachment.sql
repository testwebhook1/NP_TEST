declare @tableHTML varchar(max), @subject varchar(100), @att_path varchar(3000)
SET @tableHTML = '<table border="1" >' +    
'<tr > Dear Team, </tr><tr> Please find all SQL info in the attached (csv) for server {{ servername }},{{ sqlportno }} </tr>
<tr>Regards,</tr><tr>SQL Server team</tr></table>'

select @att_path = '{{ installation_path_setup }}{{ servername }}runme_out.csv'
select @subject='<{{ servername }}> -::- all SQL info (biodata) ::  (asb - mss_dbmw_sql_all_info)'

EXEC msdb.dbo.sp_send_dbmail      
      @recipients='{{ to_email }}',
   --@recipients='NileshR.Patel@moodys.com;Deepak.Vispute-non-empl@moodys.com;SQLServerSupport@moodys.com;',
   -- @recipients='Deepak.Vispute-non-empl@moodys.com;',
	@copy_recipients='{{ cc_email }}',    
	@subject = @subject,    
	@body = @tableHTML,    
	@body_format = 'HTML' ,
	@file_attachments = @att_path;
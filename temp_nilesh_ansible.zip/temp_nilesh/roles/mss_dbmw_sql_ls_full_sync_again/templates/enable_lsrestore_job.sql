declare @jobname varchar(500), @running int
declare @dbname varchar(500)
set @dbname = '{{ tgtuserdbname }}'

select @jobname = @dbname +' LSRestore NoJobFound'

select @jobname = name from msdb..sysjobs
 where name like 'LSRestore%' and name like '%'+RTRIM(@dbname)

If @@rowcount = 0  
	select 'LS Restore not found for this DB: '+@dbname
else
Begin
	EXEC msdb.dbo.sp_update_job  
		@job_name = @jobname,  
		 @enabled = 1 
	select @jobname + ' enabled ' , getdate()
end

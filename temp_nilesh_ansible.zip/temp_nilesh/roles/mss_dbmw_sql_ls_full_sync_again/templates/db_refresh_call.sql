insert into MIT_DBRefresh.dbo.SQLRefreshRequest (RequestNo, RequesterEmail, Source_Server, Source_DB, Target_Server, Target_DB, Overwrite, 
Last_Night_Backup, Login_Retain, Recovery, debugmode) 
values ('DR_Sync','SQLServerSupport@moodys.com','{{ prodservername }}', '{{ userdbname }}','{{ drservername }}','{{ tgtuserdbname }}','Y',
'N','N','N','AE')

USE [{{ userdbname }}]
GO
if not exists(select uid from sysusers where name = '{{ username }}')
	CREATE USER [{{ username }}] FOR LOGIN [{{ username }}] WITH DEFAULT_SCHEMA=[dbo];
GO
if 'Y' = '{{ read_all }}'
	ALTER ROLE [db_datareader] ADD MEMBER [{{ username }}];
GO
if 'Y' = '{{ write_all }}'
	ALTER ROLE [db_datawriter] ADD MEMBER [{{ username }}];
GO
if 'Y' = '{{ userdb_DBO }}'
	ALTER ROLE [db_owner] ADD MEMBER [{{ username }}];
GO

if 'Y' = '{{ execute_all }}'
	GRANT EXECUTE TO [{{ username }}];
GO

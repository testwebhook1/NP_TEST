USE [master]
GO
declare @dfdata nvarchar(Max)
declare @lfdata nvarchar(Max)
declare @sqlstring nvarchar(Max)

select @dfdata=CONVERT(sysname,SERVERPROPERTY('InstanceDefaultDataPath'))+'{{ userdbname }}.mdf' -- '{{ userdbname }}.mdf'
select @lfdata=CONVERT(sysname,SERVERPROPERTY('InstanceDefaultLogPath'))+'{{ userdbname }}_log.ldf' -- '{{ userdbname }}_log.ldf'

/****** Object:  Database [testdb]    Script Date: 10/7/2020 10:14:10 AM ******/
set @sqlstring = 'CREATE DATABASE [{{ userdbname }}]
 CONTAINMENT = NONE
 ON  PRIMARY 
( NAME = N''{{ userdbname }}'', FILENAME = N'''+ @dfdata +''', SIZE = 131072KB , MAXSIZE = UNLIMITED, FILEGROWTH = 131072KB )  
 LOG ON 
( NAME = N''{{ userdbname }}_log'', FILENAME = N'''+ @lfdata+''' , SIZE = 131072KB , MAXSIZE = 2048GB , FILEGROWTH = 131072KB )' -- '{{ userdbname }} - 2 places
select @sqlstring
execute (@sqlstring)
go
USE [master]
GO
IF LEFT(@@servername,3) = 'PTC'
	ALTER DATABASE [{{ userdbname }}] SET RECOVERY FULL WITH NO_WAIT -- [{{ userdbname }}]
ELSE
	ALTER DATABASE [{{ userdbname }}] SET RECOVERY SIMPLE WITH NO_WAIT -- [{{ userdbname }}]
GO



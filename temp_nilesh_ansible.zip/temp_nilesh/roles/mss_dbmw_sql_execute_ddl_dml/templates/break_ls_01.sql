declare @jobname varchar(500), @running int
declare @dbname varchar(500)
set @dbname = '{{ userdbname }}'
select @jobname = @dbname +' LSCopy NoJobFound'
select @jobname = name from msdb..sysjobs
 where name like 'LSCopy%' and name like '%'+RTRIM(@dbname)
If @@rowcount = 0  
	select 'LS copy not found for this DB: '+@dbname
else
Begin
	exec msdb..sp_start_job @jobname
	select @jobname + ': Job started' , getdate()

--select * from msdb..sysjobhistory where name = @jobname
	set @running = 1
	while @running = 1
	begin
		WAITFOR DELAY '00:00:03'
		SELECT 'checking job status - running '+@jobname FROM msdb.dbo.sysjobs J 
          JOIN msdb.dbo.sysjobactivity A 
              ON A.job_id=J.job_id and name = @jobname
          WHERE 
          A.run_requested_date IS NOT NULL 
          AND A.stop_execution_date IS NULL
		select @running = @@ROWCOUNT
	end
	select @jobname + ': Job Over' , getdate()
end

select @jobname = @dbname +' LSRestore NoJobFound'

select @jobname = name from msdb..sysjobs
 where name like 'LSRestore%' and name like '%'+RTRIM(@dbname)
If @@rowcount = 0  
	select 'LS Restore not found for this DB: '+@dbname
else
Begin
	exec msdb..sp_start_job @jobname
	select @jobname + ': Job started' , getdate()
--select * from msdb..sysjobhistory where name = @jobname
	set @running = 1
	while @running = 1
	begin
	 WAITFOR DELAY '00:00:03'
	 SELECT 'checking job status - running '+@jobname FROM msdb.dbo.sysjobs J 
          JOIN msdb.dbo.sysjobactivity A 
              ON A.job_id=J.job_id and name = @jobname
          WHERE 
          A.run_requested_date IS NOT NULL 
          AND A.stop_execution_date IS NULL
	select @running = @@ROWCOUNT
	end
	select @jobname + ': Job Over' , getdate()
	EXEC msdb.dbo.sp_update_job  
		@job_name = @jobname,  
		 @enabled = 0

end
select 'Opening DB for read/write '

-- tested dummy on FRM701 below 2 
--RESTORE LOG [testdb]
RESTORE LOG [{{ userdbname }}]


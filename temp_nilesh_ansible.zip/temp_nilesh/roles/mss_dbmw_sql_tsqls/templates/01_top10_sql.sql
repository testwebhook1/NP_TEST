DECLARE @tableHTML  NVARCHAR(MAX) ,  @tableHTMLcss  NVARCHAR(MAX) ,  @tableHTML1  NVARCHAR(MAX) , 
 @type char(1),@MailSubject varchar(1000) ,@to_recp varchar(1000),  @cc_recp varchar(1000),  @bcc_recp varchar(300), 
 @strMailSubject varchar(1024)    
 set nocount on 
Select @type ='',@MailSubject = ''    
set @strMailSubject = '< ' + '{{ servername }}' + ' > '  + ' Health Checkup Report'     

--select @to_recp = 'Deepak.Vispute-non-empl@moodys.com', @cc_recp='Deepak.Vispute-non-empl@moodys.com'
select @to_recp = '{{ to_email }}', @cc_recp='{{ cc_email }}'

SET @tableHTMLcss =    
N'    
<style>    
.hd1 {    
 color:white;    
 font-size:14.0pt;    
 text-decoration:none;    
 font-family:Calibri, sans-serif;    
 text-align:center;    
 background:#1F497D;    
}    
.hd2 {    
 color:black;    
 font-size:10.0pt;    
 text-decoration:none;    
 font-family:Calibri, sans-serif;    
 text-align:center;    
 background:#95B3D7;    
}    
.td12 {    
 color:black;    
 font-size:9.0pt;    
 text-decoration:none;    
 font-family:Calibri, sans-serif;    
 background:#D9D9D9;    
}    
.td3 {    
 color:black;    
 font-size:9.0pt;    
 text-decoration:none;    
 font-family:Calibri, sans-serif;    
 background:#D8E4BC;    
}    
    
</style>'     

--> Blocking Start
Select @tableHTML = @tableHTMLcss +     
    N'<table border="1" >' +    
    N'<tr class="hd1" ><th>  </th><th>Blocking</th>' +  '</tr></table>'

SET @tableHTML = @tableHTML +     
    N'<table border="1" >' +    
    N'<tr class="hd2" ><th>Session ID</th><th>Command</th><th>Blocking Session ID</th><th>Wait Time</th><th>Wait Type</th></tr>'     

select  @tableHTML = @tableHTML + N'<tr class="td3"> <td>'+ str(session_id,4) + N'</td><td>'+ isnull(command,'') +     
     N'</td><td>' + str(blocking_session_id, 4) + N'</td><td>' + str(wait_time,10,2) + N'</td><td>' + isnull(wait_type,'') + N'</td></tr>'    
 from sys.dm_exec_requests where blocking_session_id <> 0
-- session_id < 10

select @tableHTML = @tableHTML + N'<tr> <td colspan=5>&nbsp;</td> </tr></table>'    

--> Top 10 CPU Start

Select @tableHTML1 =      
    N'<table border="1" >' +    
    N'<tr class="hd1" ><th>  </th><th>Top 10 CPU</th>' +  '</tr></table>'

SET @tableHTML1 = @tableHTML1 +     
    N'<table border="1" >' +    
    N'<tr class="hd2" ><th>Creation Time</th><th>Last Execution Time</th><th>Total Worker Time</th><th>Average CPU Time</th><th>Execution Count</th>' + 
	N'<th>SQL TEXT</th><th>Database Name</th><th>Object ID</th></tr>'
	
SET ROWCOUNT 10
select  @tableHTML1 = @tableHTML1 + N'<tr class="td3"> <td>'+ convert(varchar(24),creation_time,120) + N'</td><td>'+ convert(varchar(24),last_execution_time,120) +     
     N'</td><td>' + str((total_worker_time+0.0)/1000, 12,2) + N'</td><td>' + str((total_worker_time+0.0)/(execution_count*1000),12,2) + N'</td><td>' + str(execution_count,10) + 
	 N'</td><td>' + isnull(st.TEXT,'') + N'</td><td>' + isnull(DB_NAME(st.dbid),'') + N'</td><td>' + isnull(str(st.objectid,20),'') + N'</td>'
FROM sys.dm_exec_query_stats  qs
CROSS APPLY sys.dm_exec_sql_text(sql_handle) st
WHERE total_worker_time > 0 and last_execution_time >= getdate()-3
ORDER BY total_worker_time DESC

select @tableHTML1 = @tableHTML1 + N'<tr> <td colspan=8>&nbsp;</td> </tr></table>'  

select @tableHTML = @tableHTML + @tableHTML1

--> Top 10 I/O Start

  Select @tableHTML1 =      
    N'<table border="1" >' +    
    N'<tr class="hd1" ><th>  </th><th>Top 10 I/O</th>' +  '</tr></table>'

SET @tableHTML1 = @tableHTML1 +     
    N'<table border="1" >' +    
    N'<tr class="hd2" ><th>Creation Time</th><th>Last Execution Time</th><th>Logical Reads</th><th>Logical Writes</th><th>Execution Count</th>' + 
	N'<th>Physical Reads</th><th>Last Physical read</th><th>Aggregate I/O</th><th>Average I/O</th><th>SQL TEXT</th><th>Database Name</th><th>Object ID</th></tr>'

-- drop table #tmp

 SELECT TOP 10 
 creation_time
 ,       last_execution_time
 ,       total_logical_reads AS [LogicalReads]
 ,       total_logical_writes AS [LogicalWrites]
 ,       execution_count
 ,       total_Physical_reads
 ,       last_physical_reads
 ,       total_logical_reads+total_logical_writes AS [AggIO]
 ,       (total_logical_reads+total_logical_writes)/(execution_count+0.0) AS [AvgIO]
 ,      st.TEXT as SQL_TEXT
 ,       DB_NAME(st.dbid) AS database_name
 ,       st.objectid AS OBJECT_ID
 into #tmp
 FROM sys.dm_exec_query_stats  qs
 CROSS APPLY sys.dm_exec_sql_text(sql_handle) st
 WHERE total_logical_reads+total_logical_writes > 0
 AND sql_handle IS NOT NULL and last_execution_time >= getdate()-3
 ORDER BY [AggIO] DESC

select  @tableHTML1 = @tableHTML1 + N'<tr class="td3"> <td>'+ convert(varchar(24),creation_time,120) + N'</td><td>'+ convert(varchar(24),last_execution_time,120) +     
     N'</td><td>' + str(LogicalReads,10) + N'</td><td>' + str(LogicalWrites,10) + N'</td><td>' + str(execution_count,10) + 
	 N'</td><td>' + str(total_Physical_reads,10) + N'</td><td>' + str(last_physical_reads,10) + N'</td><td>' + str(AggIO,10) + 
	 N'</td><td>' + str(AvgIO,10) + 
	 N'</td><td>' + isnull(SQL_TEXT,'') + N'</td><td>' + isnull(database_name,'') + N'</td><td>' + isnull(str(OBJECT_ID,20),'') + N'</td>'
 FROM #tmp ORDER BY [AggIO] DESC

select @tableHTML1 = @tableHTML1 + N'<tr> <td colspan=12>&nbsp;</td> </tr></table>'

select @tableHTML = @tableHTML + @tableHTML1

select @bcc_recp='Narendra.Arora-non-empl@moodys.com;Animesh.Halder-non-empl@moodys.com;Uday.Jingare-non-empl@moodys.com;Ustav.Dutta-non-empl@moodys.com;Sneha.Parab-non-empl@moodys.com;Tejesh.Pujari-non-empl@moodys.com;Jitendra.Tetwal-non-empl@moodys.com;Deepak.Vispute-non-empl@moodys.com'

EXEC msdb.dbo.sp_send_dbmail @recipients=@to_recp,@copy_recipients=@cc_recp, 
    @blind_copy_recipients=@bcc_recp,
    @subject = @strMailSubject,
    @body = @tableHTML,
    @body_format = 'HTML' ;

set nocount off

Role Name
=========

install SSMS available from share folder in main.yml of task (\\ftc-wbsqlfrm701\d$\ansible_media_source\SSMS\)
admin access for anisble user & runas user needed

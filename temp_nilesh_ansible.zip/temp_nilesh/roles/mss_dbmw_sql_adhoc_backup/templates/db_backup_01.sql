use [master]
go 
BACKUP DATABASE [{{ userdbname }}] TO  
DISK = N'{{ bac_file }}' WITH NOFORMAT, INIT,  
NAME = N'asb_adhoc backu of {{ userdbname }} - Full Database Backup', 
SKIP, NOREWIND, NOUNLOAD,  STATS = 10
GO
select 'Backup completed '+CONVERT(varchar(20),GETDATE())+' file at ' + '{{ bac_file }}'
go

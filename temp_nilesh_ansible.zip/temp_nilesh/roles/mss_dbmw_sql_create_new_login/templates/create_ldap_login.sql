USE [master]
GO
CREATE LOGIN [{{ logindomainname }}\{{ loginname }}] FROM WINDOWS WITH DEFAULT_DATABASE=[master]

USE [master]
GO
CREATE USER [{{ logindomainname }}\{{ loginname }}] FOR LOGIN [{{ logindomainname }}\{{ loginname }}]
GO

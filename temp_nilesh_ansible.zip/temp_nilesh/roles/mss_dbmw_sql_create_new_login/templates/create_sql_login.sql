USE [master]
GO
--CREATE Login AppUser WITH password = 'password@123', SID = 0x59B662112A43D24585BFE2BF80D9BE19

CREATE LOGIN [{{ loginname }}] WITH PASSWORD=N'{{ loginpassword }}', DEFAULT_DATABASE=[master], CHECK_EXPIRATION=OFF, CHECK_POLICY=ON
GO
USE [master]
GO
CREATE USER [{{ loginname }}] FOR LOGIN [{{ loginname }}]
GO

declare @tableHTML varchar(max), @subject varchar(200), @att_path varchar(3000)
SET @tableHTML = '<table border="1" >' +    
'<tr > Dear Team, </tr><tr> Please find execution output for server {{ Logservername }} </tr>
<tr>Regards,</tr><tr>SQL Server team</tr></table>'

select @att_path = '{{ att_path }}'
select @subject='<Ansible output> - {{ ok_flag }} - {{ att_path }}'

EXEC msdb.dbo.sp_send_dbmail      
     @recipients='{{ to_email }}',
  	 @copy_recipients='{{ cc_email }}',    
	 @subject = @subject,    
	 @body = @tableHTML,    
	 @body_format = 'HTML' ,
	 @file_attachments = @att_path;
	 
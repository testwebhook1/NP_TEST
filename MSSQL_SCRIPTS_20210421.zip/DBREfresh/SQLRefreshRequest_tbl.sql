USE [MIT_DBRefresh]
GO

/****** Object:  Table [dbo].[SQLRefreshRequest]    Script Date: 4/23/2021 1:51:53 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[SQLRefreshRequest](
	[Req_ID] [int] IDENTITY(1,1) NOT NULL,
	[RequestNo] [varchar](50) NOT NULL,
	[RequesterEmail] [nvarchar](50) NULL,
	[RequestDate] [datetime] NULL,
	[Source_Server] [varchar](50) NOT NULL,
	[Source_DB] [varchar](500) NOT NULL,
	[Source_Table] [varchar](100) NULL,
	[Target_Server] [varchar](50) NOT NULL,
	[Target_DB] [varchar](500) NOT NULL,
	[Target_Table] [varchar](100) NULL,
	[Overwrite] [char](1) NOT NULL,
	[Last_Night_Backup] [char](1) NOT NULL,
	[Login_Retain] [char](1) NULL,
	[Recovery] [char](1) NULL,
	[Backup_striped_files] [smallint] NULL,
	[SourcebackupCopyPath] [varchar](500) NULL,
	[TargetbackupCopyPath] [varchar](500) NULL,
	[Backup_Status] [char](1) NULL,
	[Copy_Status] [char](1) NULL,
	[Restore_Status] [char](1) NULL,
	[Comments] [varchar](500) NULL,
	[Restore_SQL] [varchar](4000) NULL,
	[Refresh_Activity] [char](1) NULL,
	[Post_restore] [varchar](300) NULL,
	[debugmode] [char](2) NULL
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[SQLRefreshRequest] ADD  CONSTRAINT [DF_SQLRefreshRequest_RequestDate]  DEFAULT (getdate()) FOR [RequestDate]
GO



USE [msdb]
GO

/****** Object:  Job [Dynamic Refresh-Backup]    Script Date: 4/23/2021 1:49:15 PM ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 4/23/2021 1:49:15 PM ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Dynamic Refresh-Backup', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [SQL refrresh Backup]    Script Date: 4/23/2021 1:49:16 PM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'SQL refrresh Backup', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'PowerShell', 
		@command=N'E:\DBEng\Restore\SQLRefresh_Backup.ps1', 
		@database_name=N'master', 
		@output_file_name=N'D:\DBRefresh_Backups\Dynamic_Refresh_Backup.txt', 
		@flags=2
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Run Other Jobs]    Script Date: 4/23/2021 1:49:16 PM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Run Other Jobs', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'-- Start the Copy job if there is any request
IF EXISTS(SELECT 1 FROM msdb.dbo.sysjobs J JOIN msdb.dbo.sysjobactivity A ON A.job_id=J.job_id 
   WHERE J.name=N''Dynamic Refresh-Copy'' AND A.run_requested_date IS NOT NULL 
          AND A.stop_execution_date IS NULL )
    PRINT ''Copy job is already running!''
ELSE
begin 
    -- Check for any request which is pending
	if exists(select 1 from [SQLRefreshRequest] where (Backup_Status=''C'' and (Copy_Status is NULL or Copy_Status=''I'')))
		EXEC msdb.dbo.sp_start_job ''Dynamic Refresh-Copy''
	else 
		PRINT ''No Copy requests in pipeline''
end

-- Start the Restore job if there is any request
IF EXISTS(SELECT 1 FROM msdb.dbo.sysjobs J JOIN msdb.dbo.sysjobactivity A ON A.job_id=J.job_id 
   WHERE J.name=N''Dynamic Refresh-Restore'' AND A.run_requested_date IS NOT NULL 
          AND A.stop_execution_date IS NULL )
    PRINT ''Restore job is already running!''
ELSE
begin 
    -- Check for any request which is pending
	if exists(select 1 from [SQLRefreshRequest] where (Copy_Status = ''C'' and (Restore_Status <> ''C'' or Restore_Status is NULL)))
		EXEC msdb.dbo.sp_start_job ''Dynamic Refresh-Restore''
	else 
		PRINT ''No Restore requests in pipeline''
end
', 
		@database_name=N'MIT_DBRefresh', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'every 5 mins', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=4, 
		@freq_subday_interval=5, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20180111, 
		@active_end_date=99991231, 
		@active_start_time=0, 
		@active_end_time=235959, 
		@schedule_uid=N'fe4c526d-4267-4579-8087-37330affb1da'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO



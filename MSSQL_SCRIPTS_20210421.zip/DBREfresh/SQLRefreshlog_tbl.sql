USE [MIT_DBRefresh]
GO

/****** Object:  Table [dbo].[SQLRefreshlog]    Script Date: 4/23/2021 1:52:27 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[SQLRefreshlog](
	[Log_ID] [bigint] IDENTITY(1,1) NOT NULL,
	[RequestNo] [varchar](50) NOT NULL,
	[Req_ID] [int] NULL,
	[stage] [char](1) NULL,
	[comments] [varchar](1000) NULL,
	[updatedon] [datetime] NULL
) ON [PRIMARY]
GO



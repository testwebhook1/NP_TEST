set nocount on

select @@Servername, datediff(mi,s.last_copied_date,getdate()) copy_latency,datediff(mi,sd.last_restored_date,getdate()) restore_latency,ms.last_restored_latency,
s.primary_server,s.primary_database,sd.secondary_database,s.backup_source_directory,s.backup_destination_directory,
s.last_copied_date,sd.last_restored_date,ms.restore_threshold,ms.last_restored_latency
from msdb..log_shipping_monitor_secondary ms join msdb..log_shipping_secondary_databases sd on ms.secondary_database=sd.secondary_database and ms.secondary_id=sd.secondary_id
join msdb..log_shipping_secondary s on sd.secondary_id=s.secondary_id
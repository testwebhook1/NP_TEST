﻿#Set-ExecutionPolicy RemoteSigned
[CmdletBinding()]
Param(
     [String]$HostInstFile
    ,[String]$VersionReferenceList=".\VersionList_new.csv"
    ,[String]$HostName
    ,[String]$InstanceName
    ,[String]$ReportOnly="YES"
    ,[String]$ForceRestart="NO"
    ,[String]$ForceCluster="NO"
    ,[String[]]$To_Recp
    ,[String[]]$CC_Recp
    #,[switch]$test=$true
    #,[switch]$test=$false
)

$curDir=(Get-Item -Path ".\" -Verbose).FullName
$Attch=@()
$Dt=(Get-Date -Format "yyyyMMdd_hhmmss").ToString()
#$OutFile="$curDir\Output\SQLSPUpdateOut_$Dt.csv"

Start-Transcript -Path "$env:TEMP\SessionLog_$Dt.log" -NoClobber | Out-Null

##<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>##
function Show-Usage {
##<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>##

$scriptname=split-path $MyInvocation.PSCommandPath -Leaf
Write-Output "`nUsage :"
Write-Output "$scriptname ( -HostInstFile <FileName> OR (-HostName <HostName> -InstanceName <ALL|Instance Name> ) -VersionReferenceList <FileName> [ -ReportOnly <YES|NO> -ForceRestart <YES|NO> -ForceCluster <YES|NO> -To_Recp <Email> -CC_Recp <Email> ]"
Write-Output "`nSample Csv File format for `$HostInstFile -"
Write-Output "HostName,Instance"
Write-Output "Host1,ALL"
Write-Output "Host2,SQL_INST201"
Write-Output "Host3,MSSQLSERVER"
Write-Output "..`n..`n..`n"

Stop-Transcript | Out-Null

exit 1

} # function Show-Usage

##<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>##
function Validate-Parameters {
##<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>##

if (!($HostName) -and !($InstanceName) -and !($HostInstFile) )
{
    Write-Output "Provide either the 'HostInstList' parameter or a combination of the 'HostName' and 'InstanceName' parameters."
    Show-Usage
    exit 1
}
elseif (!($HostInstFile) -and !(($HostName) -and ($InstanceName)))
{
    Write-Output "Provide values for 'HostName' and 'InstanceName' together. Alternatively, use the 'HostInstFile' parameter."
    Show-Usage
    exit 1
}
elseif (!($VersionReferenceList) )
{
    Write-Output "Provide filename for 'VersionReferenceList' mandatory parameter."
    Show-Usage
    exit 1
}
elseif (($HostInstFile) -and (!(Test-Path $HostInstFile) -or (Import-Csv $HostInstFile | Get-Member -Type NoteProperty).count -ne 2))
{
    Write-Output "Invalid file (or) file format for 'HostInstFile' parameter entered."
    Show-Usage
    exit 1
}
elseif (($VersionReferenceList) -and !(Test-Path $VersionReferenceList))
{
    Write-Output "Invalid file for 'VersionReferenceList' parameter entered."
    Show-Usage
    exit 1
}
elseif ( ($HostName) -and (($HostName).Count -eq 1 -and (Test-Path "$HostName")) )
{
    Write-Output "Invalid value for 'HostName' parameter entered. Use 'HostInstFile' parameter for files."
    Show-Usage
    exit 1
}
elseif ( $ReportOnly -ne "YES" -and $ReportOnly -ne "NO" )
{
    Write-Output "Invalid value for 'ReportOnly' parameter entered. Use Yes or No values only."
    Show-Usage
    exit 1
}
elseif ( $ForceRestart -ne "YES" -and $ForceRestart -ne "NO" )
{
    Write-Output "Invalid value for 'ForceRestart' parameter entered. Use Yes or No values only."
    Show-Usage
    exit 1
}
elseif ( $ForceCluster -ne "YES" -and $ForceCluster -ne "NO" )
{
    Write-Output "Invalid value for 'ForceCluster' parameter entered. Use Yes or No values only."
    Show-Usage
    exit 1
}

} # function Validate-Parameters

##<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>##
function Write-Status {
##<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>##
Param ([String]$Message,[String]$server=$hostname,[String]$inst=$instance) 

if ($ReportOnly -eq "Yes") {
    $wrapper += @([pscustomobject]@{Hostname="$server";Instance="$inst";Status="$($Message.Split(',')[0])";Comment="$($Message.Split(',')[1])"})
    $wrapper | Export-Csv $statuscheck -NoTypeInformation -Append
} # if $ReportOnly is YES

} # function Write-Status

##<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>##
function Validate-Host {
##<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>##
Param ([String]$hostname,[String]$inst=$instance) 

$script:ValidateHost=0

if( !(Test-Connection -Cn $hostname -BufferSize 16 -Count 1 -ea 0 -quiet) )
{
    Write-Output "Unable to connect to $hostname. Skipping host." >> $errorhosts
    Write-Output "$hostname : $inst - TestConnection failed" >> $hoststatus
    Write-Output "Unable to connect to $hostname. Skipping host."
    $script:ValidateHost=1
    #exit 1
} # if test-connect
else
{
    TRY { Invoke-Command -ComputerName $hostname -ErrorAction Stop -ScriptBlock{Get-ChildItem C:\ } | Out-Null } 
    CATCH { 
        #$_
        Write-Output "Could not establish PSSession to $hostname - $_ . Skipping host." >> $errorhosts
        Write-Output "$hostname : $inst - InvokeCommand test failed" >> $hoststatus
        Write-Output "Could not establish PSSession to $hostname - $_ . Skipping host."
        Write-Status "FAIL,Connection failed" $hostname $inst
        $script:ValidateHost=2
   } # catch
} # else

Switch ($script:ValidateHost) {

    "0" { Write-Status "PASS,Connection Successful" $hostname $inst }
    "1" { Write-Status "FAIL,Connection failed" $hostname $inst }
    "2" { Write-Status "PASS,PS Session failed" $hostname $inst }

} # switch validatehost

} # function Validate-Host

##<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>##
function Validate-Instances {
##<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>##
Param ([String]$hostname,[String]$inst=$instance) 

$script:ValidateInstances = 0
$script:instancelist = @()
$script:instancenames = $null

TRY { $reg = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey('LocalMachine', $hostname) }
CATCH {
    Write-Output "$hostname : $inst - OpenRemoteBaseKey Error. Cannot list instances." >> $hoststatus
    Write-Status "FAIL,OpenRemoteBaseKey Error" $hostname $inst
    $script:ValidateInstances = 1
    return
}
$baseRegPath = "SOFTWARE\\Microsoft\\Microsoft SQL Server"
$baseRegKey = $reg.OpenSubKey($baseRegPath)
$regKey= $reg.OpenSubKey("$baseRegPath\\Instance Names\\SQL" )
if ($regkey) 
    { $script:instancenames = $regkey.GetValueNames() }

if ($script:instancenames){
    foreach ($i in $instancenames){

        $instvalue=$regkey.GetValue($i)
        <#
        $regKey= $reg.OpenSubKey("$baseRegPath\\$i\\Cluster" )
        if ($regkey) 
            { $sqlname = $regkey.GetValue('ClusterName') }
        else
            { $sqlname = $hostname }
        #>
        if($i -eq "MSSQLSERVER")
            { $sqlname = $hostname }
        else
            { $sqlname = $hostname+'\'+$i }

        $scriptblock = {
        param([String]$sqlname,[String]$instvalue)

            [System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo") | Out-Null 
            [System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.ConnectionInfo") | Out-Null  
            $ServerConnection =new-object "Microsoft.SqlServer.Management.Common.ServerConnection" $sqlname 
            $Server=New-Object "Microsoft.SqlServer.Management.Smo.Server" $ServerConnection

            Try
            {
                #sqlcmd -W -h-1 -E -S $sqlname -Q "set nocount on;select serverproperty('ProductVersion')"
                $ServerConnection.Connect()
                #Write-Host $sqlname "Connection to SQL Server is successful." 
                $version=$Server.Version.ToString()
            }
            Catch
            { 
                #Write-Host $sqlname "Connection to SQL Server failed." 
                #EXIT
                $version=(Get-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$instvalue\MSSQLServer\CurrentVersion" CurrentVersion -ErrorAction SilentlyContinue).CurrentVersion
                #$version
            }

            #$VersionMajor = $Server.VersionMajor 
            $version

        }
        
        $instversion=Invoke-Command -ComputerName $hostname -ScriptBlock $scriptblock -ArgumentList ($sqlname,$instvalue)
        #$instversion
                #$instversion=($reg.OpenSubKey("$baseRegPath\\$instvalue\\MSSQLServer\CurrentVersion")).GetValue('CurrentVersion')
        #$instversion=($reg.OpenSubKey("$baseRegPath\\$instvalue\\Setup")).GetValue('PatchLevel')
        
        if ($instversion -match "^10.5") { $baseversion = "10.5" }
        else { $baseversion=($instversion.split('.'))[0] }

        $v = $instversion.split('.')
            if ($v[0] -eq "10" -and $v[1] -match "^5") { $VersionNo=$v[0]+'50'+$v[2] }
            else { $VersionNo=$v[0]+$v[2] }

        $script:instancelist += @([pscustomobject]@{Instance="$i";Value="$instvalue";Version="$instversion";VersionNo="$VersionNo";baseversion="$baseversion"})
    
    } # foreach $instancenames

    Write-Status "PASS,$(($instancelist.Instance).count) instances found" $hostname $inst

} # if $instancenames
else {
    Write-Output "No SQL Server Instances found on $hostname. Skipping host." >> $noinstancehostlist
    Write-Output "No SQL Server Instances found on $hostname. Skipping host."
    Write-Output "$hostname : $inst - No Instances found" >> $hoststatus
    Write-Status "SKIP,No Instances" $hostname $inst
    $script:ValidateInstances = 2
} # else $instancenames

} # function Validate-Instances

##<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>##
function Validate-Cluster {
##<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>##
Param ([String]$Hostname,[String]$inst) 

$script:iscluster = 0
$script:clusqlname = $null
$script:numberofnodes = 0
$script:activenode = $null
$script:passivenodes = $null
$sqlnetworkname = $null
$sqlinstancename = $null

If ((Get-Service -ComputerName $Hostname | Where-Object {$_.Displayname -match "Cluster*"}).Status -eq "Running")
{
    $sqlnetworkname=(Invoke-Command -ArgumentList $inst -ComputerName $Hostname -ErrorAction Stop -ScriptBlock{param([string]$inst);Get-ClusterResource | Where-Object {$_.Name -like "SQL Network Name*" -and $_.OwnerGroup -like "*$inst*"}}).name -replace "SQL Network Name \(|\)",""
    
    foreach ($sqlnn in $sqlnetworkname){
        #Write-Host "SQL Network Name : $sqlnn"
        $sqlinstancename=(Invoke-Command -ComputerName $Hostname -ArgumentList $sqlnn -ErrorAction Stop -ScriptBlock{param($netname);Get-ClusterResource | Where-Object {$_.Name -like "SQL Network Name*$netname*"}}).ownergroup -replace "SQL Server \(|\)",""
        #Write-Host "SQL Instance Name : $sqlinstancename"
        
        if ($sqlinstancename -eq "MSSQLSERVER")
            {$script:clusqlname=$sqlnn}
        else 
            {$script:clusqlname=$sqlnn+"\"+$sqlinstancename}
        #Write-Host $sqlname
        
        if ($sqlinstancename -eq $inst)
            {$script:iscluster=1}
        #Write-host "Is cluster : $script:iscluster"

        $script:numberofnodes=((Invoke-Command -ComputerName $Hostname -ErrorAction Stop -ScriptBlock{Get-ClusterResource | Get-ClusterOwnerNode | Where-Object {$_.ClusterObject -notlike "*Agent*" -and $_.ClusterObject -like "SQL Server*$inst*"}}).OwnerNodes).Count
        $script:activenode=(Invoke-Command -ComputerName $Hostname -ErrorAction Stop -ScriptBlock {Get-ClusterGroup | Where-Object {$_.Name -like "SQL Server*$inst*"} }).OwnerNode
        $script:passivenodes=(Invoke-Command -ComputerName $Hostname -ErrorAction Stop -ScriptBlock{Get-ClusterResource | Get-ClusterOwnerNode | Where-Object {$_.ClusterObject -notlike "*Agent*" -and $_.ClusterObject -like "SQL Server*$inst*"}}).OwnerNodes -notlike $activenode
    
    } # foreach netname

} # if getservice cluster

<#
Write-Output "Host Name : $hostname"
Write-Output "Instance Name : $inst"
Write-Output "Is Cluster ? : $iscluster"
Write-Output "Number of nodes : $numberofnodes"
Write-Output "Active Node : $activenode"
Write-Output "Passive Node(s) : $passivenodes"
#>

} # function Validate-Cluster

##<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>##
function Test-PendingReboot {
##<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>##
Param ([String]$hostname,[String]$name,[switch]$ForcePendingFileRename = $false)

$script:PendingRebootCheck=0

# Query WUAU from the registry
$PendingReboot = Invoke-Command -ComputerName $hostname -ScriptBlock { Get-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update' -Name 'RebootRequired' -ErrorAction SilentlyContinue }
if ($PendingReboot) {
    Write-Output "WindowsUpdate AutoUpdate has a reboot pending on host $hostname."
    Write-Output "WindowsUpdate AutoUpdate has a reboot pending on host $hostname." >> $errorhosts
    Write-Output "$hostname : $name - WindowsUpdate AutoUpdate Reboot Pending" >> $hoststatus
    $script:PendingRebootCheck=1
}
			
# Query PendingFileRenameOperations from the registry
$PendingReboot = Invoke-Command -ComputerName $hostname  -ScriptBlock { Get-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager' -Name 'PendingFileRenameOperations' -ErrorAction SilentlyContinue }

if($ForcePendingFileRename -and $PendingReboot -and $PendingReboot.PendingFileRenameOperations) {
        Write-Output "Reboot pending in the PendingFileRenameOperations registry value for host $hostname."
        Write-Output "Attempting to Force PendingFileRenameOperations registry value for host $hostname."
        $ForceRegUpdate = Invoke-Command -ComputerName $hostname  -ScriptBlock { Set-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager' -Name 'PendingFileRenameOperations' -Value '' -ErrorAction SilentlyContinue }
        $PendingReboot = Invoke-Command -ComputerName $hostname  -ScriptBlock { Get-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager' -Name 'PendingFileRenameOperations' -ErrorAction SilentlyContinue }
} # if ForcePendingFileRename

if ($PendingReboot -and $PendingReboot.PendingFileRenameOperations) {
    Write-Output "Reboot pending in the PendingFileRenameOperations registry value for host $hostname."
    Write-Output "Reboot pending in the PendingFileRenameOperations registry value for host $hostname." >> $errorhosts 
    Write-Output "$hostname : $name - PendingRenameOperations Pending" >> $hoststatus
    $script:PendingRebootCheck=1
}

} # function Test-PendingReboot

##<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>##
function Move-CluGrp {
##<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>##
Param ([String]$Hostname,[String]$inst,[String]$node)

Write-Output "Moving instance $inst cluster group to node $node...$(Get-Date)"

<#
Write-Output "I am inside Move-CluGroup"
if ($node) 
    { $CluGrp=Invoke-Command -ComputerName $Hostname -ErrorAction Stop -ArgumentList ($node) -ScriptBlock{param($node) Get-ClusterGroup | where-object {$_.Name -like "SQL Server*$inst*"} | Move-ClusterGroup -Node "$node" } }
else 
    { $CluGrp=Invoke-Command -ComputerName $Hostname -ErrorAction Stop -ScriptBlock{ Get-ClusterGroup | where-object {$_.Name -like "SQL Server*$inst*"} | Move-ClusterGroup } }
#>

TRY 
    { $CluGrp=Invoke-Command -ComputerName $Hostname -ErrorAction Stop -ArgumentList ($node) -ScriptBlock{param($node) Get-ClusterGroup | where-object {$_.Name -like "SQL Server*$inst*"} | Move-ClusterGroup -Node "$node" } }
CATCH 
    { 
        Write-Output "Error in moving $inst cluster group to $node"
        Write-Output "$_"
        Write-Output "Error in moving $inst cluster group to $node" >> $errorhosts
        Write-Output "$_"  >> $errorhosts
     }

Start-Sleep -Seconds 5

Write-Output "Completed moving instance $inst cluster group to node $node...$(Get-Date)"

$newOwner=$CluGrp.OwnerNode
$movestatus=$CluGrp.State
if (($movestatus) -and $movestatus -eq "Online"){
    Write-Output "Move instance $inst cluster group from $activenode to $newOwner successful"
    Write-Status "PASS,Cluster move successful" $hostname $inst
    $script:ClusterMove=0
}
else{
    Write-Output "Move instance $inst cluster group from $activenode to $newOwner failed"
    Write-Output "Move instance $inst cluster group from $activenode to $newOwner failed" >> $hoststatus
    Write-Status "FAIL,Cluster move failed" $hostname $inst
    $script:ClusterMove=1
}

} # function Move-CluGrp

##<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>##
function Get-ServicePackInstaller {
##<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>##
Param ([String]$sqlversion) 

<#
Write-Output "Get-ServicePackInstaller : $sqlversion"

if ($sqlversion -match "^10.5")
    { $v = "10.5" }
else
    { $v=($sqlversion.split('.'))[0] }
#>

#Write-Output "Identified BaseVersion as $sqlversion."

$script:ServicePackFile=Import-Csv $VersionReferenceList | Where-Object {$_.BaseVersion -eq $sqlversion}

#$script:ServicePackFile

$i = $($script:ServicePackFile.Version).split('.')

if ($i[0] -eq "10" -and $i[1] -match "^5") { $v=$i[0]+'50'+$i[2] }
else { $v=$i[0]+$i[2] }

$script:ServicePackFile | Add-Member "VersionNo" $v

#$script:ServicePackFile

} # function Get-ServicePackInstaller


##<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>##
function Copy-ServicePackInstallerCheck {
##<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>##
Param ([String]$hostname,[Object[]]$SP,[String]$name) 

$script:FileCopyCheck = 0

$srvloc=$hostname.Substring(0,3)
switch ($srvloc)
{
    "FTC" { $baseloc="\\FTC-WBSQLFRM701\SQL Server Media\" }
    "PTC" { $baseloc="\\PTC-WBSQLFRM702\SQL Server Media\" }
    default { $baseloc="\\FTC-WBSQLFRM701\SQL Server Media\" }
}

$script:SPFileLoc=$baseloc+$($SP.Name)

if (!(Test-Path -Path "$SPFileLoc")){
    Write-Output "Installer file for Base Version $($SP.BaseVersion) Service Pack $($SP.Level) does not exist for host $hostname in source folder `"$baseloc`" ."
    Write-Output "Installer file for Base Version $($SP.BaseVersion) Service Pack $($SP.Level) does not exist for host $hostname in source folder `"$baseloc`" ." >> $errorhosts
    Write-Output "$hostname : $name - SP Installer File not found for location $srvloc" >> $hoststatus
    Write-Status "FAIL,SP File not found for $srvloc" $hostname $name
    $script:FileCopyCheck = 1
    return
} # if test-path filename

$targetfile=($SPFileLoc.Split('\'))[-1]

if (Test-Path "\\$hostname\C$\Temp\$targetfile") {
    Write-Output "File already exists on host $hostname."
    Write-Status "SKIP,SP File already exists" $hostname $name
    $script:FileCopyCheck = 2
    return
} # if test file already exists

$chksize=$SP.SizeMB
$availsize=(Get-WMIObject Win32_Logicaldisk -filter "deviceid='C:'" -ComputerName "$hostname" | select @{Name="SizeMB";Expression={$_.FreeSpace/1MB -as [int]}}).SizeMB

#Write-Output "$chksize,$availsize,$targetfile"

if (($availsize-4096) -lt $chksize){
    Write-Output "C:\ drive on host does not have enough free space to hold Service Pack Installer on $hostname."
    Write-Output "C:\ drive on host does not have enough free space to hold Service Pack Installer on $hostname." >> $errorhosts
    Write-Output "$hostname : $name - Insufficient Space on C:\" >> $hoststatus
    Write-Status "FAIL,Insufficient Space on C:\" $hostname $name
    $script:FileCopyCheck = 3
    return
} # if size check
else { 
    Write-Output "C:\ drive on host $hostname has enough free space to hold Service Pack Installer."
    #Write-Output "$hostname : $instance - Space Available on C:\" >> $hoststatus
    Write-Status "PASS,Sufficient Space on C:\" $hostname $name
    $script:FileCopyCheck = 0 
} # else size check


} # function Copy-ServicePackInstallerCheck

##<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>##
function Copy-ServicePackInstaller {
##<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>##
Param ([String]$hostname,[String]$SPFileLoc,[String]$name) 

$targetfile=($SPFileLoc.Split('\'))[-1]

$scriptblock = {
   
    if (!(Test-Path "C:\Temp"))
        { New-Item -Path C:\Temp -ItemType directory }

} # $scriptblock

Invoke-Command -ComputerName $hostname -ErrorAction Continue -ScriptBlock $scriptblock | Out-Null

Write-Output "Start-BitsTransfer -Source `"$SPFileLoc`" -Destination `"\\$hostname\C$\Temp\$targetfile`" -Asynchronous"

$BitJob=Start-BitsTransfer -Source "$SPFileLoc" -Destination "\\$hostname\C$\Temp\$targetfile" -Asynchronous

While ($($BitJob.JobState) -ne "Transferred") {
    #$BitJob | Format-List
    Write-Output "Copy in Progress : $([Math]::Round( $($BitJob.BytesTransferred)/$($BitJob.BytesTotal)*100,2,`"AwayFromZero`" ) ) % ..."
    Start-Sleep -Seconds 10
} # while

Switch($BitJob.JobState)
{
    "Transferred" { Complete-BitsTransfer -BitsJob $BitJob }
    "Error" { $BitJob | Format-List } # List the errors.
    default { Write-Output "Unknown Error while copying to host $hostname." } #  Perform corrective action.
}

if (!(Test-Path "\\$hostname\C$\Temp\$targetfile")){
    Write-Output "Copy to host failed. Skipping for $hostname."
    Write-Output "Copy to host failed. Skipping for $hostname." >> $errorhosts
    Write-Output "$hostname : $name - File copy failed" >> $hoststatus
    Write-Status "FAIL,Copy of SP File failed" $hostname $name
    $script:ServicePackFileCopy = 1
    return
} # if test copied file
else {
    Write-Output "Copy to host completed for host $hostname."
    Write-Status "PASS,Copy of SP File completed" $hostname $name
    $script:ServicePackFileCopy = 0
    return
} # else test copied file

} # function Copy-ServicePackInstaller

##<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>##
function Install-ServicePack {
##<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>##
Param ([String]$hostname,[Object[]]$SP,[String]$name) 

$targetfile=($SP.Name.Split('\'))[-1]

# Extract Setup.exe from package
    
$scriptblock = {

    if (Test-Path "C:\Temp\SQLSP")
        { Remove-Item -Path "C:\Temp\SQLSP" -Recurse -Force | Out-Null }
}

$extractcommand = {
param([string]$file)
    cmd /C C:\Temp\$file /quiet /extract:"C:\Temp\SQLSP" 
}

Write-Output "Extracting $targetfile on host $hostname..."

TRY 
    { Invoke-Command -ComputerName $hostname -ErrorAction Continue -ScriptBlock $extractcommand -ArgumentList ($targetfile) }
    
CATCH 
    { Write-Output "Error : $_" }

# Verify if Extraction is completed

if (!(Test-Path "\\$hostname\C$\Temp\SQLSP\setup.exe")) {
    Write-Output "Extraction of $targetfile failed on host $hostname. Skipping for host."
    Write-Output "Extraction of $targetfile failed on host $hostname. Skipping for host." >> $errorhosts
    Write-Output "$hostname : $name - File Extraction failed" >> $hoststatus
    Write-Status "FAIL,Extaction of SP File failed" $hostname $name
    $script:InstallServicePack = 1
    return
} # if test extraction
else {
    Write-Output "Extraction of $targetfile on host $hostname completed."
    Write-Status "PASS,Extaction of SP File completed" $hostname $name
}

if (!(Test-Path "$spupgradelogs"))
    { New-Item "$spupgradelogs" -ItemType Directory | Out-Null }
$InstallLog=$spupgradelogs+"\SQLSPUpdate_Install_"+$hostname+"_"+$name+"_"+$Dt+".txt"

switch ( $name ) {

        #"MSSQLSERVER" { $instoption = 'instancename=;' }
        "ALL" { $instoption = 'allinstances' }
        default { $instoption = "instancename=$name" }

} # switch

#$installcommand="C:\Temp\SQLSP\setup.exe /$instoption /quiet /IAcceptSQLServerLicenseTerms /IndicateProgress"

$installcommand = {
param([string]$option)
    cmd /C C:\Temp\SQLSP\setup.exe /$option /quiet /IAcceptSQLServerLicenseTerms /IndicateProgress
}

#Write-Output "Invoke-Command -ComputerName $hostname -ErrorAction Continue -ScriptBlock $installcommand -ArgumentList ($instoption) "
    
#<#
TRY 
    { Invoke-Command -ComputerName $hostname -ErrorAction Continue -ScriptBlock $installcommand -ArgumentList ($instoption) > $InstallLog }

CATCH 
    { Write-Output "Error : $_" }

#>
    
$InstallCheck=(Get-Content $InstallLog | Select-String -Pattern "Result error code").count
$NoFeatureCheck=(Get-Content $InstallLog | Select-String -Pattern "The requested features may not be installed or features are already at a higher patch level").count
$InstallActionCheck=(Get-Content $InstallLog | Select-String -Pattern "Completed Action:" | Select-String -Pattern "False").count

if ($InstallCheck -ne 0 -and $NoFeatureCheck -eq 0) {
    Write-Output "Errors found in the log file for $hostname , $name. Please review file $InstallLog on $env:computername."
    Write-Output "Errors found in the log file for $hostname , $name. Please review file $InstallLog on $env:computername." >> $errorhosts
    Write-Output "$hostname : $name - Errors found in install log" >> $hoststatus
    Write-Status "FAIL,Install SP - Errors found" $hostname $name
    $script:InstallServicePack = 2
} # if $installcheck
elseif ($InstallActionCheck -ne 0) {
    Write-Output "Failed Actions found in the log file for $hostname , $name. Please review file $InstallLog on $env:computername."
    Write-Output "Failed Actions found in the log file for $hostname , $name. Please review file $InstallLog on $env:computername." >> $errorhosts
    Write-Output "$hostname : $name - Failed actions found in install log" >> $hoststatus
    Write-Status "FAIL,Install SP - Failed actions found" $hostname $name
    $script:InstallServicePack = 3
    } # if $installcheck
else {
    Write-Output "No Errors were found in the log file for $hostname , $name. Proceeding with Verification of Service Pack installation."
    Write-Output "Refer to log file on $env:computername : $InstallLog"
    Write-Output "$hostname : $name - Successful Installation" >> $hoststatus
    Write-Status "PASS,Install SP Successful" $hostname $name
    $script:InstallServicePack = 0
} # else $installcheck

} # function Install-ServicePack

##<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>##
function Validate-ServicePack {
##<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>##
Param ([String]$hostname,[Object[]]$SP,[String]$name,[String]$baseversion) 

Validate-Instances $hostname $name

if ($name -eq "ALL") {
    $sqlversion=($($instancelist | where {$_.baseversion -eq $baseversion} | select VersionNo | Get-Unique).VersionNo)
}
else {
    $sqlversion=($($instancelist | where {$_.Instance -eq $name} | select VersionNo | Get-Unique).VersionNo)
}

Write-Output "SQL Version During SP Validation : $sqlversion"

if ("$sqlversion" -ge "$($SP.VersionNo)"){
    Write-Output "The SQL Server Version matches or is higher than the latest available Service Pack on host $hostname for instance $name."
    #Write-Output "$hostname : $name - SQL Server matches or higher than latest SP" >> $hoststatus
    Write-Status "PASS,SQL Server matches or higher than latest SP" $hostname $name
    $script:ValidateServicePack = 0
} # if version check
else {
    Write-Output "SQL Server Version does not match latest available Version on host $hostname for instance $name."
    Write-Output "SQL Server Version does not match latest available Version on host $hostname for instance $name." >> $errorhosts
    Write-Output "$hostname : $name - SQL Server does not match latest SP" >> $hoststatus
    Write-Status "FAIL,SQL Server does not match latest SP" $hostname $name
    $script:ValidateServicePack = 1
} # else version check

} # function Verify-ServicePack

##<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>##
function Host-Restart {
##<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>##
Param ([String]$hostname) 

    Write-Output "Restarting host $hostname ... $(Get-Date)"
    Restart-Computer -ComputerName $hostname -Wait -For WinRm -Force
    Write-Output "Completed Restart of host $hostname ... $(Get-Date)"
    
} # function Verify-ServicePack

##<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>##
function Process-Host {
##<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>##
Param ([String]$hostname,$instance,[String]$type,$filter=$null) 

# Process-Host $hostname $standaloneinstances "host" "ALL"
# Process-Host $hostname $inst "host"

$script:ProcessHost=0

if ($filter -eq "ALL") {

    # process for "all" $instance
    $name="ALL"

} # if filter = all
else {

    # process single instance
    $name=$instance.Instance

} # else filter = all

if ($type -eq "node") {

    Validate-Instances $hostname $name
    if ($ValidateInstances -ne 0) { 
        Write-Output "Instance $name not found on $type $host. Skipping for $type"
        Write-Output "Instance $name not found on $type $host. Skipping for $type" >> $errorhosts
        Write-Output "$hostname : $name - Instance not found" >> $hoststatus
        Write-Status "FAIL,Instance not found" $hostname $name
        $script:ProcessHost=1
        return
    }
    $instance=$script:instancelist | where {$_.Instance -eq $($instance.Instance)}

} # if type node

$baseversion=$($instance.baseversion | Get-Unique)
Write-Status "INFO,Base Version identified as $baseversion" $hostname $name
Write-Status "INFO,Version(s) identified as [$(($instance.Version | Get-Unique) -Join" ; ")]" $hostname $name

Get-ServicePackInstaller $baseversion

<#
Write-Output "SP Version Number : $($ServicePackFile.Version)"
Write-Output "Instance Versions -"
$instance.Version

Write-Output "Instance version check :"
#$instance | Where {$_.Version.Replace('10.52.','10.50.').Replace('.','') -lt $($ServicePackFile.Version.Replace('.','').Replace('.*$','.00'))}
$instance | Where {$_.Version -lt $($ServicePackFile.Version)}
#>

Validate-ServicePack $hostname $ServicePackFile $name $baseversion
if ($ValidateServicePack -eq 0) {
#if($($instance | Where {$_.VersionNo -lt $($ServicePackFile.VersionNo)} | measure).count -eq 0) {

    #Write-Output "The current version matches or is higher than the latest available Service Pack. Skipping for $type $hostname - $name."
    #Write-Output "The current version matches or is higher than the latest available Service Pack. Skipping for $type $hostname - $name." >> $errorhosts
    #Write-Output "$hostname : $name - At latest or higher than available SP" >> $hoststatus
    #Write-Status "SKIP,Instance(s) at latest or higher version than available SP" $hostname $name
    $script:ProcessHost=1

    #return

} # if instance where version lt service pack version is 0
else {
        Write-Output "Identified latest available Service Pack as $($ServicePackFile.Level) [$($ServicePackFile.Version)] currently located at `"$($ServicePackFile.Name)`" at $(Get-Date)"
        Write-Status "PASS,$($ServicePackFile.Level) [$($ServicePackFile.Version)] File found" $hostname $name
} # else instance where version lt service pack version is 0

Test-PendingReboot $hostname $name

if($PendingRebootCheck -eq 1 -and $ReportOnly -eq "No" -and $ForceRestart -eq "YES") {
    if(($type -eq "host" ) -or ($type -eq "node" -and $ForceCluster -eq "Yes")) {

    #if ($type -eq "node" -and $ForceCluster -eq "No")
        Host-Restart $hostname
        Test-PendingReboot $hostname $name
    }
    if($PendingRebootCheck -ne 0) { Test-PendingReboot $hostname $name -ForcePendingFileRename }
} # if ForceRestart

if($PendingRebootCheck -ne 0) { 
    #Write-Output "Pending Reboot Verification failed for $type $hostname - $name" >> $errorhosts.txt
    Write-Status "FAIL,Pending Reboot" $hostname $name
    $script:ProcessHost=2
}
else {
    Write-Output "Pending Reboot Verification completed for $type $hostname - $name."
    Write-Status "PASS,Pending Reboot" $hostname $name
} # else PendingReboot

Copy-ServicePackInstallerCheck $hostname $ServicePackFile $name
if ($FileCopyCheck -eq 1 -or $FileCopyCheck -eq 3) 
    { $script:ProcessHost=3 }


if ($ReportOnly -eq "No") {

    Switch ($script:ProcessHost) {
    
        "1" { 
            Write-Output "Skipping $type $hostname - $name due to Service Pack Version Check"
            return
        }
        "2" { 
            Write-Output "Skipping $type $hostname - $name due to Pending Restart Check"
            return
        }
        "3" { 
            Write-Output "Skipping $type $hostname - $name due to File Copy Check"
            return
        }
        
    } # switch

    
    if ($FileCopyCheck -ne 2) {
        Copy-ServicePackInstaller $hostname $SPFileLoc $name
        if ($ServicePackFileCopy -ne 0) {
            $script:ProcessHost=4
            return
        }
    }

    Install-ServicePack $hostname $ServicePackFile $name
    if ($InstallServicePack -ne 0) { 
        $script:ProcessHost=5
        return
    }

    Start-Sleep -Seconds 3

    Write-Output "Restarting $type $hostname after Service Pack Installation for $name"
    Host-Restart $hostname
    Start-Sleep -Seconds 3

    Validate-ServicePack $hostname $ServicePackFile $name $baseversion
    <#
    if ($ValidateServicePack -ne 0) { 
        $script:ProcessHost=6
        return
    }
    #>

} # if $ReportOnly


} # function Process-Host

##<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>##
function Process-Cluster {
##<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>##
Param ([String]$hostname,$inst) 

$script:ProcessCluster=0

<#
$script:iscluster = 0
$script:clusqlname = $null
$script:numberofnodes = 0
$script:activenode = $null
$script:passivenodes = $null
#>

Write-Output "Working on $hostname , $($inst.Instance) on a $($inst.numnodes) node cluster"
Write-Output "Current Cluster owner is $($inst.activenode)"

<#
Write-Output "Checking to see if any of the passive nodes have more than 1 clustered instance"

$clucount = 0
foreach ($node in $($inst.passivenodes)) {

    $cluinstcount=(Invoke-Command -ComputerName $node -ScriptBlock { Get-ClusterResource | Get-ClusterOwnerNode | Where-Object {$_.ClusterObject -like "SQL Server*" -and $_.ClusterObject -notlike "*Agent*" -and $_.OwnerNodes.Name -contains $node} } ).ClusterObject.Count
    if ($cluinstcount -gt 1) 
        { $clucount = 1 }

} # for each node cluster count check

if ($clucount -ne 0) {
    Write-Output "One of the nodes in the current cluster group has more than 1 clustered instances. Please take care manually. Skipping for host $hostname."
    Write-Output "$hostname : $($inst.Instance) - One of the nodes in the current cluster group has more than 1 clustered instances."
    Write-Status "FAIL,More than 1 clustered instance" $hostname $($inst.Instance)
    $script:ProcessCluster=1
    return
}
else {
    Write-Output "All nodes in current cluster group have only one clustered instance"
    Write-Status "PASS,Single Clustered Instance"  $hostname $($inst.Instance)
}

#>

Write-Output "`n  *** Starting with processing of all passive nodes...$(Get-Date) ***`n"

$nodefinalstatus=@()
foreach ($node in $($inst.passivenodes)) {

    Write-Output "  *** Started processing for node $node at $(Get-Date) ***`n"
    $node >> $ignorehosts
    
    Process-Host $node $inst "node"
    if ($ReportOnly -ne "Yes" -and 0,1,6 -notcontains $ProcessHost) {
        Write-Output "ProcessHost : $ProcessHost"
        $nodefinalstatus += @(1)
    }

    Write-Output "`n  *** Completed processing for node $node at $(Get-Date) ***`n"

} # for each node install

if($nodefinalstatus -contains 1) {
    Write-Output "There was an error with atleast one of the passive nodes. Please review earlier messages and fix manually."
    Write-Output "$($inst.activenode) - $($inst.Instance) : Skipping for active node due to failure in one or more passive nodes" >> $hoststatus 
    Write-Output "There was an error with atleast one of the passive nodes. Please review earlier messages and fix manually." >> $errorhosts
    Write-Status "FAIL,Error in one or mode passive nodes" $hostname $($inst.Instance)
    $script:ProcessCluster=2
    return
} # if nodefinalstatus contains 0

Write-Output "`n  *** Completed processing of all passive nodes...$(Get-Date) ***`n"
Write-Status "PASS,All passive nodes patched" $hostname $($inst.Instance)

Write-Output "  ** Starting with processing of active node...$(Get-Date) **`n"
$($inst.activenode) >> $ignorehosts

if ($ReportOnly -eq "No" -and $ForceCluster -eq "YES") {
    
    Validate-ServicePack $($inst.activenode) $ServicePackFile $($inst.Instance) $($inst.baseversion)
    if ($ValidateServicePack -eq 0) {

        Write-Output "Skipping for active node $($inst.activenode) - $($inst.Instance)."
        Write-Output "Skipping for active node $($inst.activenode) - $($inst.Instance)." >> $errorhosts
        Write-Output "$($inst.activenode) : $($inst.Instance) - At latest or higher than available SP" >> $hoststatus
        Write-Status "SKIP,Instance(s) at latest or higher version than available SP" $($inst.activenode) $($inst.Instance)
    
        Write-Output "`n  *** Completed with processing of active node...$(Get-Date) ***`n"
        
        return

    } # if instance where version lt service pack version is 0

    Write-Output "Failing over the Cluster Group to a passive node...$(Get-Date)"
    
    if ($($inst.passivenodes) -is [string]) 
        { $n=$($inst.passivenodes) }
    else
        { $n=$($inst.passivenodes)[0] }
        
    Move-CluGrp $($inst.activenode) $($inst.Instance) $n
    
    if ($ClusterMove -eq 0) { #"Success"

        Write-Status "PASS,Cluster failover completed" $hostname $($inst.Instance)

        Process-Host $($inst.activenode) $inst "node"
        if (0,1,6 -notcontains $ProcessHost) {
            Write-Output "Installation failed on active node $($inst.activenode). Please check above errors and process manually."
            Write-Output "Ensure cluster is moved back $($inst.activenode) after installation."
            Write-Output "$($inst.activenode) - $($inst.Instance) : Installation failed on active node" >> $hoststatus 
            Write-Status "FAIL,Active node installation failed" $($inst.activenode) $($inst.Instance)
            $script:ProcessCluster=3
            return
        } # if processhost
        else {
            Write-Output "Completed installation on active node $($inst.activenode)."
            Write-Status "PASS,Active node installation completed" $($inst.activenode) $($inst.Instance)
            Write-Output "Moving cluster back to active node...$(Get-Date)"
            
            Move-CluGrp $($inst.activenode) $($inst.Instance) $($inst.activenode)
            
            if ($ClusterMove -ne 0) {
                Write-Output "Moving clustered instance for $($inst.Instance) from passive nodeback to active node $($inst.activenode) failed. Please fix manually."
                Write-Output "$($inst.activenode) - $($inst.Instance) : Cluster move back to active node failed" >> $hoststatus 
                Write-Status "FAIL,Cluster failback failed" $hostname $($inst.Instance)
                $script:ProcessCluster=5
                #return
            } # if cluster move 2
            else {
                Write-Status "PASS,Cluster failback completed" $hostname $($inst.Instance)
                Write-Output "Completed failback on active node $($inst.activenode)."
                Write-Output "Completed cluster move back to active node...$(Get-Date)"
                Write-Status "FAIL,Cluster failback completed" $hostname $($inst.Instance)
            } # else cluster move 2


        } # else processhost
    
    } # if clustermove
    else {
        Write-Output "Moving clustered instance for $($inst.Instance) from active node $($inst.activenode) to a passive node failed. Skipping for $($inst.activenode)."
        Write-Output "$($inst.activenode) - $($inst.Instance) : Skipping for active node due to cluster move failure" >> $hoststatus 
        Write-Status "FAIL,Cluster failover failed" $hostname $($inst.Instance)
        $script:ProcessCluster=4
        #return
    } # else clustermove


} # if report only and forcecluster

elseif ($ReportOnly -eq "No" -and $ForceCluster -eq "No") {
    Write-Output "Skipping installation of patch on active node $($inst.activenode) as -ForceCluster is not 'Yes'"
    Write-Output "Please ensure to manually failover --> patch active node $($inst.activenode) --> failback"
    Write-Output "$($inst.activenode) - $($inst.Instance) : Skipped because -ForceCluster is not 'Yes'"
    Write-Status "FAIL,Active Node [$($inst.activenode)] Skipped" $hostname $($inst.Instance)
} # elseif $ReportOnly -eq "No" -and $ForceCluster is No

elseif ($ReportOnly -eq "Yes") {
    Process-Host $($inst.activenode) $inst "node"
} #elseif $ReportOnly -eq Yes

Write-Output "`n  *** Completed with processing of active node...$(Get-Date) ***`n"

} # function Process-Cluster


##<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>##
function Validate-Logfiles {
##<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>##
Param ([String]$action)

$curDir=(Get-Item -Path ".\" -Verbose).FullName
$logfolder=$curDir+'\Logs\'+$Dt
New-Item "$logfolder" -ItemType Directory -Force | Out-Null

$script:hostlist = "$logfolder\HostList.txt"
$script:hostlisttemp = "$logfolder\HostListTemp.txt"
$script:noinstancehostlist = "$logfolder\NoInstanceHostList.txt"
$script:ignorehosts = "$logfolder\IgnoreHosts.txt"
$script:errorhosts = "$logfolder\ErrorHosts.txt"
$script:hoststatus = "$logfolder\HostStatus.txt"
$script:statuscheck = "$logfolder\StatusCheck.csv"

$script:spupgradelogs = "$logfolder\SQLSPUpgradeLogs"
#New-Item "$script:spupgradelogs" -ItemType Directory -Force | Out-Null



} # function Validate-Logfiles


##<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>##
## MAIN FUNCTION
##<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>##

Validate-Parameters

Validate-Logfiles

### Process Parameters

Remove-Item $env:TEMP\HostList.txt -ErrorAction SilentlyContinue -Force
Remove-Item $env:TEMP\HostListTemp.txt -ErrorAction SilentlyContinue -Force
Remove-Item $env:TEMP\NoInstanceHostList.txt -ErrorAction SilentlyContinue -Force
Remove-Item $env:TEMP\IgnoreHosts.txt -ErrorAction SilentlyContinue -Force
Remove-Item $env:TEMP\ErrorHosts.txt -ErrorAction SilentlyContinue -Force
Remove-Item $env:TEMP\HostStatus.txt -ErrorAction SilentlyContinue -Force
Remove-Item $env:TEMP\StatusCheck.csv -ErrorAction SilentlyContinue -Force

Remove-Item "$env:TEMP\SQLSPUpgradeLogs" -ErrorAction SilentlyContinue -Recurse -Force
Remove-Item $env:TEMP\SQLSPUpgradeLogs.zip -ErrorAction SilentlyContinue -Force

if($HostInstFile)
    { Get-Content $HostInstFile | Where { $_ -notmatch "^#" } >> $hostlisttemp }

#Get-Content $HostInstFile | Where { $_ -notmatch "^#" } 

if(($HostName) -and ($InstanceName))
{
    Write-Output "HostName,Instance" >> $hostlisttemp
    Write-Output "$HostName,$InstanceName" >> $hostlisttemp
} # if $HostName $InstanceName

if (Test-Path -Path $hostlisttemp)
    { Import-Csv $hostlisttemp | Where-Object {$_.HostName -ne "HostName" -and $_.HostName -ne "$env:computername"} | Sort * -Unique | Export-Csv -Path $hostlist -NoTypeInformation }

#Import-Csv $hostlisttemp |  Sort -Unique
Remove-Item $hostlisttemp -ErrorAction SilentlyContinue

if (!(Test-Path -Path $hostlist)) {
    Write-Output "No Hosts to process on. Exiting script."
    exit 2
}

if (!($To_Recp)) { 
    $To_Recp = 'SQLServerSupport@moodys.com'
    $To_Recp = 'Narendra.Arora-non-empl@Moodys.com'
    $To_Recp = @('Narendra.Arora-non-empl@Moodys.com','NileshR.Patel@moodys.com','SQLServerSupport@moodys.com')
}

if (($CC_Recp)) { 
    #$CC_Recp=$CC_Recp+@("SQLServerSupport@moodys.com","NileshR.Patel@moodys.com")
    $CC_Recp=$CC_Recp+"SQLServerSupport@moodys.com"
}
else {
    #$CC_Recp=$CC_Recp+@("SQLServerSupport@moodys.com","NileshR.Patel@moodys.com")
    $CC_Recp=$CC_Recp+@("SQLServerSupport@moodys.com")
    $CC_Recp=$CC_Recp+"Narendra.Arora-non-empl@Moodys.com"
}



### Begin process

if ($ReportOnly -eq "YES") {
    Write-Output "######################################################################"
    Write-Output "`tRunning in Report-Only mode"
    Write-Output "######################################################################`n"
}
else {
    Write-Output "######################################################################"
    Write-Output "`tRunning in Installation mode with options -"
    Write-Output "`tForceRestart = $ForceRestart ; ForceCluster = $ForceCluster"
    Write-Output "######################################################################`n"
}

$WarningPreference = 'SilentlyContinue'

foreach ($row in Import-Csv $hostlist) {

    $hostname=$row.HostName
    $instance=$row.Instance

    if ((Test-Path $ignorehosts) -and (Get-Content $ignorehosts | Where-Object {$_ -eq $hostname})) 
        { continue }

    $instancelist = $null
    $clusteredinstances = $null
    $standaloneinstances = $null

    Write-Output "`n****** Started processing for $hostname , $instance at $(Get-Date) ******`n"

    Validate-Host $hostname
    if ($ValidateHost -ne 0) 
        { continue }

    Validate-Instances $hostname $instance
    if ($ValidateInstances -ne 0) 
        { continue }

    $allinstances = $script:instancelist

    foreach ($i in $allinstances) {

        Validate-Cluster $hostname $($i.Instance)
        if ($iscluster -eq 1) {
            $clusteredinstances += @([pscustomobject]@{Instance=$($i.Instance);activenode=$activenode;passivenodes=$passivenodes;numnodes=$numberofnodes;Value=$($i.Value);Version=$($i.Version);BaseVersion=$($i.baseversion)})
        } # if iscluster
        else {
            $standaloneinstances += @([pscustomobject]@{Instance=$($i.Instance);Value=$($i.Value);Version=$($i.Version);BaseVersion=$($i.baseversion)})
        } # else iscluster

    } # foreach $instancelist

    Write-Output "Found $(($clusteredinstances | measure).count) clustered instances and $(($standaloneinstances | measure).count) standalone instances on host $hostname"
    Write-Status "INFO,$(($clusteredinstances | measure).count) clustered instances" $hostname $instance
    Write-Status "INFO,$(($standaloneinstances | measure).count) standalone instances" $hostname $instance

    $clusteredinstances
    $standaloneinstances
    Write-Output "`n"

    #foreach ($i in $standaloneinstances) {Write-Output "foreach`n";$i|ft -AutoSize}

    foreach ($inst in $clusteredinstances) {

        if ($instance -ne "ALL" -and $inst.Instance -notmatch "$instance") 
            { continue }

        # Process Cluster single instance one by one
        Write-Output "`n  **** Started processing cluster for $hostname , $($inst.Instance)..$(Get-Date) ****`n"
        Process-Cluster $hostname $inst
        Write-Output "`n  **** Completed processing cluster for $hostname , $($inst.Instance)..$(Get-Date) ****`n"

    } # foreach clusteredinstance

    if ($(($clusteredinstances | measure).count) -eq 0 -and $instance -eq "ALL") {

        if (($standaloneinstances.baseversion | Get-Unique | measure).count -eq 1) {

            Write-Output "   ** Started processing for host $hostname - ALL **"
            #Process host all single base version
            Process-Host $hostname $standaloneinstances "host" "ALL"
            Write-Output "   ** Completed processing for host $hostname - ALL **"

        } # if single base version
        else {

            foreach ($ver in $($standaloneinstances.baseversion | Get-Unique)) {
            
                #$($standaloneinstances | where {$_.baseversion -eq $ver})
                #Process host all for each baseversion
                Write-Output "   ** Started processing for host $hostname - ALL (version : $ver) **"
                Process-Host $hostname $($standaloneinstances | where {$_.baseversion -eq $ver}) "host" "ALL"
                Write-Output "   ** Started processing for host $hostname - ALL (version : $ver) **"
                
            } # foreach base version   

        } # else single base version


    } # if clusteredinstance = 0  & instance = all
    elseif ($(($clusteredinstances | measure).count) -ne 0 -and $instance -eq "ALL") {

        foreach ($inst in $standaloneinstances) {

            # Process host single instance one by one
            Write-Output "   ** Started processing for host $hostname - $($inst.Instance) **"
            Process-Host $hostname $inst "host"
            Write-Output "   ** Completed processing for host $hostname - $($inst.Instance) **"

        } # for each standaloneinstance

    } # elseif clusteredinstance <> 0  & instance = all
    elseif ($instance -ne "ALL") {

        foreach ($inst in ($standaloneinstances | where {$_.Instance -match "$instance"})) {

            # Process host single instance one by one
            Process-Host $hostname $inst "host"

        } # for each standaloneinstance

    } # elseif instance <> all


    #continue
    Write-Output "`n****** Finished processing for $hostname , $instance at $(Get-Date) ******`n"

            
} # foreach row in HostList.txt

Stop-Transcript | Out-Null

# Send EMail
if ((Test-Path $hostlist)) { $Attch=$Attch+@("$hostlist") }
if ((Test-Path $errorhosts)) { $Attch=$Attch+@("$errorhosts") }
if ((Test-Path $ignorehosts)) { $Attch=$Attch+@("$ignorehosts") }
if ((Test-Path $hoststatus)) { $Attch=$Attch+@("$hoststatus") }
if ((Test-Path $noinstancehostlist)) { $Attch=$Attch+@("$noinstancehostlist") }
if ((Test-Path $statuscheck)) { $Attch=$Attch+@("$statuscheck") }
if ((Test-Path $env:TEMP\SessionLog_$Dt.log)) { $Attch=$Attch+@("$env:TEMP\SessionLog_$Dt.log") }

if ((Test-Path $spupgradelogs)) {
    TRY 
        { Compress-Archive -Path "$spupgradelogs\*" -DestinationPath "$spupgradelogs\SQLSPUpgradeLogs_$Dt.zip" }
    CATCH { }

    if ((Test-Path $spupgradelogs\SQLSPUpgradeLogs_$Dt.zip)) { $Attch=$Attch+@("$spupgradelogs\SQLSPUpgradeLogs_$Dt.zip") }
} # if test SQLSPUpgradeLogs

$EmailBodyText += "Please find attached details for the SQL Server SP Upgrade scan.`n`nThank you!"

if ($test){
    $To_Recp = 'Narendra.Arora-non-empl@Moodys.com'
    $CC_Recp = 'Narendra.Arora-non-empl@Moodys.com'
}

Send-MailMessage -To $To_Recp -Cc $CC_Recp -Attachments $Attch -From SQLServerSupport@moodys.com -SmtpServer exmx.moodys.com -Subject "SQL Server SP Upgrade Automation Results <$env:COMPUTERNAME>" -Body $EmailBodyText
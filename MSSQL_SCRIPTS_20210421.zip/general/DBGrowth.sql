--Part 1 Filtering Database by MDFand NDF whose size is more than 5 GB


--Drop table ##DBGrowthData

SELECT distinct Rdate, AtServername, DBName,  SizeMB into ##DBGrowthData from 
(select --top 100 *
Rdate,AtServername,REPLACE(REPLACE(DBName,'[',''),']','') [DBName],SUM(UsedMB) [SizeMB]
from [dbo].[dwServerDBInfo_01] 
--where Filename not like '%.ldf' or
where Filename like '%.ldf' or
 Filename like   '%.mdf' or
 Filename like   '%.ndf'
--and AtServername='FTC-WBLMDCDB302\SQL_MFRA201' and REPLACE(REPLACE(DBName,'[',''),']','')='mdymfra'
group by Rdate,AtServername,REPLACE(REPLACE(DBName,'[',''),']','')) dwServerDBInfo_01
where --dwServerDBInfo_01.rn<=500  --and 
SizeMB > 50000  
order by AtServername,DBName,Rdate desc



--Part 2 Growth MB is Derived for Each database based on  Rdate and SizeMB on RDate.

--select  Rdate,AtServername,DBName,SizeMB,
--SizeMB-(Select TOP 1 SUB.SizeMB from ##DBGrowthData as SUB
--where sub.DBName=MAIN.DBName and sub.AtServername=main.AtServername  and main.Rdate > sub.Rdate order by Rdate desc   --sub.Rdate< main.Rdate
--) as GrowthMB
--from ##DBGrowthData AS MAIN 
--where main.AtServername like ('ptc-wbsqlfrm109%') -- main.DBName  like 'B%'
--order by    main.AtServername,Main.DBName,  Main.Rdate desc , main.SizeMB desc       

select  Rdate,AtServername,DBName,SizeMB,
SizeMB-(Select TOP 1 SUB.SizeMB from ##DBGrowthData as SUB
where sub.DBName=MAIN.DBName and sub.AtServername=main.AtServername  and main.Rdate > sub.Rdate order by Rdate desc   --sub.Rdate< main.Rdate
) as GrowthMB
from ##DBGrowthData AS MAIN 
where main.AtServername like ('PTC-WBSQLFRM109%') -- main.DBName  like 'B%'
order by    main.AtServername,Main.DBName,  Main.Rdate desc , main.SizeMB desc       

--drop table ##DBDBGrowthDataAVG
Select * into ##DBDBGrowthDataAVG from 
(
select  Rdate,AtServername,DBName,SizeMB,
SizeMB-(Select TOP 1 SUB.SizeMB from ##DBGrowthData as SUB
where sub.DBName=MAIN.DBName and sub.AtServername=main.AtServername  and main.Rdate > sub.Rdate order by Rdate desc   --sub.Rdate< main.Rdate
) as GrowthMB
from ##DBGrowthData AS MAIN 
where main.AtServername like ('SF1-WBBAWEDB101%') 
group by main.Rdate,main.AtServername,main.DBName, main.SizeMB) ##DBGrowthData
-- main.DBName  like 'B%'
order by    AtServername,DBName,  Rdate desc , SizeMB desc  


Select AtServername,DBName,AVG(GrowthMB)AS AVGGrowth
from  ##DBDBGrowthDataAVG
--where DBName='LOCAL_BACKUPS'
group by AtServername,DBName

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

declare @publisher_srv as varchar(40), @publisher_db as varchar(20), @subscriber_srv as varchar(40), @subscriber_db as varchar(20),
   	    @publication as varchar(20), @object_type as varchar(20), @source_objectname as varchar(50), @destination_objectname as varchar(50), 
		@rowcount_publisher as int, @rowcount_subscriber as int, @rowcount_diff as int, 
		@tableHTML varchar(max), @recp varchar(100), @tableHTML_hdr varchar(max), @tableHTML_dtl varchar(max), 
		@noemail tinyint, @tableHTML_dtl_diff varchar(max), @tableHTML_diff varchar(max), @tableHTML_hdr1 varchar(124), @tableHTML_hdr2 varchar(124), @tableHTML_css varchar(max)

declare @email int, @cntr int, @subject varchar(2000) 
declare @prebody1 varchar(300), @prebody2 varchar(750), @prebody3 varchar(220), @diff_rowcnt tinyint

select @email = 1

if @email = 0 
   return 

   
/********************************************************************
BEGINING OF SCRIPT
*********************************************************************/
--------------------------------------------------------------------
--STEP 1: Gather information about current transactional replication
--------------------------------------------------------------------
set nocount on 

IF OBJECT_ID('tempdb..#tempTransReplication') IS NOT NULL 
 DROP TABLE #tempTransReplication

CREATE TABLE #tempTransReplication
 (
 publisher_id INT, publisher_srv VARCHAR(255), publisher_db VARCHAR(255),
 publication VARCHAR(255), subscriber_id INT,  subscriber_srv VARCHAR(255),
 subscriber_db VARCHAR(255), object_type VARCHAR(255), source_owner VARCHAR(255),
 source_object VARCHAR(255), destination_owner VARCHAR(255), destination_object VARCHAR(255),
 rowcount_publisher INT, rowcount_subscriber INT, rowcount_diff INT
 )

INSERT INTO #tempTransReplication
 SELECT s.publisher_id, ss2.data_source, a.publisher_db, p.publication,
 s.subscriber_id, ss.data_source, s.subscriber_db, NULL,
 a.source_owner, a.source_object, ISNULL(a.destination_owner, a.source_owner), 
 -- if NULL, schema name remains same at subscriber side
 a.destination_object, NULL, NULL, NULL 
 FROM distribution.dbo.MSarticles AS a
 INNER JOIN distribution.dbo.MSsubscriptions AS s ON a.publication_id = s.publication_id AND a.article_id = s.article_id
 INNER JOIN [master].sys.servers AS ss ON s.subscriber_id = ss.server_id
 INNER JOIN distribution.dbo.MSpublications AS p ON s.publication_id = p.publication_id 
 LEFT OUTER JOIN [master].sys.servers AS ss2 ON p.publisher_id = ss2.server_id
 WHERE s.subscriber_db <> 'virtual'
 
 --SELECT  *
--FROM    #tempTransReplication

--------------------------------------------------------------------
-- STEP 2: Gather rowcount at Publisher side
--------------------------------------------------------------------

IF OBJECT_ID('tempdb..#tempPublishedArticles') IS NOT NULL 
 DROP TABLE #tempPublishedArticles

CREATE TABLE #tempPublishedArticles
 (
 publisher_db VARCHAR(255), source_owner VARCHAR(255), source_object VARCHAR(255),
 object_type VARCHAR(255), rowcount_publisher INT
 )

DECLARE @pub_db VARCHAR(255), @strSQL_P VARCHAR(4000)

DECLARE db_cursor_p CURSOR
 FOR SELECT DISTINCT
 publisher_db
 FROM distribution.dbo.MSpublications

OPEN db_cursor_p 
FETCH NEXT FROM db_cursor_p INTO @pub_db

WHILE @@FETCH_STATUS = 0 
    BEGIN
        SET @strSQL_P = 'SELECT ' + '''' + @pub_db + ''''
            + ' AS publisher_db, s.name AS source_owner, o.name AS source_object, o.Type_Desc AS object_type, i.rowcnt AS rowcount_publisher 
 FROM ' + @pub_db + '.sys.objects AS o 
 INNER JOIN ' + @pub_db + '.sys.schemas AS s 
on o.schema_id = s.schema_id 
 LEFT OUTER JOIN ' + @pub_db + '.dbo.sysindexes AS i 
on o.object_id = i.id 
 WHERE ' + '''' + @pub_db + '''' 
+ ' + ' + '''' + '.' + '''' + ' + s.name'
            + ' + ' + '''' + '.' + '''' + ' + o.name'
            + ' IN (SELECT publisher_db + ' + '''' + '.' + ''''
            + ' + source_owner + ' + '''' + '.' + ''''
            + ' + source_object collate SQL_Latin1_General_CP1_CI_AS FROM #tempTransReplication) 
 AND ISNULL(i.indid, 0) IN (0, 1)
 ORDER BY i.rowcnt DESC'
-- heap (indid=0); clustered index (indix=1)
INSERT INTO #tempPublishedArticles
 EXEC ( @strSQL_P
 )
 
 FETCH NEXT FROM db_cursor_p INTO @pub_db 
 END
CLOSE db_cursor_p 
DEALLOCATE db_cursor_p

--SELECT  * --FROM    #tempPublishedArticles
--------------------------------------------------------------------
-- STEP 3: Gather rowcount at Subscriber(s) side
--------------------------------------------------------------------

IF OBJECT_ID('tempdb..#tempSubscribedArticles') IS NOT NULL 
 DROP TABLE #tempSubscribedArticles

CREATE TABLE #tempSubscribedArticles
 (
 subscriber_srv VARCHAR(255),
 subscriber_db VARCHAR(255),
 destination_owner VARCHAR(255),
 destination_object VARCHAR(255),
 object_type VARCHAR(255),
 rowcount_subscriber INT
 )

DECLARE @sub_srv VARCHAR(255),
 @sub_db VARCHAR(255),
 @strSQL_S VARCHAR(4000)

DECLARE db_cursor_s CURSOR
 FOR SELECT DISTINCT
 subscriber_srv,
 subscriber_db
 FROM #tempTransReplication

OPEN db_cursor_s
FETCH NEXT FROM db_cursor_s INTO @sub_srv, @sub_db

WHILE @@FETCH_STATUS = 0 
 BEGIN
SET @strSQL_S = 'SELECT ' + '''' + @sub_srv + ''''
 + ' AS subscriber_srv, ' + '''' + @sub_db + ''''
 + ' AS subscriber_db, '
 + 's.name AS destination_owner, o.name AS destination_object, o.Type_Desc AS object_type, i.rowcnt AS rowcount_subscriber 
FROM [' + @sub_srv + '].' + @sub_db + '.sys.objects AS o 
INNER JOIN [' + @sub_srv + '].' + @sub_db
 + '.sys.schemas AS s on o.schema_id = s.schema_id
LEFT OUTER JOIN [' + @sub_srv + '].' + @sub_db
 + '.dbo.sysindexes AS i on o.object_id = i.id
WHERE ' + '''[' + @sub_srv + '].' + @sub_db + '''' 
+ ' + ' + '''' + '.' + ''''
 + ' + s.name' + ' + ' + '''' + '.' + '''' + ' + o.name'
 + ' IN (SELECT ''[''+subscriber_srv + ' + '''' + '].' + ''''
 + ' + subscriber_db + ' + '''' + '.' + ''''
 + ' + destination_owner + ' + '''' + '.' + ''''
 + ' + destination_object collate SQL_Latin1_General_CP1_CI_AS FROM #tempTransReplication) 
AND ISNULL(i.indid, 0) IN (0, 1) 
ORDER BY i.rowcnt DESC'
-- heap (indid=0); clustered index (indix=1)
--print @strSQL_S
INSERT INTO #tempSubscribedArticles
 EXEC ( @strSQL_S
 )

 FETCH NEXT FROM db_cursor_s INTO @sub_srv, @sub_db
 END 
CLOSE db_cursor_s
DEALLOCATE db_cursor_s

--SELECT  *
--FROM    #tempSubscribedArticles

--------------------------------------------------------------------
-- STEP 4: Update table #tempTransReplication with rowcount
--------------------------------------------------------------------

UPDATE t
SET rowcount_publisher = p.rowcount_publisher,
 object_type = p.object_type
FROM #tempTransReplication AS t
 INNER JOIN #tempPublishedArticles AS p ON t.publisher_db = p.publisher_db 
 AND t.source_owner = p.source_owner
 AND t.source_object = p.source_object

UPDATE t
SET rowcount_subscriber = s.rowcount_subscriber
FROM #tempTransReplication AS t
 INNER JOIN #tempSubscribedArticles AS s ON t.subscriber_srv = s.subscriber_srv
 AND t.subscriber_db = s.subscriber_db
 AND t.destination_owner = s.destination_owner
 AND t.destination_object = s.destination_object

UPDATE #tempTransReplication
SET rowcount_diff = ABS(rowcount_publisher - rowcount_subscriber)

--SELECT  *
--FROM    #tempTransReplication

DECLARE @scriptCursor as CURSOR

SET @scriptCursor = CURSOR FOR
SELECT  publisher_srv, publisher_db, subscriber_srv, subscriber_db,
        publication, object_type,
        ( source_owner + '.' + source_object ) AS source_objectname,
        ( destination_owner + '.' + destination_object ) AS destination_objectname,
        isnULL(rowcount_publisher,0) as rowcount_publisher, isNULL(rowcount_subscriber,0) as rowcount_subscriber, 
	isnull(rowcount_diff,0) as rowcount_diff 
FROM    #tempTransReplication
ORDER BY publisher_srv, publisher_db, subscriber_srv, subscriber_db,
        publication, object_type, source_objectname, rowcount_publisher

open @scriptCursor
--ED2939 red color 
SET @tableHTML_css =    
N'    
<style>    
.hd1 {    
 color:white;    
 font-size:11.0pt;    
 text-decoration:none;    
 font-family:Calibri, sans-serif;    
 text-align:center;    
 background:#1F497D;    
}    
.hd2 {    
 color:black;    
 font-size:11.0pt;    
 text-decoration:none;    
 font-family:Calibri, sans-serif;    
 text-align:center;    
 background:#DCDCDC;    
}    
.td12 {    
 color:white;    
 font-size:10.0pt;    
 text-decoration:none;    
 font-family:Calibri, sans-serif;    
 text-align:center;background:#ED2939;    
}    
.td3 {    
 color:black;    
 font-size:10.0pt;    
 text-decoration:none;    
 font-family:Calibri, sans-serif;    
 text-align:center;
 background:#D8E4BC;    
}    
.td4 {    
 color:black;    
 font-size:10.0pt;    
 text-decoration:none;    
 font-family:Calibri, sans-serif;    
 text-align:center;
 background:white;    
}    
    
</style>'    


set @preBody1 = N'<table ><tr class="td4"> Hello, <br> <br>
You are receiving this email as a part of the Infrastructure Operations� proactive monitoring initiative (or) you may have requested for it.<br>Below listed is a comparison in the rowcounts between SQL Server Replication Source and Targets.<br><br>'
set @preBody2 = N'The tables with differences need to be analyzed by the application team and confirm the required action to be taken by the DB Ops team. <br>
The reason for the difference could be either � <br>
         A current delay in the replication, which would eventually catch up in a few minutes depending on amount of data <br>
		 OR<br>
		 A conflicting process within the application which is working on the data without consideration of keeping the source and target in sync. <br>
The actions for DB Ops team can be either a re-initialization of the tables (effectively dropped and re-created on the target) OR remove the tables from replication, if no longer required. <br><br>'
set @preBody3 = N'
Please reach out to DB Ops team(SQLServerSupport@moodys.com) if any further information is needed.<br><br></tr></table>'

SET @tableHTML_hdr1 = '<table border="1" >' +    
'<tr class="hd2"> Replicated Tables with Mismatch Rowcount </tr></table>'

SET @tableHTML_hdr2 = '<table border="1" >' +    
'<tr class="hd2"> Replicated Tables with Matched Rowcount </tr></table>'

SET @tableHTML_hdr = '<table border="1" >' +    
'<tr class="hd1"><th>Publisher Server</th><th>Publisher Database</th><th>Subscriber Server</th><th>Subscriber database</th><th>Publication</th><th>Table Name</th><th>Row Count(Publisher)</th><th>Row Count(Subscriber)</th><th>Row Count(Difference)</th></tr>' 

select @tableHTML='', @tableHTML_diff = ''
select @cntr=1, @noemail=1, @diff_rowcnt=0

FETCH NEXT FROM @scriptCursor INTO @publisher_srv, @publisher_db, @subscriber_srv, @subscriber_db, @publication, @object_type, @source_objectname, @destination_objectname, @rowcount_publisher, @rowcount_subscriber, @rowcount_diff  ;

select @tableHTML_dtl='', @tableHTML_dtl_diff=''
WHILE @@FETCH_STATUS = 0
BEGIN

    if (@rowcount_diff = 0) 
	begin 
		select @tableHTML_dtl='<tr class="td3"><td>'+@publisher_srv+'</td><td>'+@publisher_db+'</td><td>'+@subscriber_srv+'</td><td>'+@subscriber_db+'</td><td>'+ @publication+'</td><td>'+@source_objectname+'</td><td>' + str(@rowcount_publisher, 10)+'</td><td>'+ str(@rowcount_subscriber,10)+'</td><td>'+str(@rowcount_diff,10) + '</td></tr>'
		
		select @tableHTML=@tableHTML +  @tableHTML_dtl  
	end 
	else
	begin 
		select @tableHTML_dtl_diff ='<tr class="td12"><td>'+@publisher_srv+'</td><td>'+@publisher_db+'</td><td>'+@subscriber_srv+'</td><td>'+@subscriber_db+'</td><td>'+ @publication+'</td><td>'+@source_objectname+'</td><td>' +str(@rowcount_publisher,10)+'</td><td>'+ str(@rowcount_subscriber,10)+'</td><td>'+ str(@rowcount_diff,10) + '</td></tr>'
		
		select @tableHTML_diff = @tableHTML_diff + @tableHTML_dtl_diff
		select @diff_rowcnt=1
	end 
	
	FETCH NEXT FROM @scriptCursor INTO @publisher_srv, @publisher_db, @subscriber_srv, @subscriber_db, @publication, @object_type, @source_objectname, @destination_objectname, @rowcount_publisher, @rowcount_subscriber, @rowcount_diff  ;
END
	
if (len(@tableHTML) > 0)
begin 
		select @tableHTML= @tableHTML_hdr+@tableHTML+'</table>'

		if (@diff_rowcnt = 1) 
		begin 
			select @tableHTML_diff = @tableHTML_hdr+@tableHTML_diff+'</table>'
			select @tableHTML = @tableHTML_css + '<br>' + @preBody1 + @preBody2 + @preBody3 + @tableHTML_hdr1 + '<br>' + @tableHTML_diff + '<br>' + @tableHTML_hdr2 + '<br>' + @tableHTML + '<br>'  
		end
		else
		begin 
			select @tableHTML = @tableHTML_css + '<br>' + @preBody1 + @preBody3 + 
				'<br>' + @tableHTML_hdr2 + '<br>' + @tableHTML + '<br>'  
		end 
end 

select @subject='<'+@@servername+'> -::- Replication Rowcount -::-'

	EXEC msdb.dbo.sp_send_dbmail      
       @recipients='%%to_email%%',
	   --@recipients='NileshR.Patel@moodys.com;Deepak.Vispute-non-empl@moodys.com;SQLServerSupport@moodys.com;',
	   --@recipients='Deepak.Vispute-non-empl@moodys.com;',
		@copy_recipients='%%cc_email%%',    
		@subject = @subject,    
		@body = @tableHTML,    
		@body_format = 'HTML' ;    
	
CLOSE @scriptCursor;
DEALLOCATE @scriptCursor;

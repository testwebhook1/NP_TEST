/**********************************************************
------------------ Create UPD Stats SP ------------------
***********************************************************/
USE [master]
GO

/****** Object:  StoredProcedure [dbo].[update_stats]    ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[update_stats]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[update_stats]
GO

USE [master]
GO

/****** Object:  StoredProcedure [dbo].[update_stats]    ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[update_stats]

@databaseToCheck VARCHAR(255) = NULL,
@rowmodctr INT = 20, 
@samplepercent INT = 40,
@reportOnly BIT = 0
-- created by Animesh 8/01/2017
-- modified by Nilesh 8/02/2017 added reportonly and filter for system tables and null index name
-- Ver_201708_02

AS

BEGIN

  SET NOCOUNT ON

  SET ARITHABORT ON

  SET NUMERIC_ROUNDABORT OFF

DECLARE @DBS TABLE (I INT NOT NULL IDENTITY(1,1) PRIMARY KEY CLUSTERED,
                    DBNAME SYSNAME NOT NULL )--declare databases to check table

DECLARE @I INT --declare outer while loop start counter
        ,@Z INT --declare outer while loop end counter
        ,@SQL VARCHAR(1024) --declare variable for update stat command
        ,@j INT --declare inner while loop start counter
        ,@Y INT --declare inner while loop end counter
        ,@MYDB SYSNAME --declare dynamic variable for database to use
        ,@msg NVARCHAR(1024) --declare error message variable
		
--if database not specified scan all databases
IF @databaseToCheck IS NULL
BEGIN

--get the databases to check except master,tempdb and model
INSERT INTO @DBS
SELECT s.name 
FROM sys.databases s
INNER JOIN SYS.master_files F ON S.DATABASE_ID = F.database_id  AND F.data_space_id = 1
WHERE S.STATE = 0 -- online
  AND S.database_id > 3 -- exclude master, tempdb and model -- I left msdb 
  AND S.is_read_only = 0 -- read/write
  AND S.user_access = 0 -- multi_user
  --AND S.NAME NOT IN ('test')
ORDER BY F.SIZE DESC

END

--if database is specified scan the database only
ELSE
BEGIN

--get the specified database
INSERT INTO @DBS
SELECT s.name 
FROM sys.databases s
INNER JOIN SYS.master_files F ON S.DATABASE_ID = F.database_id  AND F.data_space_id = 1
WHERE S.STATE = 0 -- online
  AND S.NAME = @databaseToCheck -- for the specified database only 
  AND S.is_read_only = 0 -- read/write
  AND S.user_access = 0 -- multi_user
  --AND S.NAME NOT IN ('test')
ORDER BY F.SIZE DESC

END

SELECT @Z = @@ROWCOUNT --initalize end value for outer while loop
SELECT @I = 1 --initalize start value for inner while loop



WHILE @I <= @z 

BEGIN

	--drop and create temp table
    BEGIN TRY DROP TABLE #T END TRY BEGIN CATCH END CATCH
    CREATE TABLE #T( I INT NOT NULL IDENTITY(1,1) PRIMARY KEY CLUSTERED, tablename VARCHAR(1024) NOT NULL, 
	type_desc VARCHAR(1024) NOT NULL, index_name VARCHAR(1024) NULL, statistics_update_date [datetime] NULL, 
	rowmodctr INT NULL, MYSQL VARCHAR(1024) NOT NULL )
	--get the insert statement for temp table
    SELECT @MYDB = QUOTENAME (S.DBNAME )
           ,@SQL = 'USE ' + QUOTENAME (S.DBNAME ) + ';' + CHAR(13) + ' 
                    ' + CHAR(13) +
                   'INSERT INTO #T(tablename,type_desc,index_name,statistics_update_date,rowmodctr,MYSQL) 
SELECT 

DISTINCT
      tablename= OBJECT_NAME(i.object_id)
       , o.type_desc
       ,''all''--,index_name=i.[name]
    , ''01/01/01''--statistics_update_date = STATS_DATE(i.object_id, i.index_id)
       , si.rowmodctr, ''UPDATE STATISTICS '' + QUOTENAME(OBJECT_NAME(i.object_id)) + 
       '' WITH SAMPLE '+ cast(@samplepercent AS NVARCHAR) + ' PERCENT''
FROM sys.indexes i (nolock)
JOIN sys.objects o (nolock) on
       i.object_id=o.object_id 
	   and o.type_desc <> ''SYSTEM_TABLE''
	   and i.name is not null
JOIN sys.sysindexes si (nolock) on
       i.object_id=si.id
       and i.index_id=si.indid
       and si.rowmodctr >= '+ CAST (@rowmodctr AS NVARCHAR) + '
order by si.rowmodctr desc  ' + CHAR(13)  

      FROM @DBS s
        WHERE s.I = @I 


    PRINT CAST (@SQL AS NTEXT)
       BEGIN TRY

            EXEC (@SQL) -- execute the insert statement for temp table
            SELECT @Y = @@ROWCOUNT --initalize inner while loop end value

       END TRY
       BEGIN CATCH
           SELECT @Y = 0
       END CATCH



    SELECT @J = 1 --initalize inner while loop start value
if @reportOnly = 1 --to get the report only
	select @MYDB+' - '+MYSQL from    #T 
else

	BEGIN  --@reportOnly = 0
		WHILE @J <= @y BEGIN
			
			--get the command from the temp table along with the database name
		   SELECT @SQL = 'USE ' + @MYDB + ';' + CHAR(13) + MYSQL 
		   FROM #T 
		   WHERE I= @J

		   BEGIN TRY
				PRINT CAST (@SQL AS NTEXT)
				EXEC (@SQL) -- execute the update stats command
		   END TRY
		   BEGIN CATCH
				select   @msg='ErrorMsg# '+convert(CHAR(10),ERROR_NUMBER())+' '+ERROR_MESSAGE() --get the error while executing update stats
				print @msg
		   END CATCH

		   SELECT @J = @J + 1

		END /*INNER WHILE*/
	END --@reportOnly=0
    SELECT @I = @I +1

  END /*OUTER WHILE*/

END

GO


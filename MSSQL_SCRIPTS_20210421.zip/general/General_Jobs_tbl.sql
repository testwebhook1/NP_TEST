USE [MIT_DBRefresh]
GO

/****** Object:  Table [dbo].[General_Jobs]    Script Date: 4/23/2021 1:53:46 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[General_Jobs](
	[SR_ID] [int] NULL,
	[SR_Name] [varchar](200) NULL,
	[SR_SQL] [varchar](500) NULL,
	[SR_Server] [varchar](100) NULL,
	[SR_DB_Name] [varchar](100) NULL,
	[is_Sched] [char](1) NULL,
	[Sched_Type] [varchar](10) NULL,
	[SR_To_recp] [varchar](200) NULL,
	[SR_cc_recp] [varchar](200) NULL,
	[updated_on] [datetime] NULL,
	[updated_by] [varchar](20) NULL
) ON [PRIMARY]
GO



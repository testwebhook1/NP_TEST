


-----Delete Tlog SP Added by Arun on 10/9/2019------

USE [master]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_DeleteOldTrnlogBackup]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_DeleteOldTrnlogBackup]
GO

USE [master]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

USE [master]
GO

/****** Object:  StoredProcedure [dbo].[usp_DeleteOldTrnlogBackup]    Script Date: 10/9/2019 11:59:56 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [dbo].[usp_DeleteOldTrnlogBackup] 
	@bkpDIR NVARCHAR(255) = null,
	@extension NVARCHAR(10),
	@LogPath VARCHAR(255) = null,
	@logdir VARCHAR(255) = null,
	@age_hrs INT
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @DeleteDate NVARCHAR(50)
	DECLARE @DeleteDateTime DATETIME
	SET @DeleteDateTime = DateAdd(hh, - @age_hrs, GetDate())
    SET @DeleteDate = (Select Replace(Convert(nvarchar, @DeleteDateTime, 111), '/', '-') + 'T' + Convert(nvarchar, @DeleteDateTime, 108))
	EXEC master..xp_instance_regread @rootkey = 'HKEY_LOCAL_MACHINE',  
    @key = 'Software\Microsoft\MSSQLServer\MSSQLServer',  
    @value_name = 'BackupDirectory', @BackupDirectory = @bkpDIR OUTPUT ;

	set @logdir='Tlog_Backup'
    SET @LogPath= @bkpDIR +'\' + @logdir
	EXEC xp_create_subdir @LogPath
	EXECUTE master.dbo.xp_delete_file 0, -- 0 for bkp files,1 for report files
		@bkpDIR,
		@extension,
		@DeleteDate,
		1 -- 0 for current folder,1 for subdirectories
END

GO



/******************************************************************************************
---------------- Transaction_Log_Backup Job Added by Arun on 10/9/2019 --------------------
******************************************************************************************/

USE [msdb]
GO

/****** Object:  Job [Transaction_Log_Backup]    Script Date: 10/9/2019 12:08:44 PM ******/
EXEC msdb.dbo.sp_delete_job @job_id=N'a45f4992-552e-4024-aaff-223d10ab8968', @delete_unused_schedule=1
GO

/****** Object:  Job [Transaction_Log_Backup]    Script Date: 10/9/2019 12:08:44 PM ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [Database Maintenance]    Script Date: 10/9/2019 12:08:44 PM ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'Database Maintenance' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'Database Maintenance'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Transaction_Log_Backup', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'Takes Tlog Backup', 
		@category_name=N'Database Maintenance', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [TakeTlogBackup]    Script Date: 10/9/2019 12:08:44 PM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'TakeTlogBackup', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=4, 
		@on_fail_step_id=3, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC usp_BackupDatabases
@backupType=''A'', --Specify A for all, S for specific databases and E to Exclude dbs in expDB
@expDBs='''', -- List the execption dbs
@defaultType=''L''', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [TlogBackupCleanUp]    Script Date: 10/9/2019 12:08:44 PM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'TlogBackupCleanUp', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=4, 
		@on_fail_step_id=3, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC usp_DeleteOldTrnlogBackup
@extension=''trn'',
@age_hrs=''48''', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [SendNotification]    Script Date: 10/9/2019 12:08:44 PM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'SendNotification', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=2, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @strMailSubject varchar(1024)
set @strMailSubject = ''< '' + @@Servername + '' > '' + ''Job Failure : Transaction Log Backup - Failed'' 

EXEC msdb.dbo.sp_send_dbmail 
     @profile_name = ''SQLDBAMail'', 
     @recipients = ''SQLServerSupport@moodys.com;'', 
     @body = ''Job Failure : DB Backup - Daily'',
     @subject = @strMailSubject', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Schedule', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=4, 
		@freq_subday_interval=15, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20191009, 
		@active_end_date=99991231, 
		@active_start_time=190000, 
		@active_end_time=235959, 
		@schedule_uid=N'6a0d7e75-33d1-4a30-a4b0-793ce51a0931'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO
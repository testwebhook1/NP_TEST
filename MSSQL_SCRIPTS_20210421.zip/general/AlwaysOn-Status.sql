declare @status tinyint
declare @reqno varchar(20), @req_id int, @stat_desc varchar(500), @row_cnt int, @req_email varchar(400), @req_type varchar(10)


declare @ag_name varchar(100), @ag_status varchar(200), @ag_replica varchar(100), @ag_dbname varchar(200), 
	    @rep_server varchar(100), @rep_state varchar(100), @rep_health varchar(100),
		@recp varchar(100)

declare @email int, @tableHTML_hdr varchar(max), @tableHTML varchar(max), @tableHTML_dtl varchar(max), 
		@strsubject varchar(100), @to_recp varchar(200), @cc_recp varchar(200), @sub varchar(200)
DECLARE @scriptCursor as CURSOR

select @to_recp = '%%to_email%%', @cc_recp='%%cc_email%%', @sub='%%sub%%'

set @email=0
if exists (select G.name 'AG name',GS.synchronization_health_desc 'AG status',
case when is_local=0 then 'Secondary' else 'Primary' end as 'Replica',
DB.name 'DBName', R.replica_server_name,Rs.synchronization_state_desc 'Replica state', 
RS.synchronization_health_desc as 'Replica Health',RS.last_commit_time  
From [sys].[dm_hadr_database_replica_states] RS
inner join [sys].[dm_hadr_availability_group_states] GS on GS.group_id = Rs.group_id and GS.primary_recovery_health_desc='ONLINE'
inner join sys.availability_groups G on G.group_ID = RS.group_ID
inner join sys.databases db on db.database_id = RS.database_id
inner join sys.availability_replicas R on R.replica_id = RS.replica_id 
where ((is_local=0) or GS.group_id=RS.group_id) 
and GS.synchronization_health_desc not in ('HEALTHY')
)
    select @email = 1
else 
begin 
    select @email = case when datepart(hh, getdate()) = 11 then  1 else 0 end 
end

--if @status = 1 select @email = 1

select @email = 1

--if @email = 0 return 



SET @scriptCursor = CURSOR FOR
select G.name,GS.synchronization_health_desc,case when is_local=0 then 'Secondary' else 'Primary' end,DB.name,  R.replica_server_name,Rs.synchronization_state_desc, 
RS.synchronization_health_desc  
From [sys].[dm_hadr_database_replica_states] RS
inner join [sys].[dm_hadr_availability_group_states] GS on GS.group_id = Rs.group_id and GS.primary_recovery_health_desc='ONLINE'
inner join sys.availability_groups G on G.group_ID = RS.group_ID
inner join sys.databases db on db.database_id = RS.database_id
inner join sys.availability_replicas R on R.replica_id = RS.replica_id 
where GS.primary_recovery_health = 1
Union 
select G.Name, GS.synchronization_health_desc, 
case when GS.Primary_replica=R.replica_server_name then 'Primary' else 'Secondary' end,
(select top 1 D.name from sys.databases D where exists 
(select 1 from sys.availability_replicas R1 where R1.group_id = G.group_id and D.replica_id=r1.replica_id)),
R.replica_server_name, Rs.synchronization_state_desc ,
RS.synchronization_health_desc
from sys.availability_groups G 
inner join sys.availability_replicas R on G.group_id = R.group_id
inner join sys.dm_hadr_availability_group_states GS on GS.group_id = R.group_id
inner join [sys].[dm_hadr_database_replica_states] RS on RS.group_id = R.group_id
where GS.secondary_recovery_health =1
order by 1, 4

open @scriptCursor

SET @tableHTML_hdr =    
N'    
<style>    
.hd1 {    
 color:white;    
 font-size:11.0pt;    
 text-decoration:none;    
 font-family:Calibri, sans-serif;    
 text-align:center;    
 background:#1F497D;    
}    
.hd2 {    
 color:black;    
 font-size:11.0pt;    
 text-decoration:none;    
 font-family:Calibri, sans-serif;    
 text-align:center;    
 background:#95B3D7;    
}    
.td12 {    
 color:black;    
 font-size:11.0pt;    
 text-decoration:none;    
 font-family:Calibri, sans-serif;    
 background:#D9D9D9;    
}    
.td3 {    
 color:black;    
 font-size:11.0pt;    
 text-decoration:none;    
 font-family:Calibri, sans-serif;    
 text-align:center;
 background:#D8E4BC;    
}    
    
</style>'    

SET @tableHTML_hdr = @tableHTML_hdr +'<table border="1" >' +    
'<tr class="hd1"><th>AG Name</th><th>AG Status</th><th>AG Replica</th><th>AG DB Name</th><th>Replica Server Name</th><th>Replica State</th><th>Replica Health</th>' 

select @tableHTML=''

FETCH NEXT FROM @scriptCursor INTO @ag_name, @ag_status, @ag_replica, @ag_dbname, @rep_server, @rep_state, @rep_health ;
select @tableHTML_dtl=''
WHILE @@FETCH_STATUS = 0
BEGIN

	select @tableHTML_dtl='<tr class="td3"><td>'+@ag_name+'</td><td>'+@ag_status+'</td><td>'+@ag_replica+'</td><td>'+@ag_dbname+'</td><td>'+ 
						@rep_server+'</td><td>'+@rep_state+'</td><td>'+@rep_health + '</td></tr>'
	select @tableHTML=@tableHTML +  @tableHTML_dtl  
	
	FETCH NEXT FROM @scriptCursor INTO @ag_name, @ag_status, @ag_replica, @ag_dbname, @rep_server, @rep_state, @rep_health ;
END
	
if (len(@tableHTML) > 0)
		select @tableHTML= @tableHTML_hdr+@tableHTML+'</table>'

select @sub=@@servername+'-::Always ON Status Report::-'

	EXEC msdb.dbo.sp_send_dbmail @recipients=@to_recp,
		@copy_recipients=@cc_recp,    
		@subject = @sub,    
		@body = @tableHTML,    
		@body_format = 'HTML' ;    
	
CLOSE @scriptCursor;
DEALLOCATE @scriptCursor;


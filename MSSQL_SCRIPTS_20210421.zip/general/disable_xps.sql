/**********************************************************
-------------- Config Change to disable XPs ---------------
***********************************************************/

Use Master
GO

EXEC master.dbo.sp_configure 'show advanced options', 1
RECONFIGURE WITH OVERRIDE
GO

EXEC master.dbo.sp_configure 'xp_available media', 0
go
EXEC master.dbo.sp_configure 'xp_cmdshell', 0
go
EXEC master.dbo.sp_configure 'xp_dirtree', 0
go
EXEC master.dbo.sp_configure 'xp_dsninfo', 0
go
EXEC master.dbo.sp_configure 'xp_enumdsn', 0
go
EXEC master.dbo.sp_configure 'xp_enumerrorlogs', 0
go
EXEC master.dbo.sp_configure 'xp_enumgroups', 0
go
EXEC master.dbo.sp_configure 'xp_eventlog', 0
go
EXEC master.dbo.sp_configure 'xp_getfiledetails', 0
go
EXEC master.dbo.sp_configure 'xp_getnetname',0
go
EXEC master.dbo.sp_configure 'xp_logevent', 0
go
EXEC master.dbo.sp_configure 'xp_loginconfig', 0
go
EXEC master.dbo.sp_configure 'xp_servicecontrol', 0
go
EXEC master.dbo.sp_configure 'Default trace enabled', 1;  
go 
EXEC master.dbo.sp_configure 'xp_sprintf', 0
go
EXEC master.dbo.sp_configure 'Ad Hoc Distributed Queries', 0;  
go
EXEC master.dbo.sp_configure 'Database Mail XPs', 1;   
go
EXEC master.dbo.sp_configure 'clr enabled', 0;
go
EXEC master.dbo.sp_configure 'Cross db ownership chaining', 0;   
go
EXEC master.dbo.sp_configure 'xp_sscanf', 0
go
EXEC master.dbo.sp_configure 'xp_subdirs', 0
go
EXEC master.dbo.sp_configure 'xp_deletemail',0 
go
EXEC master.dbo.sp_configure 'xp_findnextmsg',0
go
EXEC master.dbo.sp_configure 'xp_deletemail',0 
go
EXEC master.dbo.sp_configure 'xp_findnextmsg',0
go
EXEC master.dbo.sp_configure 'xp_get_mapi_default_profile',0
go
EXEC master.dbo.sp_configure 'xp_get_mapi_profiles',0
go
EXEC master.dbo.sp_configure 'xp_readmail',0
go
EXEC master.dbo.sp_configure 'xp_startmail',0
go
EXEC master.dbo.sp_configure 'xp_stopmail',0
go
EXEC master.dbo.sp_configure 'xp_cleanupwebtask',0 
go 
EXEC master.dbo.sp_configure 'xp_convertwebtask',0 
go 
EXEC master.dbo.sp_configure 'xp_dropwebtask',0 
go 
EXEC master.dbo.sp_configure 'xp_enumcodepages',0 
go 
EXEC master.dbo.sp_configure 'xp_makewebtask',0 
go 
EXEC master.dbo.sp_configure 'xp_readwebtask',0 
go 
EXEC master.dbo.sp_configure 'xp_runwebtask',0 
go
EXEC master.dbo.sp_configure 'sp_OADestroy',0 
go 
EXEC master.dbo.sp_configure 'sp_OAGetErrorInfo',0 
go 
EXEC master.dbo.sp_configure 'sp_OAStop',0 
go
EXECUTE sp_configure 'Database Mail XPs', 1;
go
EXECUTE sp_configure 'Remote admin connections', 0;
go
EXECUTE sp_configure 'Scan for startup procs', 0;
go
REVOKE EXECUTE ON xp_regaddmultistring TO PUBLIC;
go
REVOKE EXECUTE ON xp_regdeletekey TO PUBLIC;
go
REVOKE EXECUTE ON xp_regdeletevalue TO PUBLIC;
go
REVOKE EXECUTE ON xp_regenumvalues TO PUBLIC;
go
REVOKE EXECUTE ON xp_regremovemultistring TO PUBLIC;
go
REVOKE EXECUTE ON xp_regwrite TO PUBLIC;
go
REVOKE EXECUTE ON xp_regread TO PUBLIC;
go
REVOKE EXECUTE ON xp_regaddmultistring TO PUBLIC;
go
REVOKE EXECUTE ON xp_regdeletekey TO PUBLIC;
go
REVOKE EXECUTE ON xp_regdeletevalue TO PUBLIC;
go
REVOKE EXECUTE ON xp_regenumvalues TO PUBLIC;
go
REVOKE EXECUTE ON xp_regremovemultistring TO PUBLIC;
go
REVOKE EXECUTE ON xp_regwrite TO PUBLIC;
go
REVOKE EXECUTE ON xp_regread TO PUBLIC;
go

sp_configure 'allow updates',0
go

RECONFIGURE WITH OVERRIDE
GO

EXEC master.dbo.sp_configure 'show advanced options', 0
RECONFIGURE WITH OVERRIDE
GO

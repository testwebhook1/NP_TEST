use distribution

select t.publisher_database_id, t.xact_seqno, 
      max(t.entry_time) as EntryTime, count(c.xact_seqno) as CommandCount, c.article_id
into #results
FROM MSrepl_commands c with (nolock)
LEFT JOIN  msrepl_transactions t with (nolock)
      on t.publisher_database_id = c.publisher_database_id 
      and t.xact_seqno = c.xact_seqno
                where t.entry_time > getdate() -2
GROUP BY t.publisher_database_id, t.xact_seqno, c.article_id

SELECT publisher_database_id, D.article_id
      ,datepart(year, EntryTime) as Year
      ,datepart(month, EntryTime) as Month 
      ,datepart(day, EntryTime) as Day
      ,datepart(hh, EntryTime) as Hour
      --,datepart(mi, EntryTime) as Minute
      ,sum(CommandCount) as CommandCountPerTimeUnit,source_owner, Source_object
FROM #results D left join MSArticles a on D.article_id = a.article_id 
GROUP BY publisher_database_id , D.article_id
      ,datepart(year, EntryTime)
      ,datepart(month, EntryTime)
      ,datepart(day, EntryTime)
      ,datepart(hh, EntryTime),source_owner, Source_object
      --,datepart(mi, EntryTime)
--order by publisher_database_id, sum(CommandCount) Desc
ORDER BY publisher_database_id, Month, Day, Hour, article_id,source_owner, Source_object

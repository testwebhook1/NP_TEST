***********************************************************/
/**********************************************************
---------------- Enable Database Mail XPs  ----------------
***********************************************************/

EXEC master.dbo.sp_configure 'show advanced options', 1
RECONFIGURE WITH OVERRIDE
GO
exec sp_configure 'Database Mail XPs',1
RECONFIGURE WITH OVERRIDE
GO

select 'DBMailAccount_Before' [Type],p.name [ProfileName],p.description [ProfileDesc],a.name [AccountName],a.description [AccountDesc],a.email_address,a.display_name,a.replyto_address,pp.is_default
from [msdb].[dbo].[sysmail_profile] p join [msdb].[dbo].[sysmail_profileaccount] pa on p.profile_id=pa.profile_id
join [msdb].[dbo].[sysmail_account] a on pa.account_id=a.account_id join [msdb].[dbo].[sysmail_principalprofile] pp on p.profile_id=pp.profile_id
where p.name in ('SQLServerMail','SQLDBAMail') and p.description like 'Mail for SQL%'

IF NOT EXISTS(select 'DBMailAccount_Before' [Type],p.name [ProfileName],p.description [ProfileDesc],a.name [AccountName],a.description [AccountDesc],a.email_address,a.display_name,a.replyto_address,pp.is_default
from [msdb].[dbo].[sysmail_profile] p join [msdb].[dbo].[sysmail_profileaccount] pa on p.profile_id=pa.profile_id
join [msdb].[dbo].[sysmail_account] a on pa.account_id=a.account_id join [msdb].[dbo].[sysmail_principalprofile] pp on p.profile_id=pp.profile_id
where p.name in ('SQLServerMail','SQLDBAMail') and p.description like 'Mail for SQL%')
BEGIN
	-- Create a Database Mail account  
	EXECUTE msdb.dbo.sysmail_add_account_sp  
		@account_name = 'SQLDBAMail',  
		@description = 'SQLServer DBA Mail',  
		@email_address = 'SQLServerJobAlert@moodys.com',  
		@replyto_address = 'No-Reply@Moodys.com',  
		@display_name = 'SQLServer Job Alert',  
		@mailserver_name = 'exmx.moodys.com' ;  

	-- Create a Database Mail profile  
	EXECUTE msdb.dbo.sysmail_add_profile_sp  
		@profile_name = 'SQLDBAMail',  
		@description = 'Mail for SQLServer' ;  

	-- Add the account to the profile  
	EXECUTE msdb.dbo.sysmail_add_profileaccount_sp  
		@profile_name = 'SQLDBAMail',  
		@account_name = 'SQLDBAMail',  
		@sequence_number =1 ;  

	-- Grant access to the profile to all users in the msdb database  
	EXECUTE msdb.dbo.sysmail_add_principalprofile_sp  
		@profile_name = 'SQLDBAMail',  
		@principal_name = 'public',  
		@is_default = 1 ;  

	
END
ELSE -- If exists
BEGIN

declare @act_id int,@prof_id int
select @prof_id=pa.profile_id,@act_id=pa.account_id from [msdb].[dbo].[sysmail_profile] p join [msdb].[dbo].[sysmail_profileaccount] pa on p.profile_id=pa.profile_id
join [msdb].[dbo].[sysmail_account] a on pa.account_id=a.account_id join [msdb].[dbo].[sysmail_principalprofile] pp on p.profile_id=pp.profile_id
where p.name in ('SQLServerMail','SQLDBAMail') and p.description like 'Mail for SQL%'

exec msdb..sysmail_update_account_sp @account_id=@act_id,
	@account_name = 'SQLDBAMail',  
	@description = 'SQLServer DBA Mail',  
	@email_address = 'SQLServerJobAlert@moodys.com',  
	@replyto_address = 'No-Reply@Moodys.com',  
	@display_name = 'SQLServer Job Alert',  
	@mailserver_name = 'exmx.moodys.com' ; 

exec msdb..sysmail_update_profile_sp @profile_id=@prof_id,
	@profile_name = 'SQLDBAMail',  
    @description = 'Mail for SQLServer' 

END

GO

USE [msdb]
IF (OBJECT_ID('sp_send_dbmail_moodys') IS NOT NULL)
DROP PROCEDURE [dbo].[sp_send_dbmail_moodys] 
GO
CREATE PROCEDURE [dbo].[sp_send_dbmail_moodys] 
				@MailSubject varchar(1000) = '' ,@ErrorMessage varchar(2048) = '== SQLServer Database Mail =='
AS
BEGIN
	SET NOCOUNT ON;

	declare @strMailSubject varchar(1024)
	set @strMailSubject = '< ' + @@Servername + ' > ' + @MailSubject

	EXEC msdb.dbo.sp_send_dbmail 
		@profile_name = 'SQLDBAMail', 
		@recipients = 'SQLServerSupport@moodys.com;', 
		@body = @ErrorMessage, 
		@subject = @strMailSubject
END
GO
	--exec msdb.dbo.sp_send_dbmail_moodys 'Please Ignore! Testing. '

select 'DBMailAccount_After' [Type],p.name [ProfileName],p.description [ProfileDesc],a.name [AccountName],a.description [AccountDesc],a.email_address,a.display_name,a.replyto_address,pp.is_default
from [msdb].[dbo].[sysmail_profile] p join [msdb].[dbo].[sysmail_profileaccount] pa on p.profile_id=pa.profile_id
join [msdb].[dbo].[sysmail_account] a on pa.account_id=a.account_id join [msdb].[dbo].[sysmail_principalprofile] pp on p.profile_id=pp.profile_id
where p.name in ('SQLServerMail','SQLDBAMail') and p.description like 'Mail for SQL%'
GO

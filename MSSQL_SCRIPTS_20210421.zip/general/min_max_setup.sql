/**********************************************************
---------- SETUP MIN/MAX Memory for SQL Instance ----------
***********************************************************/

DECLARE @total_mem decimal(20,2),
		@min INT = 2048,
		@max INT,
		@SQLver INT,
		@dynSQL1 NVARCHAR (100),
		@dynSQL2 NVARCHAR (100),
		@dynDef NVARCHAR (100) 

SET NOCOUNT ON
SELECT @SQLver = @@MICROSOFTVERSION/0x01000000

SELECT @dynSQL1 = (SELECT CASE
WHEN @SQLver >= 11
THEN 'physical_memory_kb'
ELSE 'physical_memory_in_bytes'
END AS PhysMemMB FROM sys.dm_os_sys_info)

SET @dynSQL2 = 'SELECT @total_memOUT = ' +@dynSQL1+ ' FROM sys.dm_os_sys_info';
SET @dynDef = N'@total_memOUT decimal(20,2) OUTPUT';
EXEC SP_EXECUTESQL @dynSQL2, @dynDef, @total_memOUT=@total_mem OUTPUT

IF @SQLver >=11
SELECT @max = (@total_mem *(8.5 / 10.0))/(1024) 
ELSE
SELECT @max = (@total_mem *(8.5 / 10.0))/(1024*1024) 

EXEC sp_configure 'show advanced options',1
RECONFIGURE
EXEC sp_configure 'min server memory (MB)',@min
EXEC sp_configure 'max server memory (MB)',@max
EXEC sp_configure 'show advanced options',0
RECONFIGURE
GO

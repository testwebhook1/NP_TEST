/**********************************************************
---------------- Job to Purge JOB History -----------------
***********************************************************/

USE [msdb]
GO

/****** Object:  Job [DBA Log Purging]    Script Date: 7/19/2018 11:40:00 PM ******/
IF EXISTS(select name from msdb..sysjobs where name = 'DBA Log Purging')
EXEC msdb.dbo.sp_delete_job @job_name=N'DBA Log Purging', @delete_unused_schedule=1
GO


/****** Object:  Job [DBA Log Purging]    Script Date: 7/19/2018 11:40:00 PM ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 7/19/2018 11:40:00 PM ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'DBA Log Purging', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'--Deletes 2 weeks old error log files
--Deletes 8 weeks old MSDB backup/restore history
--Deletes 2 weeks old Job history log for every job
--Deletes 8 weeks old Maintenance plan history logs', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [LogPurge]    Script Date: 7/19/2018 11:40:00 PM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'LogPurge', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=4, 
		@on_fail_step_id=2, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'USE master
DECLARE @spath varchar(500), @dt datetime, @st varchar(500), @cutoff_date datetime

CREATE table #tmp (Logdate datetime, processinfo varchar(20), logtext varchar(100))
INSERT into #tmp 
EXEC sp_readerrorlog 1,1,''Logging''

--SELECT @spath =  [path] FROM Sys.dm_os_server_diagnostics_log_configurations

select @spath=logtext from #tmp
select @spath=rtrim(ltrim(right(@spath, len(@spath)-charindex(''file'',@spath)-4)))
select @spath=rtrim(replace(@spath,'''''''',''''))
select @spath=left(@spath, len(@spath)-1)
select @spath=right(reverse(@spath), len(@spath)-charindex(''\'',reverse(@spath))+1)
select @spath=reverse(@spath)
drop table #tmp

--- Cleanup Maintenance Plan report files -- 2 weeks before 
SET @cutoff_date = DATEADD(day, -15, GETDATE());
EXECUTE master.dbo.xp_delete_file 1,@spath,N''txt'',@dt
EXEC msdb.dbo.sp_purge_jobhistory  @oldest_date=@cutoff_date

--- History cleanup Task -- 8 weeks before 
SET @cutoff_date = DATEADD(day, -56, GETDATE());
EXEC msdb.dbo.sp_delete_backuphistory @cutoff_date

EXECUTE msdb..sp_maintplan_delete_log null,null,@cutoff_date
GO 
', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [SendNotiF]    Script Date: 7/19/2018 11:40:00 PM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'SendNotiF', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=2, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @strMailSubject varchar(1024)
set @strMailSubject = ''< '' + @@Servername + '' > '' + ''Job Failure : DB Maintenance - Weekly'' 

EXEC msdb.dbo.sp_send_dbmail 
     @profile_name = ''SQLDBAMail'', 
     @recipients = ''SQLServerSupport@moodys.com;'', 
     @body = ''Job Failure : DBA Log history Purging'',
     @subject = @strMailSubject', 
		@database_name=N'msdb', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'WeeklySchedule', 
		@enabled=1, 
		@freq_type=8, 
		@freq_interval=64, --Not to be changed unless day needs to be changed
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1,
 		@active_start_time=220000 --Not to be changed unless time needs to be changed
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO

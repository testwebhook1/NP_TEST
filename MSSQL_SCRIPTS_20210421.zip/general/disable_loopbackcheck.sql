/**********************************************************
---------- DisableLookbackCheck for A-RECORD --------------
***********************************************************/

EXEC xp_instance_regwrite
      @rootkey = N'HKEY_LOCAL_MACHINE',
      @key =N'SYSTEM\CurrentControlSet\Control\Lsa',
      @value_name = N'DisableLoopbackCheck',
      @type = N'REG_DWORD',
      @value = 1
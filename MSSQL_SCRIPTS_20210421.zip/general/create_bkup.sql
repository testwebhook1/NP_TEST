
/****************************************************************************
------------- Create DB Backup/Cleaunup SP Modified by Arun on 10/9/2019---------------
****************************************************************************/
USE [master]
GO

/****** Object:  StoredProcedure [dbo].[usp_BackupDatabases]    Script Date: 10/9/2019 10:14:54 AM ******/
DROP PROCEDURE [dbo].[usp_BackupDatabases]
GO

/****** Object:  StoredProcedure [dbo].[usp_BackupDatabases]    Script Date: 10/9/2019 10:14:54 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



CREATE PROCEDURE [dbo].[usp_BackupDatabases]
@backupType CHAR(5)= null, 
@defaultType CHAR(10) = null,
@filePath VARCHAR(255) = null,
@LogPath VARCHAR(255) = null,
@logdir VARCHAR(255) = null,
@tmpName NVARCHAR(50) = null,
@fileName NVARCHAR(255) = null,
@fileDate NVARCHAR(20) = null,
@expDBs NVARCHAR(255) = null

--@dynSQL NVARCHAR(255) = null

AS
SET NOCOUNT ON; 

SELECT @fileDate = CONVERT(VARCHAR, GETDATE(),112) + '_' +  REPLACE(CONVERT(VARCHAR, GETDATE(),108),':','')   
EXEC master..xp_instance_regread @rootkey = 'HKEY_LOCAL_MACHINE', @key = 'Software\Microsoft\MSSQLServer\MSSQLServer',  
    @value_name = 'BackupDirectory', @BackupDirectory = @filePath OUTPUT ;
EXEC xp_create_subdir @filepath
IF @defaultType = 'F' -- Begin loop for Full backup
BEGIN
IF @backupType = 'A' -- Begin loop for All database
BEGIN
DECLARE db_cursor CURSOR READ_ONLY FOR  

SELECT name 
FROM sys.databases 
WHERE 
state ='0' and 
user_access_desc <> 'SINGLE_USER' and 
is_read_only = 0 and
name not in ('tempdb','distribution')

OPEN db_cursor   
FETCH NEXT FROM db_cursor INTO @tmpName   

WHILE @@FETCH_STATUS = 0   
BEGIN
   SET @fileName = @filePath +'\' + @tmpName + '_' + @fileDate + '.BAK'
   --SET @dynSQL = 'BACKUP '+ @defaultType +' [' + @tmpName + '] TO DISK='+ @fileName
   --EXECUTE sp_executesql @dynSQL
   BACKUP DATABASE @tmpName TO DISK = @fileName  
   FETCH NEXT FROM db_cursor INTO @tmpName   
END   
CLOSE db_cursor   
DEALLOCATE db_cursor
END

ELSE IF @backupType = 'S' --Beign Loop for Specific db's mentioned in @expDBs
BEGIN
DECLARE db_cursor CURSOR READ_ONLY FOR  
SELECT name 
FROM sys.databases 
WHERE 
name IN (@expDBs) and 
state ='0' and 
is_read_only = '0' and
user_access_desc <> 'SINGLE_USER'
 
OPEN db_cursor   
FETCH NEXT FROM db_cursor INTO @tmpName   
 
WHILE @@FETCH_STATUS = 0   
BEGIN
   SET @fileName = @filePath +'\' + @tmpName + '_' + @fileDate + '.BAK'
   --SET @dynSQL = 'BACKUP '+ @defaultType +' [' + @tmpName + '] TO DISK='+ @fileName
   --EXECUTE sp_executesql @dynSQL
   BACKUP DATABASE @tmpName TO DISK = @fileName  
   FETCH NEXT FROM db_cursor INTO @tmpName   
END   
CLOSE db_cursor   
DEALLOCATE db_cursor
END

ELSE IF @backupType = 'E' --Begin loop to exclude DB's in @expDBs
BEGIN
DECLARE db_cursor CURSOR READ_ONLY FOR  
SELECT name 
FROM sys.databases
WHERE 
name NOT IN (@expDBs) and 
state ='0' and 
is_read_only = '0' and
user_access_desc <> 'SINGLE_USER' and
name not in ('tempdb','distribution')
 
OPEN db_cursor   
FETCH NEXT FROM db_cursor INTO @tmpName   
 
WHILE @@FETCH_STATUS = 0   
BEGIN
   SET @fileName = @filePath +'\' + @tmpName + '_' + @fileDate + '.BAK'
   --SET @dynSQL = 'BACKUP '+ @defaultType +' [' + @tmpName + '] TO DISK='+ @fileName
   --EXECUTE sp_executesql @dynSQL
   BACKUP DATABASE @tmpName TO DISK = @fileName  
   FETCH NEXT FROM db_cursor INTO @tmpName   
END   
CLOSE db_cursor   
DEALLOCATE db_cursor
END

ELSE
PRINT 'Please specify backupType = A/S/E'
END

ELSE IF @defaultType = 'L' --Begin loop for Log backup
BEGIN
IF @backupType = 'A' --Being loop for log backup of all databases which are online and recovery is full
BEGIN
DECLARE db_cursor CURSOR READ_ONLY FOR  
SELECT name 
FROM sys.databases 
WHERE 
state ='0' and 
user_access_desc <> 'SINGLE_USER' and 
is_read_only = '0' and 
recovery_model_desc ='FULL' 
and name not in (SELECT primary_database FROM msdb..log_shipping_primary_databases)
and name not in ('tempdb','distribution')

OPEN db_cursor   
FETCH NEXT FROM db_cursor INTO @tmpName   

WHILE @@FETCH_STATUS = 0   
BEGIN
/*
EXEC master..xp_instance_regread @rootkey = 'HKEY_LOCAL_MACHINE', @key = 'Software\Microsoft\MSSQLServer\MSSQLServer',  
    @value_name = 'BackupDirectory', @BackupDirectory = @filePath OUTPUT ;
EXEC xp_create_subdir @filepath
*/
   set @logdir='Tlog_Backup'
   SET @LogPath= @filePath +'\' + @logdir
   EXEC xp_create_subdir @logpath
   SET @fileName = @LogPath +'\' + @tmpName + '_' + @fileDate + '.TRN'
   --SET @dynSQL = 'BACKUP '+ @defaultType +' [' + @tmpName + '] TO DISK='+ @fileName
   --EXECUTE sp_executesql @dynSQL
   BACKUP LOG @tmpName TO DISK = @fileName  
   FETCH NEXT FROM db_cursor INTO @tmpName   
END   
CLOSE db_cursor   
DEALLOCATE db_cursor
END

ELSE IF @backupType = 'S' -- Loop for specific db's
BEGIN
DECLARE db_cursor CURSOR READ_ONLY FOR  
SELECT name 
FROM sys.databases 
WHERE 
name IN (@expDBs) and 
state ='0' and 
is_read_only = '0' and 
recovery_model_desc ='FULL' and
user_access_desc <> 'SINGLE_USER'
 
OPEN db_cursor   
FETCH NEXT FROM db_cursor INTO @tmpName   
 
WHILE @@FETCH_STATUS = 0   
BEGIN
   SET @fileName = @filePath +'\' + @tmpName + '_' + @fileDate + '.TRN'
   --SET @dynSQL = 'BACKUP '+ @defaultType +' [' + @tmpName + '] TO DISK='+ @fileName
   --EXECUTE sp_executesql @dynSQL
   BACKUP LOG @tmpName TO DISK = @fileName  
   FETCH NEXT FROM db_cursor INTO @tmpName   
END   
CLOSE db_cursor   
DEALLOCATE db_cursor
END

ELSE IF @backupType = 'E' --Loop to exclude DBs 
BEGIN
DECLARE db_cursor CURSOR READ_ONLY FOR  
SELECT name 
FROM sys.databases
WHERE 
name NOT IN (@expDBs) and 
state ='0' and 
is_read_only = '0' and
user_access_desc <> 'SINGLE_USER' and 
recovery_model_desc = 'FULL' 
 
OPEN db_cursor   
FETCH NEXT FROM db_cursor INTO @tmpName   
 
WHILE @@FETCH_STATUS = 0
BEGIN
   SET @fileName = @filePath +'\' + @tmpName + '_' + @fileDate + '.TRN'
   --SET @dynSQL = 'BACKUP '+ @defaultType +' [' + @tmpName + '] TO DISK='+ @fileName
   --EXECUTE sp_executesql @dynSQL
   BACKUP LOG @tmpName TO DISK = @fileName  
   FETCH NEXT FROM db_cursor INTO @tmpName   
END   
CLOSE db_cursor   
DEALLOCATE db_cursor
END

ELSE
PRINT 'Please specify backupType = A/S/E'
END

ELSE
PRINT 'Please specify defaultType = F/L'


GO


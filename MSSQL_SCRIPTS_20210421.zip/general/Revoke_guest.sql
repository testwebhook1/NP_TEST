/**********************************************************
---------- Revoke CONNECT Permissions On 'Guest' ----------
***********************************************************/

EXECUTE master.sys.sp_MSforeachdb 'USE [?]; REVOKE CONNECT FROM guest'
go
USE msdb;
go
GRANT connect TO guest;
go


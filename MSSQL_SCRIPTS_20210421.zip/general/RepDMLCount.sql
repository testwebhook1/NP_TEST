declare @tableHTML varchar(max), @subject varchar(100), @att_path varchar(3000)
SET @tableHTML = '<table border="1" >' +    
'<tr > Dear Team, </tr><tr> Please find the attached Replicated DML Rowcount (csv) for server %%d_server%% </tr>
<tr>Regards,</tr><tr>SQL Server team</tr></table>'

select @att_path = '%%attpath%%'
select @subject='<%%d_server%%> -::- Replication DML Rowcount -::-'

EXEC msdb.dbo.sp_send_dbmail      
      @recipients='%%to_email%%',
   --@recipients='NileshR.Patel@moodys.com;Deepak.Vispute-non-empl@moodys.com;SQLServerSupport@moodys.com;',
   -- @recipients='Deepak.Vispute-non-empl@moodys.com;',
	@copy_recipients='%%cc_email%%',    
	@subject = @subject,    
	@body = @tableHTML,    
	@body_format = 'HTML' ,
	@file_attachments = @att_path;    

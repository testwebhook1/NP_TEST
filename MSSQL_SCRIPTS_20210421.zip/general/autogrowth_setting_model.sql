/**********************************************************
---------------- Change Recovery for Model ----------------
***********************************************************/

IF EXISTS(SELECT * FROM sys.databases WHERE name = 'model' and recovery_model_desc <> 'SIMPLE')
ALTER DATABASE model SET RECOVERY SIMPLE
GO
USE [master]
GO
ALTER DATABASE [model] MODIFY FILE ( NAME = N'modeldev', FILEGROWTH = 131072KB )
GO
ALTER DATABASE [model] MODIFY FILE ( NAME = N'modellog', FILEGROWTH = 131072KB )
GO

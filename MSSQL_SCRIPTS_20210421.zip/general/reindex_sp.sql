/**********************************************************
------------------- Create reindex SP ---------------------
***********************************************************/

USE [master]
GO

/****** Object:  StoredProcedure [dbo].[rebuild_reorg_index]    ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[rebuild_reorg_index]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[rebuild_reorg_index]
GO

USE [master]
GO

/****** Object:  StoredProcedure [dbo].[rebuild_reorg_index]    ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [dbo].[rebuild_reorg_index]

@databaseToCheck VARCHAR(250) = NULL,
@fragmentationThreshold VARCHAR(10) = 10,
@indexFillFactor VARCHAR(5) = 90,
@reportOnly BIT = 0,
@doonline VARCHAR(5) = 'OFF',
@sortInTempdb VARCHAR(5) = 'ON'
-- created by Animesh 5/23/2017
-- monified by Nilesh 5/23/2017 filter added using table for flexibility
-- modified by Nilesh 5/24/2017 Try catch added.
-- modified by nilesh 5/25/2017 error count and information & softinTempDB parameter
-- modified by nilesh 5/25/2017 copy from other version for exsits condition and print date+table name
-- modified by Animesh 5/26/2017 added on line and off line both reindex with error msg executing second one too
-- Ver_201705_05

AS

BEGIN

  SET NOCOUNT ON

  SET ARITHABORT ON

  SET NUMERIC_ROUNDABORT OFF


--Initial check - You must be SysAdmin
DECLARE @isSysAdmin INT
SET @isSysAdmin=(SELECT IS_SRVROLEMEMBER ('sysadmin'));

--Initial check - You must be using SQL Server 2005 or later
DECLARE @SQLServerVersion INT
SET @SQLServerVersion=(SELECT CAST(LEFT(CAST(SERVERPROPERTY('ProductVersion') AS VARCHAR(50)),CHARINDEX('.',CAST

(SERVERPROPERTY('ProductVersion') AS VARCHAR(50)))-1) AS INT));

declare    @msg varchar(800), @errcount int
set @msg='* successfully over *'
set @errcount = 0

IF @isSysAdmin=1 AND @SQLServerVersion >= 9
BEGIN 

-- Variable/parameters Declaration
DECLARE @dbname NVARCHAR(128);
DECLARE @ReorganizeOrRebuildCommand NVARCHAR(MAX);
DECLARE @ReorganizeOrRebuildCommandExp NVARCHAR(MAX);
DECLARE @dbid INT;
--DECLARE @indexFillFactor VARCHAR(5); 
--DECLARE @fragmentationThreshold VARCHAR(10);
DECLARE @indexStatisticsScanningMode VARCHAR(20);
DECLARE @verboseMode BIT;
--DECLARE @reportOnly BIT;
-- DECLARE @sortInTempdb VARCHAR(3);
DECLARE @isHadrEnabled BIT;
--DECLARE @databaseToCheck VARCHAR(250)
DECLARE @dynamic_command NVARCHAR(1024);
DECLARE @dynamic_command_get_tables NVARCHAR(MAX);
DECLARE @schemaname NVARCHAR(255);
DECLARE @tablename NVARCHAR(255);

--Initializations - Do not change
--SET @databaseToCheck=NULL;
SET @dynamic_command = NULL;
SET @dynamic_command_get_tables = NULL;
SET @isHadrEnabled=0;

--SET NOCOUNT ON;

---------------------------------------------------------
--Set Parameter Values: You can change these (optional) -
--Note: The script has default parameters set   -
---------------------------------------------------------
--if set to 1: it will just generate a report with the index reorganization/rebuild statements
--if set to 0: it will reorganize or rebuild the fragmented indexes
--SET @reportOnly = 0;

--optional: if not set (NULL), it will scann all databases
--If name is set (i.e. 'testDB') it will just scan the given database
--SET @databaseToCheck = NULL;

--maintains only the indexes that have average fragmentation percentage equal or higher from the given value
--SET @fragmentationThreshold = 15;

--fill factor - the percentage of the data page to be filled up with index data
--SET @indexFillFactor = 90;

--sets the scanning mode for index statistics 
--available values: 'DEFAULT', NULL, 'LIMITED', 'SAMPLED', or 'DETAILED'
SET @indexStatisticsScanningMode='SAMPLED';

--if set to ON: sorts intermediate index results in TempDB 
--if set to OFF: sorts intermediate index results in user database's log file
--SET @sortInTempdb='ON'; 

--if set to 0: Does not output additional information about the index reorganization/rebuild process
--if set to 1: Outputs additional information about the index reorganization/rebuild process
SET @verboseMode = 1; 
------------------------------
--End Parameter Values Setup -
------------------------------

-- check if given database exists and if compatibility level >= SQL 2005 (90)
IF @verboseMode=1
 PRINT 'Checking if database '+@databaseToCheck+' exists and if compatibility level equals or greater 2005 (90)';

 -- if given database does not exist, raise error with severity 20
 -- in order to terminate script's execution
IF @databaseToCheck IS NOT NULL
BEGIN
 DECLARE @checkResult INT
 SET @checkResult=(SELECT COUNT(*) FROM master.sys.databases WHERE [name]=RTRIM(@databaseToCheck));
 IF @checkResult<1
  RAISERROR('Error executing index reorganization/rebuild script: Database does not exist' , 20, 1) WITH LOG;

 DECLARE @checkResult2 INT
 SET @checkResult=(SELECT [compatibility_level] FROM master.sys.databases WHERE [name]=RTRIM(@databaseToCheck));
 IF @checkResult<90
  RAISERROR('Error executing index reorganization/rebuild script: Only databases with SQL Server 2005 or later 

compatibility level are supported' , 20, 1) WITH LOG;  
END

IF @verboseMode=1
 PRINT 'Initial checks completed with no errors.';

-- Temporary table for storing index fragmentation details
IF OBJECT_ID('tempdb..#tmpFragmentedIndexes') IS NULL
BEGIN
CREATE TABLE #tmpFragmentedIndexes
    (
      [dbName] sysname,
      [tableName] sysname,
   [schemaName] sysname,
      [indexName] sysname,
      [databaseID] SMALLINT ,
      [objectID] INT ,
      [indexID] INT ,
      [AvgFragmentationPercentage] FLOAT,
   [reorganizationOrRebuildCommand] NVARCHAR(MAX),
   [reorganizationOrRebuildCommandExp] NVARCHAR(MAX)
    );
END 

-- Initialize temporary table
DELETE FROM #tmpFragmentedIndexes;

-- Validate parameters/set defaults
IF @sortInTempdb NOT IN ('ON','OFF')
SET @sortInTempdb='ON';

-- Check if instance has AlwaysOn AGs enabled
SET @isHadrEnabled=CAST((SELECT ISNULL(SERVERPROPERTY('IsHadrEnabled'),0)) AS BIT);

-- if database not specified scan all databases
IF @databaseToCheck IS NULL
BEGIN
DECLARE dbNames_cursor CURSOR
FOR
    SELECT  s.[name] AS dbName ,
            s.database_id
    FROM    master.sys.databases s            
    WHERE   s.state_desc = 'ONLINE'
            AND s.is_read_only != 1            
            AND s.[name] NOT IN ( 'master', 'model', 'tempdb' )
   AND s.[compatibility_level]>=90
    ORDER BY s.database_id;    
END 
ELSE
-- if database specified, scan only that database
BEGIN
DECLARE dbNames_cursor CURSOR 
FOR
    SELECT  s.[name] AS dbName ,
            s.database_id
    FROM    master.sys.databases s            
    WHERE   s.state_desc = 'ONLINE'
            AND s.is_read_only != 1                        
   AND s.[name]=RTRIM(@databaseToCheck)    
END 

-- if Always On Availability Groups are enabled, check for primary databases
-- (thus exclude secondary databases)
IF @isHadrEnabled=1
BEGIN

DEALLOCATE dbNames_cursor;

-- if database not specified scan all databases
IF @databaseToCheck IS NULL
BEGIN
 DECLARE dbNames_cursor CURSOR
 FOR
  SELECT  s.[name] AS dbName ,
    s.database_id
  FROM    master.sys.databases s
    LEFT JOIN master.sys.dm_hadr_availability_replica_states r ON s.replica_id = r.replica_id
  WHERE   s.state_desc = 'ONLINE'
    AND s.is_read_only != 1
    AND UPPER(ISNULL(r.role_desc, 'NonHadrEnabled')) NOT LIKE 'SECONDARY'
    AND s.[name] NOT IN ( 'master', 'model', 'tempdb' )
    AND s.[compatibility_level]>=90 
  ORDER BY s.database_id;    
END
ELSE
-- if database specified, scan only that database
BEGIN
 DECLARE dbNames_cursor CURSOR
 FOR
  SELECT  s.[name] AS dbName ,
    s.database_id
  FROM    master.sys.databases s
    LEFT JOIN master.sys.dm_hadr_availability_replica_states r ON s.replica_id = r.replica_id
  WHERE   s.state_desc = 'ONLINE'
    AND s.is_read_only != 1
    AND UPPER(ISNULL(r.role_desc, 'NonHadrEnabled')) NOT LIKE 'SECONDARY'    
    AND s.[name]=RTRIM(@databaseToCheck);  
END 
END 


--
-- For each database included in the cursor, 
-- gather all tables that have indexes with 
-- average fragmentation percentage equal or above @fragmentationThreshold
--
OPEN dbNames_cursor;
FETCH NEXT FROM dbNames_cursor INTO @dbname, @dbid;
WHILE @@fetch_status = 0
    BEGIN   
 
 --If verbose mode is enabled, print logs
        IF @verboseMode = 1
            BEGIN
    PRINT ''
                PRINT 'Gathering index fragmentation statistics for database: ['+ @dbname + '] with id: ' + CAST

(@dbid AS VARCHAR(10));    
            END;
                   
        SET @dynamic_command_get_tables = N'
 USE [' + @dbname+ N'];
 INSERT INTO #tmpFragmentedIndexes (
  [dbName],
  [tableName],
  [schemaName],
  [indexName],
  [databaseID],
  [objectID],
  [indexID],
  [AvgFragmentationPercentage],
  [reorganizationOrRebuildCommand],
  [reorganizationOrRebuildCommandExp] 
  )
  SELECT
     DB_NAME() as [dbName], 
     tbl.name as [tableName],
     SCHEMA_NAME (tbl.schema_id) as schemaName, 
     idx.Name as [indexName], 
     pst.database_id as [databaseID], 
     pst.object_id as [objectID], 
     pst.index_id as [indexID], 
     pst.avg_fragmentation_in_percent as [AvgFragmentationPercentage],
     CASE WHEN pst.avg_fragmentation_in_percent > 30 THEN 
     ''ALTER INDEX [''+idx.Name+''] ON [''+DB_NAME()+''].[''+SCHEMA_NAME (tbl.schema_id)+''].[''+tbl.name+''] 

REBUILD WITH (FILLFACTOR = '+@indexFillFactor+', SORT_IN_TEMPDB = '+@sortInTempdb+',ONLINE = '+ @doonline++',  STATISTICS_NORECOMPUTE = 

OFF);''
     WHEN pst.avg_fragmentation_in_percent > 5 AND pst.avg_fragmentation_in_percent <= 30 THEN 
     ''ALTER INDEX [''+idx.Name+''] ON [''+DB_NAME()+''].[''+SCHEMA_NAME (tbl.schema_id)+''].[''+tbl.name+''] 

REORGANIZE;''     
     ELSE
     NULL
     END,
	 CASE WHEN pst.avg_fragmentation_in_percent > 30 THEN 
     ''ALTER INDEX [''+idx.Name+''] ON [''+DB_NAME()+''].[''+SCHEMA_NAME (tbl.schema_id)+''].[''+tbl.name+''] 

REBUILD WITH (FILLFACTOR = '+@indexFillFactor+', SORT_IN_TEMPDB = '+@sortInTempdb+',ONLINE = OFF,  STATISTICS_NORECOMPUTE = 

OFF);''     
     ELSE
     NULL
     END
  FROM sys.dm_db_index_physical_stats(DB_ID(), NULL, NULL, NULL , '''+@indexStatisticsScanningMode+''') as pst
   INNER JOIN sys.tables as tbl ON pst.object_id = tbl.object_id
   INNER JOIN sys.indexes idx ON pst.object_id = idx.object_id AND pst.index_id = idx.index_id
  WHERE pst.index_id != 0  
   AND pst.alloc_unit_type_desc IN ( N''IN_ROW_DATA'', N''ROW_OVERFLOW_DATA'')
   AND pst.avg_fragmentation_in_percent >= '+ @fragmentationThreshold + '';
   
        
  -- if verbose  mode is enabled, print logs    
  IF @verboseMode=1
   BEGIN
    PRINT 'Index fragmentation statistics script: ';    
    PRINT @dynamic_command_get_tables;
  END

  -- gather index fragmentation statistics
        EXEC (@dynamic_command_get_tables);
       
     -- bring next record from the cursor
        FETCH NEXT FROM dbNames_cursor INTO @dbname, @dbid;
    END;

CLOSE dbNames_cursor;
DEALLOCATE dbNames_cursor;
-----------------------------------
--**Nilesh

If OBJECT_ID('dbo.MITDBA_Maintenance') is null
BEGIN 
	set @dynamic_command_get_tables = '

CREATE TABLE [dbo].[MITDBA_Maintenance](
	[MITId] [int] NOT NULL,
	[EntryDate] [datetime] NOT NULL,
	[UpdateDate] [datetime] NOT NULL,
	[DBName] [sysname] NOT NULL,
	[SchemaName] [sysname] NOT NULL,
	[TableName] [sysname] NOT NULL,
	[indexName] [sysname] NOT NULL,
	[IgnoreYN] [char](1) NOT NULL,
	[rebuildCMD] [varchar](200) NULL,
	[reOrgCMD] [varchar](200) NULL,
	[RecActiveYN] [char](1) NULL,
PRIMARY KEY CLUSTERED 
(
	[DBName] ASC,
	[SchemaName] ASC,
	[TableName] ASC,
	[indexName] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

ALTER TABLE [dbo].[MITDBA_Maintenance] ADD  CONSTRAINT [DF__MITDBA_Maint_Ignore]  DEFAULT (''Y'') FOR [IgnoreYN]
ALTER TABLE [dbo].[MITDBA_Maintenance] ADD  CONSTRAINT [DF__MITDBA_Maint_active]  DEFAULT (''Y'') FOR [RecActiveYN]
'
  EXEC (@dynamic_command_get_tables);
END
-- skip whoe database
delete #tmpFragmentedIndexes from #tmpFragmentedIndexes T  join
       master.[dbo].[MITDBA_Maintenance] ING on T.dbName = ING.[DBName] and ING.[SchemaName] = '*'
              where ING.RecActiveYN = 'Y' and ING.IgnoreYN = 'Y'
-- skip entire schema
delete #tmpFragmentedIndexes from #tmpFragmentedIndexes T  join
       master.[dbo].[MITDBA_Maintenance] ING on T.dbName = ING.[DBName] and t.schemaName = ING.[SchemaName] 
                     and ING.[TableName] = '*'
              where ING.RecActiveYN = 'Y' and ING.IgnoreYN = 'Y'
-- skip whole table
delete #tmpFragmentedIndexes from #tmpFragmentedIndexes  T  join
       master.[dbo].[MITDBA_Maintenance] ING on T.dbName = ING.[DBName] and t.schemaName = ING.[SchemaName]
              and T.tableName = ING.[TableName] and ING.indexName='*'
				and ING.RecActiveYN = 'Y' and ING.IgnoreYN = 'Y'
-- skip table+index
delete #tmpFragmentedIndexes from #tmpFragmentedIndexes  T  join
       master.[dbo].[MITDBA_Maintenance] ING on T.dbName = ING.[DBName] and t.schemaName = ING.[SchemaName]
              and T.tableName = ING.[TableName] and T.indexName = ING.indexName
				and ING.RecActiveYN = 'Y' and ING.IgnoreYN = 'Y'
--update customized command 
UPDATE #tmpFragmentedIndexes SET reorganizationOrRebuildCommand = [reOrgCMD]
       from #tmpFragmentedIndexes  T  join
       master.[dbo].[MITDBA_Maintenance] ING on T.dbName = ING.[DBName] and t.schemaName = ING.[SchemaName]
              and T.tableName = ING.[TableName] and T.indexName = ING.indexName and ING.RecActiveYN = 'Y'
       where reorganizationOrRebuildCommand like '%REORGANIZE%'
UPDATE #tmpFragmentedIndexes SET reorganizationOrRebuildCommand = [rebuildCMD]
       from #tmpFragmentedIndexes  T  join
       master.[dbo].[MITDBA_Maintenance] ING on T.dbName = ING.[DBName] and t.schemaName = ING.[SchemaName]
              and T.tableName = ING.[TableName] and T.indexName = ING.indexName and ING.RecActiveYN = 'Y'
	   where T.reorganizationOrRebuildCommand like '%REBUILD%'

------------------------------------------------------------

-- if 'report only' mode is enabled
IF @reportOnly=1
BEGIN 
 SELECT  dbName ,
            tableName ,
            schemaName ,
            indexName ,            
            AvgFragmentationPercentage ,
            reorganizationOrRebuildCommand,
			reorganizationOrRebuildCommandExp
 FROM    #tmpFragmentedIndexes
 ORDER BY AvgFragmentationPercentage DESC;
END
ELSE 
-- if 'report only' mode is disabled, then execute 
-- index reorganize/rebuild statements
BEGIN 
 DECLARE reorganizeOrRebuildCommands_cursor CURSOR
 FOR
    SELECT  dbName,schemaName,tableName,reorganizationOrRebuildCommand, reorganizationOrRebuildCommandExp
  FROM #tmpFragmentedIndexes
  WHERE reorganizationOrRebuildCommand IS NOT NULL
  ORDER BY AvgFragmentationPercentage DESC;

  
--Start executing the rebuild or reorg command

 OPEN reorganizeOrRebuildCommands_cursor;
 FETCH NEXT FROM reorganizeOrRebuildCommands_cursor INTO @dbname,@schemaname,@tablename,@ReorganizeOrRebuildCommand,@ReorganizeOrRebuildCommandExp ;
 WHILE @@fetch_status = 0
  BEGIN   
         
   IF @verboseMode = 1
   BEGIN
     PRINT ''
     PRINT 'Executing script:'     
     PRINT @ReorganizeOrRebuildCommand
   END
	print convert(char(22),getdate()) +'table '+@dbname +N'.' + @schemaname +N'.' + @tablename
   -------------- 
--declare    @msg varchar(800)
	IF OBJECT_ID(@dbname +N'.' + @schemaname +N'.' + @tablename, 'U') IS NOT NULL
	BEGIN
		BEGIN TRY  
			--select (1/0)
			EXEC  (@ReorganizeOrRebuildCommand);  
		END TRY  
		BEGIN CATCH
			select   @msg='ErrorMsg# '+convert(CHAR(10),ERROR_NUMBER())+' '+ERROR_MESSAGE() 
			print @msg
			set @errcount  = @errcount + 1
			IF @msg LIKE '%Online index operations can only be performed in Enterprise edition of SQL Server%' OR
				@msg LIKE '%online operation cannot be performed%'
			BEGIN
				PRINT 'Executing Rebuild Index OFFLINE:'
				EXEC  (@ReorganizeOrRebuildCommandExp);
				set @errcount  = @errcount - 1 --decreasing the actual error count by 1
			END
		END CATCH;
		--
		
	END
   FETCH NEXT FROM reorganizeOrRebuildCommands_cursor INTO @dbname,@schemaname,@tablename,@ReorganizeOrRebuildCommand,@ReorganizeOrRebuildCommandExp;
  END;

 CLOSE reorganizeOrRebuildCommands_cursor;
 DEALLOCATE reorganizeOrRebuildCommands_cursor;

 PRINT ''
 PRINT 'All fragmented indexes have been reorganized/rebuilt.'
 PRINT ''
	print @msg
	print 'Total error(s): '+STR(@errcount ) +'** i.e. search for ErrorMsg# in output log'
END
END 
ELSE
BEGIN
 PRINT '';
 PRINT 'Error: You need to be SysAdmin and use SQL Server 2005 or later in order to use this script.';
 PRINT '';
END
--End of Script

END

GO

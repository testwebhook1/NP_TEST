/**********************************************************
-------------------  Create CAS ID  ---------------------
***********************************************************/

declare @window_login_name SYSNAME
set @window_login_name='domainname\username'
declare @servername varchar(30),@hostname varchar(50), @instancename varchar(50), @domain varchar(50)

select @servername=@@servername
select @hostname = RTRIM(LTRIM(cast(SERVERPROPERTY('ComputerNamePhysicalNetBIOS') as varchar(200))))
	If @hostname is null 
	set @hostname = @instancename

declare @env CHAR(15)
set @env= case when @servername like '%1__' or @servername like '%7__' 
or @servername like '%prd%'  or @servername like '%prod%' then 'prod' 
 when @hostname like '%1__' or @hostname like '%7__' then 'prod' 
 else 'dev'
end --as 'env'

select @domain=DEFAULT_DOMAIN()
If @domain='ANALYTICS'
		select @domain = 'MDYNYCMAS'

if @env = 'dev'
	set @window_login_name = @domain+'\sql_ex_cas01'
if @env = 'prod'
	set @window_login_name = @domain+'\sql_pr_cas01'

if SUSER_ID( @window_login_name) IS NULL
begin
	declare @version int
	declare @login_cmd varchar(100)
	set @version= @@microsoftversion / 0x01000000
	if (@version>8)

	begin
		set @login_cmd='create login ['+@window_login_name +'] from windows'
		exec(@login_cmd)
	end
	else
	begin
		exec sp_grantlogin @window_login_name
	end
end

if not exists (select * from master.dbo.sysusers where [name]=@window_login_name)
begin
	EXEC sp_grantdbaccess @window_login_name, @window_login_name
	EXEC sp_addsrvrolemember  @window_login_name , 'sysadmin'
end

GO

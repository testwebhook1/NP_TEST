/**********************************************************
---------------- Create DB Maint JOB  --------------------
***********************************************************/
USE [msdb]
GO

/****** Object:  Job [DB Maintenance Plan - Weekly]    Script Date: 06/10/2018 20:10:15 ******/
IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs WHERE name = N'DB Maintenance Plan - Weekly')
EXEC msdb.dbo.sp_delete_job @job_name=N'DB Maintenance Plan - Weekly', @delete_unused_schedule=1
GO

USE [msdb]
GO

/****** Object:  Job [DB Maintenance Plan - Weekly]    Script Date: 06/10/2018 20:10:15 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [Database Maintenance]    Script Date: 7/20/2018 1:03:45 AM ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'Database Maintenance' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'Database Maintenance'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'DB Maintenance Plan - Weekly', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'Weekly Maintenance Job', 
		@category_name=N'Database Maintenance', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [CheckDB]    Script Date: 7/20/2018 1:03:45 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'CheckDB', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=4, 
		@on_fail_step_id=4, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'BEGIN
IF OBJECT_ID(''tempdb..#CheckOnlineDB'') IS NOT NULL DROP TABLE #CheckOnlineDB
Create table #CheckOnlineDB
(
ID INT IDENTITY (1,1) NOT NULL ,
Database_name sysname NOT NULL,
State_desc nvarchar(60)
)

Insert into #CheckOnlineDB

Select name,state_desc 
from sys.databases 
where state_desc=''Online''

Declare @ExecuteCmd nvarchar(max), @ID Int, @DBName sysname, @State_Desc1 nvarchar(60)

SET @ID=1

While (1=1)
BEGIN
Select @ID=ID, @DBName=Database_name, @State_Desc1=State_desc
from #CheckOnlineDB
where ID=@ID
IF @@ROWCOUNT=0
BREAK

SET @ExecuteCmd = N''DBCC CHECKDB(['' + @DBName + N''])WITH NO_INFOMSGS, ALL_ERRORMSGS, DATA_PURITY ''
--Print @command1
exec sp_executesql @ExecuteCmd
Set @ID=@ID+1

END
END', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Reindexing]    Script Date: 7/20/2018 1:03:45 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Reindexing', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=4, 
		@on_fail_step_id=4, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXECUTE master.[dbo].[rebuild_reorg_index] 
@databaseToCheck = NULL,
@fragmentationThreshold=10, 
@indexFillFactor=90,
@doonline = ''ON'',
@sortInTempdb = ''ON'',
@reportOnly=0', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [UpdateStats]    Script Date: 7/20/2018 1:03:45 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'UpdateStats', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=4, 
		@on_fail_step_id=4, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC master.dbo.update_stats
@databaseToCheck = NULL,--NULL for all databases
@rowmodctr = 500,
@samplepercent=20,
@reportonly=0', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [SendNotification]    Script Date: 7/20/2018 1:03:45 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'SendNotification', 
		@step_id=4, 
		@cmdexec_success_code=0, 
		@on_success_action=2, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @strMailSubject varchar(1024)
set @strMailSubject = ''< '' + @@Servername + '' > '' + ''Job Failure : DB Maintenance - Weekly'' 

EXEC msdb.dbo.sp_send_dbmail 
     @profile_name = ''SQLDBAMail'', 
     @recipients = ''SQLServerSupport@moodys.com;'', 
     @body = ''Job Failure : DB Maintenance - Weekly'',
     @subject = @strMailSubject', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'WeelySchedule', 
		@enabled=1, 
		@freq_type=8, 
		@freq_interval=64, --Not to be changed unless day needs to be changed
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_time=230000 -- Not to be changed unless time needs to be changed
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

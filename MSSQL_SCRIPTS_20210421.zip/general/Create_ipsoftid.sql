
/**********************************************************
------------------- Create IPSoft ID  --------------------
***********************************************************/

declare @window_login_name SYSNAME
set @window_login_name='domainname\username'
declare @servername varchar(30),@hostname varchar(50), @instancename varchar(50), @domain varchar(50)

select @servername=@@servername
select @hostname = RTRIM(LTRIM(cast(SERVERPROPERTY('ComputerNamePhysicalNetBIOS') as varchar(200))))
	If @hostname is null 
	set @hostname = @instancename

declare @env CHAR(15)
set @env= case when @servername like '%1__' or @servername like '%7__' 
--or @servername like '%4__' or @servername like '%4___' 
or @servername like '%prd%'  or @servername like '%prod%' then 'prod' 
 when @hostname like '%1__' or @hostname like '%7__' then 'prod' 
when (@servername like '%2__' or @servername like '%DEV%'  or @servername like '%DV%' )
		and (@servername not like '%2e_' and @servername not like '%2QA' and @servername not like '%3201')  then 'dev' 
 else 'Controlled'
end --as 'env'

select @domain=DEFAULT_DOMAIN()
If @domain='ANALYTICS'
		select @domain = 'MDYNYCMAS'

		select DEFAULT_DOMAIN()
if @env = 'dev'
	set @window_login_name = @domain+'\sql_dv_ipc'
if @env = 'Controlled'
	set @window_login_name = @domain+'\sql_qa_ipc'
if @env = 'prod'
	set @window_login_name = @domain+'\sql_pr_ipc'

if SUSER_ID( @window_login_name) IS NULL
begin
	declare @version int
	declare @login_cmd varchar(100)
	set @version= @@microsoftversion / 0x01000000
	if (@version>8)

	begin
		set @login_cmd='create login ['+@window_login_name +'] from windows'
		exec(@login_cmd)
	end
	else
	begin
		exec sp_grantlogin @window_login_name
	end
end

use msdb
if not exists (select * from msdb.dbo.sysusers where [name]=@window_login_name)
begin
	EXEC msdb.dbo.sp_grantdbaccess @window_login_name, @window_login_name
	EXEC msdb.dbo.sp_addrolemember 'db_datareader', @window_login_name
	end
	else
	begin
	EXEC msdb.dbo.sp_addrolemember 'db_datareader', @window_login_name
	end

use master
declare @dyn_master_query_1 varchar(100)
if not exists (select * from master.dbo.sysusers where [name]=@window_login_name)
begin
	EXEC sp_grantdbaccess @window_login_name, @window_login_name
	EXEC sp_addrolemember 'db_datareader', @window_login_name
	
	set @dyn_master_query_1='Grant exec on xp_readerrorlog to ['+@window_login_name+']'
	exec(@dyn_master_query_1)

end
else
	begin
		EXEC sp_addrolemember 'db_datareader', @window_login_name
		
		set @dyn_master_query_1='Grant exec on xp_readerrorlog to ['+@window_login_name+']'
		exec(@dyn_master_query_1)
end

declare @grant_cmd varchar (200)
set @version= @@microsoftversion / 0x01000000
if (@version>8)
begin
	set @grant_cmd ='grant view server state to ['+@window_login_name+']'+
			' grant view any definition to ['+@window_login_name+']'
	use master
	exec (@grant_cmd)
	exec msdb.dbo.sp_addrolemember 'SQLAgentOperatorRole',@window_login_name

end
else
begin
	exec msdb.dbo.sp_addrolemember 'TargetServersRole',@window_login_name
end

GO

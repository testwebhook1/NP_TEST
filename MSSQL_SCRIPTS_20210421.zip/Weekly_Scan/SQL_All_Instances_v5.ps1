﻿#Set-ExecutionPolicy RemoteSigned
[CmdletBinding()]
Param(
[String]$HostFile,
[String]$HostFileDMZ,
[String]$Filter="ALL",
[String]$SQLFile,
[String]$HostName,
[String]$SQLQuery,
[String[]]$To_Recp,
[String[]]$CC_Recp,
[String]$SortUnique="YES",
[boolean]$LoadResult=0
)

$curDir=(Get-Item -Path ".\" -Verbose).FullName
$global:Results = @() ; $global:CluResults = @()
$CluCompleted=@()
$Attch=@()
$Dt=(Get-Date -Format "yyyyMMdd_hhmmss").ToString()
$Curr_Dt=(Get-Date -Format "yyyyMMdd_hhmmss").ToString()
$OutFile="$curDir\Output\SQLQueryOut_$Dt.csv"

Start-Transcript -Path "$env:TEMP\SessionLog_$Dt.log" -NoClobber | Out-Null

function Show-Usage {
$scriptname=split-path $MyInvocation.PSCommandPath -Leaf
Write-Output "`nUsage :"
Write-Output "$scriptname ( -HostFile <FileName> OR -HostFileDMZ <FileName> OR -HostName <HostName> ) ( -SQLFile <FileName> OR -SQLQuery <Query>) -LoadResult < 0 | 1 > [ -Filter <ALL|Instance Name> -To_Recp <Email> -CC_Recp <Email> -SortUnique <YES|NO>]"
Stop-Transcript | Out-Null
exit 1
}

function Validate-Parameters {

if( (!($HostFile) -and !($HostFileDMZ) -and !($HostName)) -or (!($SQLFile) -and !($SQLQuery)) )
{
Write-Output "A combination of one of the Host and one of the SQL parameters is required."
Show-Usage
exit 1
}
elseif (($HostFile) -and (!(Test-Path $HostFile) -or (Import-Csv $HostFile | Get-Member -Type NoteProperty).count -ne 1))
{
Write-Output "Invalid file (or) file format for 'HostFile' parameter entered."
Show-Usage
exit 1
}
elseif (($HostFileDMZ) -and (!(Test-Path $HostFileDMZ) -or (Import-Csv $HostFileDMZ | Get-Member -Type NoteProperty).count -ne 2))
{
Write-Output "Invalid file (or) file format for 'HostFileDMZ' parameter entered."
Show-Usage
exit 1
}
elseif (($SQLFile) -and !(Test-Path $SQLFile))
{
Write-Output "Invalid file for 'SQLFile' parameter entered."
Show-Usage
exit 1
}
elseif ( (($HostName) -and (Test-Path $HostName)) -or (($SQLQuery) -and (Test-Path $SQLQuery)) )
{
Write-Output "Invalid value for 'HostName' or 'SQLQuery' parameter entered. Use 'HostFile' or 'SQLFile' parameters for files."
Show-Usage
exit 1
}
elseif (($SQLFile) -and ($SQLQuery))
{
Write-Output "Use ONLY ONE of the SQL parameters."
Show-Usage
exit 1
}
}

function Validate-Host {
Param ([String]$Hostname) 

if( !(Test-Connection -Cn $Hostname -BufferSize 16 -Count 1 -ea 0 -quiet) )
{
Write-Output "Unable to connect to $Hostname. Skipping host." >> $env:TEMP/ErrorHosts.txt
Write-Output "$Hostname - TestConnection failed" >> $env:TEMP/HostStatus.txt
Write-Output "Unable to connect to $Hostname. Skipping host."
$Global:ValidateHost=0
#exit 1
}
else
{
$Global:ValidateHost=1
$so=New-PSSessionOption -OpenTimeout 10000 -OperationTimeout 10000 -CancelTimeout 10000
TRY { Invoke-Command -ComputerName $Hostname -ErrorAction Stop -ScriptBlock{Get-ChildItem C:\ } -SessionOption $so | Out-Null } 
CATCH { 
#$_
Write-Output "Could not establish PSSession to $Hostname - $_ . Skipping host." >> $env:TEMP/ErrorHosts.txt
Write-Output "$Hostname - InvokeCommand test failed" >> $env:TEMP/HostStatus.txt
Write-Output "Could not establish PSSession to $Hostname - $_ . Skipping host."
$Global:ValidateHost=0
 }
}
}

function Validate-Instances {
Param ([String]$Hostname) 

$reg = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey('LocalMachine', $Hostname)
$regKey= $reg.OpenSubKey("SOFTWARE\\Microsoft\\Microsoft SQL Server\\Instance Names\\SQL" )
if ($regkey) { $global:instances = $regkey.GetValueNames() ; $global:sqlservices = gwmi win32_service -computername $Hostname | where {$_.DisplayName -like "SQL Server (*)"} }
else { $global:instances = $null }

}

function Validate-Instance {
Param ([String]$Hostname,[String]$Instance) 

$ChkServiceState=$($global:sqlservices | where {$_.DisplayName -like "*$Instance*"}).State
$global:srvchk = 1
if ($ChkServiceState -ne "Running") { $global:srvchk = 0 }
else { $global:srvchk = 1 }

}

function Validate-Cluster {
Param ([String]$Hostname,[String]$inst) 

$global:iscluster=0
$global:clusqlname=""
$sqlnetworkname=""
$sqlinstancename=""

If ((Get-Service -ComputerName $Hostname | Where-Object {$_.Displayname -match "Cluster*"}).Status -eq "Running")
{
    $sqlnetworkname=(Invoke-Command -ArgumentList $inst -ComputerName $Hostname -ErrorAction Stop -ScriptBlock{param([string]$inst);Get-ClusterResource | Where-Object {$_.Name -like "SQL Network Name*" -and $_.OwnerGroup -like "*$inst*"}}).name -replace "SQL Network Name \(|\)",""
    foreach ($sqlnn in $sqlnetworkname){
        #Write-Host "SQL Network Name : $sqlnn"
        $sqlinstancename=(Invoke-Command -ComputerName $Hostname -ArgumentList $sqlnn -ErrorAction Stop -ScriptBlock{param($netname);Get-ClusterResource | Where-Object {$_.Name -like "SQL Network Name*$netname*"}}).ownergroup -replace "SQL Server \(|\)",""
        #Write-Host "SQL Instance Name : $sqlinstancename"
        if ($sqlinstancename -eq "MSSQLSERVER"){$global:clusqlname=$sqlnn}
        else {$global:clusqlname=$sqlnn+"\"+$sqlinstancename}
        #Write-Host $sqlname
        if ($sqlinstancename -eq $inst){$global:iscluster=1}
        #Write-host "Is cluster : $global:iscluster"
        #(Invoke-Command -ComputerName $Hostname -ErrorAction Stop -ScriptBlock{Get-ClusterResource | Get-ClusterOwnerNode | Where-Object {$_.ClusterObject -like "SQL Server*"}}).OwnerNodes -inotlike $Hostname | Sort |Get-Unique >> $env:TEMP/IgnoreHosts.txt
    
    } # foreach netname
} # if getservice cluster
}

function Execute-Standalone {
Param ([String]$H,[String]$I,[String]$Filter)

TRY {
            $session=New-PSSession -ComputerName $H -ErrorAction Stop 
            $Curr_Dt=(Get-Date -Format "yyyyMMdd_hhmmss").ToString()
            Write-Output "Executing on host $H - $I now - $Curr_Dt" 
        } 
        CATCH {
            Write-Output "Could not establish PSSession to $H - $_ . Skipping host." >> $env:TEMP/ErrorHosts.txt
            Write-Output "$H - PSSession Test failed (Inside)" >> $env:TEMP/HostStatus.txt
            Write-Output "Could not establish PSSession to $H - $_ . Skipping host."
            continue
        }

        if ($I -eq "SQLEXPRESS" -or $I -eq "SHAREPOINT") { 
        Write-Output "Skipping $I instance on $H" >> $env:TEMP/ErrorHosts.txt
        Write-Output "Skipping $I instance on $H"
        continue
        }

        if ($I -ne "MSSQLSERVER") { $sqlname=$H+"\"+$I }
        else  { $sqlname=$H }

        if ($Filter -ne "ALL" -and $sqlname -notlike "*$Filter*") { continue }

        $scriptblock = {
        param($sqlname)
        
            set-executionpolicy unrestricted -force

            if ( !(Test-Path C:\TEMP\SQLCommand.sql) ) {
            Write-Host "SQL File not copied to server $env:COMPUTERNAME. Skipping host."
            continue
            }

            $WarningPreference = 'SilentlyContinue'
            TRY{[reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo") | Out-Null
            Add-PSSnapin SqlServerCmdletSnapin100 2>&1 | Out-Null
            Add-PSSnapin SqlServerProviderSnapin100 2>&1 | Out-Null
            Import-Module SQLPS 2>&1 | Out-Null
            Import-Module SQLServer 2>&1 | Out-Null } 
            CATCH {}

            TRY { Invoke-Sqlcmd -ServerInstance "$sqlname" -Query "select 1" -QueryTimeout 360 -ErrorAction Stop | Out-Null }
            CATCH { 
                Write-Host "Error connecting to SQL Server $sqlname - $_ . Skipping Instance."
                continue
            }

            Invoke-Sqlcmd -ServerInstance $sqlname -InputFile C:\TEMP\SQLCommand.sql -QueryTimeout 360

            Remove-Item C:\TEMP\SQLCommand.sql -ErrorAction SilentlyContinue
            
        } #scriptblock

        TRY { 
            if( !(Test-Path \\$H\c$\TEMP) ) {New-Item \\$H\c$\TEMP -Type Directory -ErrorAction ignore | Out-Null}
        
            Copy-Item $env:TEMP\SQLCommand.sql -Destination \\$H\c$\TEMP\SQLCommand.sql }
        CATCH { 
            Write-Output "Copy SQL File to $H failed - $_ . Skipping host." >> $env:TEMP/ErrorHosts.txt
            Write-Output "$H - Copy File Failed" >> $env:TEMP/HostStatus.txt
            continue
        }

        $out=Invoke-Command -Session $($session | ? { $_.State -eq 'Opened' }) -ScriptBlock $scriptblock -ArgumentList ($sqlname) -AsJob 

        Wait-Job $out | Out-Null
        $global:Results+=Receive-Job $out

        #$global:Results | ft -AutoSize

        Remove-PSSession $session

}

function Execute-Cluster {
Param ([String]$H,[String]$sqlname,[String]$sqlv)

Write-Output "Executing on host $H - $sqlname now."

if (!($sqlv)) {
    
        TRY { Invoke-Sqlcmd -ServerInstance "$sqlname" -Query "select 1" -QueryTimeout 360 -ErrorAction Stop | Out-Null }
        CATCH { 
            Write-Host "Error connecting to SQL Server $sqlname - $_ . Skipping Instance." >> $env:TEMP/ErrorHosts.txt
            Write-Output "$sqlname - Cannot connect to Cluster SQL Server" >> $env:TEMP/HostStatus.txt
            continue 
        }

        $TempResults=Invoke-Sqlcmd -ServerInstance $sqlname -InputFile $env:TEMP\SQLCommand.sql -QueryTimeout 360
        $TempResults | Add-Member -MemberType NoteProperty "PSComputerName" -Value "$H" 
        
        #$TempResults | ft -AutoSize

        $global:CluResults+=$TempResults
    }
else {

        $pass="ourN"+$sqlv+"pass"

        TRY { Invoke-Sqlcmd -ServerInstance "$sqlname" -Query "select 1" -Username "sa" -Password $pass -QueryTimeout 360 -ErrorAction Stop | Out-Null }
        CATCH { 
            Write-Host "Error connecting to SQL Server $sqlname - $_ . Skipping Instance." >> $env:TEMP/ErrorHosts.txt
            Write-Output "$sqlname - Cannot connect to (DMZ) Cluster SQL Server" >> $env:TEMP/HostStatus.txt
            continue
        }

        $TempResults=Invoke-Sqlcmd -ServerInstance $sqlname -InputFile $env:TEMP\SQLCommand.sql -Username "sa" -Password $pass -QueryTimeout 360 -ErrorAction SilentlyContinue
        $TempResults | Add-Member -MemberType NoteProperty "PSComputerName" -Value "$H" 
        
        #$TempResults | ft -AutoSize

        $global:CluResults+=$TempResults

    }
}

Validate-Parameters

### Process Parameters

Remove-Item $env:TEMP\SQLCommand.sql -ErrorAction SilentlyContinue
Remove-Item $env:TEMP\HostList.txt -ErrorAction SilentlyContinue
Remove-Item $env:TEMP\HostListTemp.txt -ErrorAction SilentlyContinue
Remove-Item $env:TEMP\NoInstanceHostList.txt -ErrorAction SilentlyContinue
Remove-Item $env:TEMP\IgnoreHosts.txt -ErrorAction SilentlyContinue
Remove-Item $env:TEMP\ErrorHosts.txt -ErrorAction SilentlyContinue
Remove-Item $env:TEMP\HostStatus.txt -ErrorAction SilentlyContinue

if($HostFile) { Get-Content $HostFile | Where { $_ -notmatch "^#" } >> $env:TEMP\HostListTemp.txt }
if($HostName) { Write-Output $HostName >> $env:TEMP\HostListTemp.txt }

if (Test-Path -Path $env:TEMP\HostListTemp.txt) {
    if($SortUnique -eq "YES") { Get-Content $env:TEMP\HostListTemp.txt | Sort | Get-Unique >> $env:TEMP\HostList.txt }
    else { Get-Content $env:TEMP\HostListTemp.txt >> $env:TEMP\HostList.txt }
}

if ($SQLQuery){ Write-Output $SQLQuery >> $env:TEMP\SQLCommand.sql }
else { Copy-Item $SQLFile -Destination $env:TEMP\SQLCommand.sql }

if (!($To_Recp)) { 
    $To_Recp = 'SQLServerSupport@moodys.com'
    $To_Recp = 'Narendra.Arora-non-empl@Moodys.com'
    $To_Recp = @('Narendra.Arora-non-empl@Moodys.com','NileshR.Patel@moodys.com','SQLServerSupport@moodys.com')
}

if (($CC_Recp)) { 
    #$CC_Recp=$CC_Recp+@("SQLServerSupport@moodys.com","NileshR.Patel@moodys.com")
    $CC_Recp=$CC_Recp+"SQLServerSupport@moodys.com"
}
else {
    #$CC_Recp=$CC_Recp+@("SQLServerSupport@moodys.com","NileshR.Patel@moodys.com")
    $CC_Recp=$CC_Recp+@("SQLServerSupport@moodys.com")
    #$CC_Recp=$CC_Recp+"Narendra.Arora-non-empl@Moodys.com"
}

### Main Fuction

$WarningPreference = 'SilentlyContinue'
TRY{[reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo") | Out-Null
Add-PSSnapin SqlServerCmdletSnapin100 2>&1 | Out-Null
Add-PSSnapin SqlServerProviderSnapin100 2>&1 | Out-Null
Import-Module SQLPS 2>&1 | Out-Null
Import-Module SQLServer 2>&1 | Out-Null } 
CATCH {}
cd $curDir

if ( ($HostFile) -or ($HostName) ) {
    ForEach ($H in Get-Content $env:TEMP\HostList.txt ) {# % { New-PSSession -ComputerName $H | out-null}
    #$sessions = Get-PSSession

    #if ((Test-Path $env:TEMP\IgnoreHosts.txt) -and (Get-Content $env:TEMP\IgnoreHosts.txt | Where-Object {$_ -eq $H})) {continue}

    Validate-Host $H
    if ($ValidateHost -eq 0) { continue }

    Validate-Instances $H

    if ( !($global:instances) ) { 
        Write-Output "No SQL Server Instances found on $H. Skipping host." >> $env:TEMP\NoInstanceHostList.txt
        Write-Host "No SQL Server Instances found on $H. Skipping host."
        continue
    }

    foreach ($I in $global:instances) {

        Validate-Cluster $H $I

        if ($iscluster -eq 1) {
            $sqlname=$global:clusqlname
    
            if ($Filter -ne "ALL" -and $sqlname -notlike "*$Filter*") { continue }
            if ($CluCompleted -contains $sqlname) { continue }
        
            #$CluCompleted

            Execute-Cluster $H $sqlname

            $CluCompleted+=@("$sqlname")
        } #if cluster
        else {
            Validate-Instance $H $I
            
            if ( $global:srvchk -eq 1) {
                Execute-Standalone $H $I $Filter
            } #if srvchk
        
        } #else
    } # foreach instances

    } # foreach host

} # if hostfile or hostname

if ($HostFileDMZ) {
    ForEach ($HDMZ in Import-Csv $HostFileDMZ ) {
        $H=$HDMZ.server
        $V=$HDMZ.version

        #if( !(Test-Connection -Cn $H -BufferSize 16 -Count 1 -ea 0 -quiet) )
        #{
        #    Write-Output "Unable to connect to $H. Skipping host." >> $env:TEMP/ErrorHosts.txt
        #    Write-Output "$H - DMZ TestConnection failed" >> $env:TEMP/HostStatus.txt
        #    Write-Output "Unable to connect to $H. Skipping host."
        #    continue
        #}

        if ($Filter -ne "ALL" -and $H -notlike "*$Filter*") { continue }
        if ($CluCompleted -contains $H) { continue }

        Execute-Cluster $H $H $V

        $CluCompleted+=@("$H")

    } # foreach dmz host
} # if hostfiledmz

if ($global:Results) {
    #$global:Results 2> $null | Select * -ExcludeProperty RunspaceId,PSShowComputerName | ft -AutoSize
    $global:Results | Select * -ExcludeProperty RunspaceId,PSShowComputerName,RowError,RowState,Table,ItemArray,HasErrors | Export-Csv $OutFile -NoTypeInformation
    #$global:Results | Select PSComputerName,* -ExcludeProperty RunspaceId,PS* | Export-Csv $OutFile -NoTypeInformation
    #$global:Results | Select "PSComputerName","instance","Column 0","Column 1","Column 2","Column 3","Column 4","Column 5","Column 6","Column 7","Column 8","Column 9","Column 10","Column 11","Column 12","Column 13","Column 14","Column 15","Column 16","Column 17","Column 18","Column 19","Column 20","Column 21","Column 22" | Export-Csv $OutFile -NoTypeInformation
} # if results

if ($global:CluResults) {
    #$global:CluResults 2> $null | Select * -ExcludeProperty RunspaceId,PSShowComputerName | ft -AutoSize
    $global:CluResults | Select * -ExcludeProperty RunspaceId,PSShowComputerName,RowError,RowState,Table,ItemArray,HasErrors | Export-Csv $OutFile -NoTypeInformation -Append
    #$global:CluResults | Select PSComputerName,* -ExcludeProperty RunspaceId,PS* | Export-Csv $OutFile -NoTypeInformation -Append
    #$global:CluResults | Select "PSComputerName","instance","Column 0","Column 1","Column 2","Column 3","Column 4","Column 5","Column 6","Column 7","Column 8","Column 9","Column 10","Column 11","Column 12","Column 13","Column 14","Column 15","Column 16","Column 17","Column 18","Column 19","Column 20","Column 21","Column 22" | Export-Csv $OutFile -NoTypeInformation -Append
} # if cluresults

Stop-Transcript
$Attch=$Attch+@("$env:TEMP\SessionLog_$Dt.log")

##[String[]]$typelist=@("ServerInfo_01","DBInfo_01","Job Status","Disk Status","Memory Status","CPU Status","Access","Config")
##$MissingList=@()

##$ScannedList=$global:Results+$global:CluResults | select "Column 2","Column 0" -Unique | Select-Object -Property @{N='Server';E={$_."Column 2"}},@{N='Type';E={$_."Column 0"}} 
##foreach ($i in $ScannedList.Server | unique) { $l=$ScannedList | where Server -like $i | select type; foreach ($j in $typelist) { if (!($l.type -contains $j)) { $MissingList += New-Object -TypeName psobject -Property @{Host=$i;Type=$j} } } }

### Import Output into table
### nilesh added Jobserver on 10/15/2019 due to new build of SQL2016 on FRM701
$server="FTC-WBSQLFRM701";$db="MDYMIT_DBs";$table="MSSQLSCAN_02_output";$jobserver="SQL-IGNT101"

#$ConnectionString = "Data Source=$server; Database=$db; Trusted_Connection=True;"
#$connection = New-Object System.Data.SqlClient.SqlConnection("Data Source=$server;Integrated Security=SSPI;Initial Catalog=$db;") 
#. $OutFile

#$query = "TRUNCATE TABLE $table;"
#$connection.Open()
#$command = new-object System.Data.SqlClient.SqlCommand($query, $connection)
#$command.ExecuteNonQuery() | Out-Null
#$connection.Close()

#[System.Reflection.Assembly]::LoadFrom("$curDir\CsvDataReader.dll") | Out-Null
#$reader = New-Object SqlUtilities.CsvDataReader($OutFile)

#$bulkCopy = new-object ("Data.SqlClient.SqlBulkCopy") $ConnectionString
#$bulkCopy.DestinationTableName = $table
#$bulkCopy.WriteToServer($reader)
# querytimeout from 360 to 600000  -- 10/22/2019 Nilesh

if ($LoadResult -eq 1){
    Copy-Item $OutFile "$curDir\SQLQueryOut_Final.csv" -Force
    $load_result=1
    TRY { Invoke-Sqlcmd -ServerInstance $jobserver -Query "exec msdb..sp_start_job 'DBA - Load Wrapper Output';" -QueryTimeout 600000 -ErrorAction Stop }
    CATCH { $EmailBodyText += "The load into $server.$db..$table failed with error : $_" ; $load_result=0 }
    if ($load_result -eq 1){
        ## - 22-Jan-2020 Start Change 
        ## - Start-Sleep 90
        Start-Sleep 3600
        ## - 22-Jan-2020 End Change 
        $counts=Invoke-Sqlcmd -ServerInstance $server -Database $db -Query "select 'Total count:' [Type],count(*) [Count] from $table;select 'Server count:' [Type],count(distinct instance) [Count] from $table;" -QueryTimeout 360 -ErrorAction SilentlyContinue
        #$counts.ItemArray

        $EmailBodyText += "Email Body :`n`nThe output data is imported into $server.$db..$table.`n`n "+$counts.ItemArray+ "`n`n" 

        [String[]]$typelist=@("ServerInfo_01","ServerProtocols","DBInfo_01","Job Status","Disk Status","Memory Status","CPU Status","Access","Config","Services","DBMailAccount")
        $MissingList=@()

        $ScannedList=$global:Results+$global:CluResults | select "Column 2","Column 0" -Unique | Select-Object -Property @{N='Server';E={$_."Column 2"}},@{N='Type';E={$_."Column 0"}} 
        foreach ($i in $ScannedList.Server | unique) { $l=$ScannedList | where Server -like $i | select type; foreach ($j in $typelist) { if (!($l.type -contains $j)) { $MissingList += New-Object -TypeName psobject -Property @{Host=$i;Type=$j} } } }
    
    } # if load_result
} # if $LoadResult

if ((Test-Path $env:TEMP/ErrorHosts.txt)) {Get-Content $env:TEMP/ErrorHosts.txt;$Attch=$Attch+@("$env:TEMP/ErrorHosts.txt")}
if ((Test-Path $env:TEMP/HostStatus.txt)) {Get-Content $env:TEMP/HostStatus.txt;$Attch=$Attch+@("$env:TEMP/HostStatus.txt")}
if ((Test-Path $env:TEMP/NoInstanceHostList.txt)) {Get-Content $env:TEMP/NoInstanceHostList.txt;$Attch=$Attch+@("$env:TEMP/NoInstanceHostList.txt")}

if (Test-Path $OutFile) { 
    if ((Get-Item $OutFile).length/1024/1024 -lt 19) { 
    $Attch=$Attch+@("$OutFile") 
    $EmailBodyText += "Please find attached the query result output file."
    }
    else {
        TRY { Compress-Archive -Path $OutFile -DestinationPath (Get-Item $OutFile).FullName.Replace(".csv","") }
        CATCH { }
        $OutZip=(Get-Item $OutFile).FullName.Replace(".csv",".zip")
        if (Test-Path $OutZip) {
            if ((Get-Item $OutZip).length/1024/1024 -ge 19) {
            Remove-Item $OutZip -Force
            $EmailBodyText += "Result zip file size is greater than 19 MB, cannot attach to email."
            $EmailBodyText += "`nPlease open file using below shared link -`n"
            $sharelink="\\"+$env:computername + "\"+(Get-Item $OutFile).FullName.Replace(":","$")
            $EmailBodyText += $sharelink
            } # if outfile zip size
            else {
            $Attch=$Attch+@($OutZip) 
            $EmailBodyText += "Please find attached the query result output file."
            } # else output zip size
        } # if test path outfile zip
    } # else outfile size
} # if test path outfile

if ($MissingList) { $EmailBodyText += "`n`nBelow Instances have given sections missing from the data -`n"; $EmailBodyText += $MissingList | Out-String }
$EmailBodyText += "`n`nThank you!"

$test=0
if ($test -eq 1){
    $To_Recp = 'Narendra.Arora-non-empl@Moodys.com'
    $CC_Recp = 'Narendra.Arora-non-empl@Moodys.com'
}

#Write-Host Send-MailMessage -To $To_Recp -Cc $CC_Recp -Attachments $Attch -From SQLServerSupport@moodys.com -SmtpServer exmx.moodys.com -Subject "Query Automation Results <$env:COMPUTERNAME>"
Send-MailMessage -To $To_Recp -Cc $CC_Recp -Attachments $Attch -From SQLServerSupport@moodys.com -SmtpServer exmx.moodys.com -Subject "Query Automation Results <$env:COMPUTERNAME>" -Body $EmailBodyText

### Cleanup Files
if (($OutZip) -and (Test-Path $OutZip) )
    { Remove-Item $OutZip -Force -ErrorAction SilentlyContinue }
﻿$ComputerName = Get-Content "E:\DBEng\Disabling_CEIP_Service\Serverlist.txt"
foreach ($computer in $ComputerName) 
{
 
Get-Service -ComputerName $computer |? name -Like "*TELEMETRY*" | select -property MachineName,name,starttype,status
Get-Service -ComputerName $computer -name "*TELEMETRY*" | Stop-Service -passthru | Set-Service -startmode disabled
Get-Service -ComputerName $computer |? name -Like "*TELEMETRY*" | select -property MachineName,name,starttype,status

 }
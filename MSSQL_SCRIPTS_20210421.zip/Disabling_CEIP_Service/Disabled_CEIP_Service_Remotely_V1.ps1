﻿[System.Reflection.Assembly]::LoadWithPartialName('Microsoft.SqlServer.SqlWmiManagement') | out-null
$Server='PTC-WBSQLBAM101'


Get-Service -ComputerName $Server |? name -Like "*TELEMETRY*" | select -property name,starttype,status
Get-Service -ComputerName $Server -name "*TELEMETRY*" | Stop-Service -passthru | Set-Service -startmode disabled
Get-Service -ComputerName $Server |? name -Like "*TELEMETRY*" | select -property name,starttype,status
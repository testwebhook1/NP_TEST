Add-PSSnapin -Name sqlserverprovidersnapin100 -ErrorAction SilentlyContinue
Add-PSSnapin -Name sqlservercmdletsnapin100 -ErrorAction SilentlyContinue

$TServer = "FTC-WBSQLFRM701\SQL_2016"
$TDB = "MDYMIT_DBs"
$Dt=(Get-Date -Format "dd-MMM-yyyy").ToString().ToUpper()
$ErrFile="E:\DBEng\HealthCheck\Logs\HealthCheckErrors_$Dt.txt"
$OutFile="E:\DBEng\HealthCheck\Logs\HealthCheckStatus_$Dt.txt"
$Attch=@()

$Tconn = new-object System.Data.SqlClient.SQLConnection("Data Source=$Tserver;Integrated Security=SSPI;Initial Catalog=$TDB");
$Tconn.Open();

$sqlquery = "select * from Alert_app_table where is_sched='Y'"
$cmd = new-object System.Data.SqlClient.SqlCommand($sqlquery, $Tconn) ;
$result = $cmd.ExecuteReader()

#Remove-Item $ErrFile -ErrorAction SilentlyContinue
#Remove-Item $OutFile -ErrorAction SilentlyContinue

while ($result.Read()) 
{

  $QueryPath= "E:\DBEng\HealthCheck\HealthCheck.sql"
  $sqlText= Get-Content -path $QueryPath | out-string
  
  $servernm = $result.GetValue(0)
  $env = $result.GetValue(2)
  $to_recp = $result.GetValue(4)
  $cc_recp = $result.GetValue(5)
  $cc_recp = 'Rajesh.Ravindranathan@moodys.com;MoodysSQLDBA@moodys.com;' + $cc_recp
  $dbname = $result.GetValue(6)
  $schedule = $result.GetValue(12)
  $dbnamefilter="AND DBName='"+$dbname+"'"

    #$servernm
  #$env
  #$to_recp
  #$cc_recp
  #$dbname
  #$schedule
  $go_ahead="No"
  switch -Regex ($schedule){
  'D|d'{
    $dur=1
    $dur_text="Daily"
    $go_ahead="Yes"
    }
  'W|w'{
    $dur=7
    $dur_text="Weekly"
    $dayofweek=(get-date).DayOfWeek
    if($dayofweek -eq "Monday"){$go_ahead="Yes";}
    }
  'M|m'{
    $dur=30
    $dur_text="Monthly"
    $dayofmonth=(get-date).Day
    if($dayofmonth -eq 1){$go_ahead="Yes";}
    }
  default{
    $dur=1
    $dur_text="Daily"
    $go_ahead="Yes"
    }
  }
  
  #$go_ahead="Yes"  
  
  $sqlText=$sqlText -replace "%%env%%",$env
  $sqlText=$sqlText -replace "%%to_email%%",$to_recp
  $sqlText=$sqlText -replace "%%cc_email%%",$cc_recp
  $sqlText=$sqlText -replace "%%db_name%%",$dbname
  $sqlText=$sqlText -replace "%%dur%%",$dur
  $sqlText=$sqlText -replace "%%dur_text%%",$dur_text

  #$dbname.ToString()
  #$dbnamefilter
  if ($dbname.ToString() -ne $Null -and $dbname.ToString() -ne '') { $sqlText=$sqlText -replace "--%%DBNAMEFILTER%%",$dbnamefilter }

  $sqlText
   
  if($go_ahead -eq "Yes"){
      #continue
      try {
        $ErrorActionPreference = "Stop"
        Invoke-Sqlcmd -ServerInstance $servernm -Database master -query $sqlText -QueryTimeout 1800
      } catch {
        $strout = "$Dt - Server - $servernm - $dbname :: - Reason - " + $_.Exception.Message
        Write-Output $strout >> $ErrFile
        Write-Output $strout
      }
      finally {
        $ErrorActionPreference = "Continue"
        $strout = "$Dt - Server - $servernm - $dbname :: - Health Check Report Executed."
        Write-Output $strout >> $OutFile
        Write-Output $strout
      }
  }
}

if (Test-Path $OutFile) { $Attch=$Attch+@("$OutFile") }
if (Test-Path $ErrFile) { $Attch=$Attch+@("$ErrFile") }
$body=Get-Content $OutFile | Out-String 

if($Attch){
    $Err_Recp=@("<NileshR.Patel@moodys.com>", "<Deepak.Vispute-non-empl@moodys.com>", "<SQLServerSupport@moodys.com>")
    
    #Send-MailMessage -To $Err_Recp -Attachments $ErrFile -From SQLServerSupport@moodys.com -SmtpServer exmx.moodys.com -Subject "Errors found in Health Check Job <$env:COMPUTERNAME> on $Dt"
    Send-MailMessage -To $Err_Recp -Body $body -Attachments $Attch -From SQLServerSupport@moodys.com -SmtpServer exmx.moodys.com -Subject "Health Check Job Status Report <$env:COMPUTERNAME> for $Dt"
}

$result.Close()

$Tconn.Close(); 

DECLARE @tableHTML  NVARCHAR(MAX) ,  @tableHTMLcss  NVARCHAR(MAX) ,  @tableHTML1  NVARCHAR(MAX) , 
 @type char(1),@MailSubject varchar(1000) ,@to_recp varchar(1000),  @cc_recp varchar(1000),  @bcc_recp varchar(300), 
 @strMailSubject varchar(1024)    , @preBody varchar(1024), @vCount int
 set nocount on 
Select @type ='',@MailSubject = ''    
--set @strMailSubject = '< ' + @@Servername + ' - %%db_name%% > '  + ' Health Checkup Report'     
set @strMailSubject = '< ' + @@Servername + ' - %%db_name%% > '  + ': %%env%%  Long Running and blocking Report'     

select @to_recp = '%%to_email%%', 
--@to_recp = 'Narendra.Arora-non-empl@Moodys.com',@cc_recp='Narendra.Arora-non-empl@Moodys.com'
--@cc_recp='Joseph.Gimigliano@moodys.com;Mahesh.Sahore@moodys.com;Rajesh.Ravindranathan@moodys.com;MoodysSQLDBA@moodys.com;%%cc_email%%'
--@cc_recp='SQLServerSupport@moodys.com;%%cc_email%%'
@cc_recp='%%cc_email%%'

SET @tableHTMLcss =    
N'    
<style>    
.hd1 {    
 color:white;    
 font-size:14.0pt;    
 text-decoration:none;    
 font-family:Calibri, sans-serif;    
 text-align:center;    
 background:#1F497D;    
}    
.hd2 {    
 color:black;    
 font-size:10.0pt;    
 text-decoration:none;    
 font-family:Calibri, sans-serif;    
 text-align:center;    
 background:#95B3D7;    
}    
.td12 {    
 color:black;    
 font-size:9.0pt;    
 text-decoration:none;    
 font-family:Calibri, sans-serif;    
 background:#D9D9D9;    
}    
.td3 {    
 color:black;    
 font-size:9.0pt;    
 text-decoration:none;    
 font-family:Calibri, sans-serif;    
 background:#D8E4BC;    
}    
    
</style>'     

-- drop table #tmp


SELECT 
start_time start_time, 
datediff(mi,start_time,getdate()) since_min,
host_name host_name, 
login_name login_name,
DB_NAME( qs.Database_ID ) Database_Name, 
qs.CPU_Time CPU_Time, 
qs.Total_Elapsed_Time Total_Elapsed_Time,
qs.Total_Elapsed_Time/1000 TE_Insec, 
qs.Wait_Time/1000 Wait_Insec,
qs.Session_ID Session_ID,
qs.Blocking_Session_ID Blocking_Session_ID, 
qs.Status Status,
qs.Wait_Type Wait_Type, 
qs.Wait_Time Wait_Time, 
SUBSTRING(st.text, (qs.statement_start_offset/2)+1,
((CASE qs.statement_end_offset
WHEN -1 THEN DATALENGTH(st.text)
ELSE qs.statement_end_offset
END - qs.statement_start_offset)/2) + 1) statement_text,
GetDate() currentDate,
qs.Open_Transaction_Count Open_Transaction_Count
into #tmp
FROM sys.dm_exec_requests AS qs
CROSS APPLY sys.dm_exec_sql_text(qs.sql_handle) AS st
inner join sys.dm_exec_sessions SE on SE.session_id = qs.session_id
 WHERE (datediff(mi,qs.start_time,getdate()) > 120 --start_time < getdate() - .05 -- Wait_Time > 0
or ( Blocking_Session_ID <> 0 and start_time < getdate() - 0.01)
) and Not (DB_NAME( qs.Database_ID ) = 'distribution' and qs.Wait_Time /1000 < 300) -- i.e. SQL-EFM101
  and not (qs.Wait_Type='SP_SERVER_DIAGNOSTICS_SLEEP') -- i.e. PTC-AGSQLECM101
ORDER BY qs.Total_Elapsed_Time DESC


set @preBody = N'<table ><tr class="td4"> Hello, <br> <br>
You are getting this email as part of Application Infrastructure Operation�s proactive monitoring initiative to reduce INC due to long running t-sql or blocking connection due to data page locked by blocker connection.<br><br>

The below SQL server has come as an exception in our KPI report, and we need the database owner to see if there are any possibility to tune the SQL. This is a standard process we are following and this report every 1 hour for critical production databases upon request. If needed, please work with the product Vendor / development team for tuning the SQL or get their advice. Note: You can also review top 10 report if setup for you (daily/weekly).<br><br>

Please reach out to DB ops team(SQLServerSupport@moodys.com) if any further information is needed on the same.<br><br></tr></table>'

--->Long Running Query

Select @tableHTML1 = @tableHTMLcss +  @preBody +
    N'<table border="1" >' +    
    N'<tr class="hd1" ><th>  </th><th>Long Running</th>' +  '</tr></table>'

SET @tableHTML1 = @tableHTML1 +     
    N'<table border="1" >' +    
    N'<tr class="hd2"><th>start_time</th><th>since_min</th><th>host_name</th><th>login_name</th><th>Database_Name</th><th>CPU_Time</th><th>Total_Elapsed_Time' + 
    N'</th><th>TE_Insec</th><th>Wait_Insec</th><th>Session_ID</th><th>Blocking_Session_ID</th><th>Status</th><th>Wait_Type</th><th>' +
    N'</th><th>Wait_Time</th><th>statement_text</th><th>CurrentDate</th><th>OpenTrancount</th></tr>'

SET ROWCOUNT 10
select  @tableHTML1 = @tableHTML1 
+ N'<tr class="td3"> <td>'+ convert(varchar(24),start_time,120) 
+ N'</td><td>' + str(since_min, 12,2 ) 
+ N'</td><td>' + isnull(host_name,'') 
+ N'</td><td>' + isnull(login_name,'')
+ N'</td><td>' + isnull(Database_Name,'')
+ N'</td><td>' + str(CPU_Time,12,2)
+ N'</td><td>' + str(TE_Insec, 12,2)
+ N'</td><td>' + str((TE_Insec), 12,2)
+ N'</td><td>' + str(Wait_Insec/1000, 12,2)
+ N'</td><td>' + isnull(str(Session_ID,20),'')
+ N'</td><td>' + isnull(str(Blocking_Session_ID,20),'')
+ N'</td><td>' + isnull(Status,'') 
+ N'</td><td>' + isnull(Wait_Type,'') 
+ N'</td><td>' + str((Wait_Time), 12,2)
+ N'</td><td>' + isnull(statement_text,'') 
+ N'</td><td>'+ convert(varchar(24),currentDate,120)
+ N'</td><td>' + str(Open_Transaction_Count,12,2)
+ N'</td>'

FROM #tmp 

-- WHERE datediff(mi,qs.start_time,getdate()) > 120 --start_time < getdate() - .05 -- Wait_Time > 0
--ORDER BY qs.Total_Elapsed_Time DESC


select @tableHTML1 = @tableHTML1 + N'<tr> <td colspan=17>&nbsp;</td> </tr></table>'    

select @tableHTML = @tableHTML1

--> Blocking Start
Select @tableHTML1 =    
    N'<table border="1" >' +    
    N'<tr class="hd1" ><th>  </th><th>Blocking</th>' +  '</tr></table>'

SET @tableHTML1 = @tableHTML1 +   N'<table border="1" >' +    
    N'<tr class="hd2" ><th>Session ID</th><th>Command</th><th>Blocking Session ID</th><th>Wait Time</th><th>Wait Type</th></tr>'     

select  @tableHTML1 = @tableHTML1 + N'<tr class="td3"> <td>'+ str(session_id,4) + N'</td><td>'+ isnull(command,'') +     
     N'</td><td>' + str(blocking_session_id, 4) + N'</td><td>' + str(wait_time,10,2) + N'</td><td>' + isnull(wait_type,'') + N'</td></tr>'    
 from sys.dm_exec_requests where blocking_session_id <> 0
-- session_id < 10

select @tableHTML1 = @tableHTML1 + N'<tr> <td colspan=5>&nbsp;</td> </tr></table>'    

select @tableHTML = @tableHTML + @tableHTML1


select @bcc_recp='Rohit.Taru-non-empl@moodys.com'

select @vCount =count (*) from #tmp 

if @vCount > 0

begin

EXEC msdb.dbo.sp_send_dbmail @recipients=@to_recp,@copy_recipients=@cc_recp, 
    @blind_copy_recipients=@bcc_recp,
    @subject = @strMailSubject,
    @body = @tableHTML,
    @body_format = 'HTML' ;

End

set nocount off

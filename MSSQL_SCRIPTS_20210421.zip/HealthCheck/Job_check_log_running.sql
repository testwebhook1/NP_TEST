USE [msdb]
GO

/****** Object:  Job [Check_long_running]    Script Date: 4/23/2021 1:43:26 PM ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 4/23/2021 1:43:27 PM ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Check_long_running', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Check long Running and blocking]    Script Date: 4/23/2021 1:43:28 PM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Check long Running and blocking', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'PowerShell', 
		@command=N'Add-PSSnapin -Name sqlserverprovidersnapin100 -ErrorAction SilentlyContinue
Add-PSSnapin -Name sqlservercmdletsnapin100 -ErrorAction SilentlyContinue

$TServer = "FTC-WBSQLFRM701\SQL_2016"
$TDB = "MDYMIT_DBs"
$Dt=(Get-Date -Format "dd-MMM-yyyy").ToString().ToUpper()
$ErrFile="E:\DBEng\Long_running_finding_Script\output\LongrunningqErrors_$Dt.txt"
$OutFile="E:\DBEng\Long_running_finding_Script\output\LongrunningqErrorsStatus_$Dt.txt"
$Attch=@()

$Tconn = new-object System.Data.SqlClient.SQLConnection("Data Source=$Tserver;Integrated Security=SSPI;Initial Catalog=$TDB");
$Tconn.Open();

$sqlquery = "select * from Alert_app_table_longrunning where is_sched=''Y''"
$cmd = new-object System.Data.SqlClient.SqlCommand($sqlquery, $Tconn) ;
$result = $cmd.ExecuteReader()

#Remove-Item $ErrFile -ErrorAction SilentlyContinue
#Remove-Item $OutFile -ErrorAction SilentlyContinue

while ($result.Read()) 
{

  $QueryPath= "E:\DBEng\Long_running_finding_Script\To blocking details_mail_modification.sql"
  $sqlText= Get-Content -path $QueryPath | out-string
  
  $servernm = $result.GetValue(0)
  $env = $result.GetValue(2)
  $to_recp = $result.GetValue(4)
  $cc_recp = $result.GetValue(5)
  $cc_recp = ''Rohit.Taru-non-empl@moodys.com;'' + $cc_recp
  $dbname = $result.GetValue(6)
  $schedule = $result.GetValue(12)
  $dbnamefilter="AND DBName=''"+$dbname+"''"

    #$servernm
  #$env
  #$to_recp
  #$cc_recp
  #$dbname
  #$schedule
  $go_ahead="No"
  switch -Regex ($schedule){
  ''D|d''{
    $dur=1
    $dur_text="Daily"
    $go_ahead="Yes"
    }
  ''W|w''{
    $dur=7
    $dur_text="Weekly"
    $dayofweek=(get-date).DayOfWeek
    if($dayofweek -eq "Monday"){$go_ahead="Yes";}
    }
  ''M|m''{
    $dur=30
    $dur_text="Monthly"
    $dayofmonth=(get-date).Day
    if($dayofmonth -eq 1){$go_ahead="Yes";}
    }
  default{
    $dur=1
    $dur_text="Daily"
    $go_ahead="Yes"
    }
  }
  
  #$go_ahead="Yes"  
  #$to_recp="Rohit.Taru-non-empl@moodys.com"
  #$cc_recp="Rohit.Taru-non-empl@moodys.com"

  $sqlText=$sqlText -replace "%%env%%",$env
  $sqlText=$sqlText -replace "%%to_email%%",$to_recp
  $sqlText=$sqlText -replace "%%cc_email%%",$cc_recp
  $sqlText=$sqlText -replace "%%db_name%%",$dbname
  $sqlText=$sqlText -replace "%%dur%%",$dur
  $sqlText=$sqlText -replace "%%dur_text%%",$dur_text

  #$dbname.ToString()
  #$dbnamefilter
  if ($dbname.ToString() -ne $Null -and $dbname.ToString() -ne '''') { $sqlText=$sqlText -replace "--%%DBNAMEFILTER%%",$dbnamefilter }

  $sqlText
   
  if($go_ahead -eq "Yes"){
      #continue
      try {
        $ErrorActionPreference = "Stop"
        Invoke-Sqlcmd -ServerInstance $servernm -Database master -query $sqlText -QueryTimeout 1800
      } catch {
        $strout = "$Dt - Server - $servernm - $dbname :: - Reason - " + $_.Exception.Message
        Write-Output $strout >> $ErrFile
        Write-Output $strout
      }
      finally {
        $ErrorActionPreference = "Continue"
        $strout = "$Dt - Server - $servernm - $dbname :: - long Running checkup."
        Write-Output $strout >> $OutFile
        Write-Output $strout
      }
  }
}

if (Test-Path $OutFile) { $Attch=$Attch+@("$OutFile") }
if (Test-Path $ErrFile) { $Attch=$Attch+@("$ErrFile") }
$body=Get-Content $OutFile | Out-String 

if($Attch){
    $Err_Recp=@("<Rohit.Taru-non-empl@moodys.com>")
    #$Err_Recp=@("<Rohit.Taru-non-empl@moodys.com>")
    
    #Send-MailMessage -To $Err_Recp -Attachments $ErrFile -From SQLServerSupport@moodys.com -SmtpServer exmx.moodys.com -Subject "Errors found in Health Check Job <$env:COMPUTERNAME> on $Dt"
    Send-MailMessage -To $Err_Recp -Body $body -Attachments $Attch -From SQLServerSupport@moodys.com -SmtpServer exmx.moodys.com -Subject "Long Running query Status Report <$env:COMPUTERNAME> for $Dt"
}

$result.Close()

$Tconn.Close(); ', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Long running check Every one hour', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=8, 
		@freq_subday_interval=1, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20200807, 
		@active_end_date=99991231, 
		@active_start_time=0, 
		@active_end_time=235959, 
		@schedule_uid=N'1485711e-8f77-4141-9979-025d3b9a758f'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO



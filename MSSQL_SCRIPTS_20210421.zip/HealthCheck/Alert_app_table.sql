USE [MDYMIT_DBs]
GO

/****** Object:  Table [dbo].[Alert_app_table]    Script Date: 4/23/2021 1:42:25 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Alert_app_table](
	[Servername] [varchar](30) NULL,
	[Groupname] [varchar](30) NULL,
	[Environment] [varchar](5) NULL,
	[Applicationname] [varchar](30) NULL,
	[To_recp] [varchar](1000) NULL,
	[cc_recp] [varchar](1000) NULL,
	[DBName] [varchar](1000) NULL,
	[add_strg1] [varchar](1000) NULL,
	[add_strg2] [varchar](1000) NULL,
	[add_dt1] [smalldatetime] NULL,
	[add_dt2] [smalldatetime] NULL,
	[is_sched] [char](1) NULL,
	[sched_type] [varchar](20) NULL,
	[updated_On] [smalldatetime] NULL,
	[updated_By] [varchar](10) NULL
) ON [PRIMARY]
GO


